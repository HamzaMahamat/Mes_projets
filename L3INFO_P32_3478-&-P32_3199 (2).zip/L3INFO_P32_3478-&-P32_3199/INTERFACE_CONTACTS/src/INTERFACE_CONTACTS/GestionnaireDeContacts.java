package INTERFACE_CONTACTS;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class GestionnaireDeContacts {
    public List<Contact> contacts = new ArrayList<>();
    private final String fichierCSV;

    public GestionnaireDeContacts(String fichierCSV) {
        this.fichierCSV = fichierCSV;
    }
    public void chargerContacts() {
        try (BufferedReader br = new BufferedReader(new FileReader(fichierCSV))) {
            String ligne;
            while ((ligne = br.readLine()) != null) {
                String[] data = ligne.split(",");
                if (data.length == 4) {
                    contacts.add(new Contact(data[0].trim(), data[1].trim(), data[2].trim(), data[3].trim()));
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors du chargement des contacts : " + e.getMessage());
        }
    }
    public void sauvegarderContacts() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierCSV))) {
            for (Contact contact : contacts) {
                bw.write(contact.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la sauvegarde des contacts : " + e.getMessage());
        }
    }

    public void ajouterContact(Contact contact) {
        if (!contacts.contains(contact)) {
            contacts.add(contact);
            sauvegarderContacts();
        } else {
            System.out.println("Ce contact existe déjà.");
        }
    }

    public void modifierContact(String telephone, Contact contactModifie) {
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).getTelephone().equals(telephone)) {
                contacts.set(i, contactModifie);
                sauvegarderContacts();
                return;
            }
        }
        System.out.println("Contact non trouvé.");
    }


    public void supprimerContact(String telephone) {
        contacts.removeIf(contact -> contact.getTelephone().equals(telephone));
        sauvegarderContacts();
    }

    public void listerContacts() {
        if (contacts.isEmpty()) {
            System.out.println("Aucun contact disponible.");
        } else {
            for (Contact contact : contacts) {
                System.out.println(contact);
            }
        }
    }
}

