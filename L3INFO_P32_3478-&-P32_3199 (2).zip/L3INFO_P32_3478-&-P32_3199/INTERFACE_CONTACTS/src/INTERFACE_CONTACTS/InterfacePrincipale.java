package INTERFACE_CONTACTS;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.stream.Collectors;

public class InterfacePrincipale extends JFrame {
    private GestionnaireDeContacts gestionnaire;
    private JTable table;

    public InterfacePrincipale(GestionnaireDeContacts gestionnaire) {
        this.gestionnaire = gestionnaire;
        this.setTitle("Gestion des Contacts");
        this.setSize(1200, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Nom");
        model.addColumn("Prénom");
        model.addColumn("Téléphone");
        model.addColumn("Email");
        model.addColumn("Modifier");
        model.addColumn("Supprimer");

        for (Contact contact : gestionnaire.contacts) {
            model.addRow(new Object[]{
                    contact.getNom(),
                    contact.getPrenom(),
                    contact.getTelephone(),
                    contact.getEmail(),
                    "Modifier",
                    "Supprimer"
            });
        }

        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4 || column == 5;
            }
        };

        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(200);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(80);

        table.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                String action = (String) table.getValueAt(selectedRow, table.getSelectedColumn());
                String telephone = (String) table.getValueAt(selectedRow, 2);

                if ("Modifier".equals(action)) {
                    modifierContact(telephone);
                } else if ("Supprimer".equals(action)) {
                    supprimerContact(telephone);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Ajouter un contact"));

        JTextField txtNom = new JTextField();
        JTextField txtPrenom = new JTextField();
        JTextField txtTelephone = new JTextField();
        JTextField txtEmail = new JTextField();

        formPanel.add(new JLabel("Nom :"));
        formPanel.add(txtNom);
        formPanel.add(new JLabel("Prénom :"));
        formPanel.add(txtPrenom);
        formPanel.add(new JLabel("Téléphone :"));
        formPanel.add(txtTelephone);
        formPanel.add(new JLabel("Email :"));
        formPanel.add(txtEmail);

        JButton btnAjouter = new JButton("Ajouter");
        btnAjouter.addActionListener(e -> {
            String nom = txtNom.getText().trim();
            String prenom = txtPrenom.getText().trim();
            String telephone = txtTelephone.getText().trim();
            String email = txtEmail.getText().trim();

            if (nom.isEmpty() || prenom.isEmpty() || telephone.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Tous les champs doivent être remplis.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean telephoneExists = gestionnaire.contacts.stream().anyMatch(c -> c.getTelephone().equals(telephone));
            boolean emailExists = gestionnaire.contacts.stream().anyMatch(c -> c.getEmail().equals(email));

            if (telephoneExists) {
                JOptionPane.showMessageDialog(this, "Un contact avec ce numéro de téléphone existe déjà.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (emailExists) {
                JOptionPane.showMessageDialog(this, "Un contact avec cet email existe déjà.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            gestionnaire.ajouterContact(new Contact(nom, prenom, telephone, email));
            JOptionPane.showMessageDialog(this, "Contact ajouté avec succès !");
            refreshTable();
        });

        formPanel.add(new JLabel());
        formPanel.add(btnAjouter);

        mainPanel.add(formPanel, BorderLayout.EAST);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSauvegarder = new JButton("Sauvegarder");
        btnSauvegarder.addActionListener(e -> {
            gestionnaire.sauvegarderContacts();
            JOptionPane.showMessageDialog(this, "Données sauvegardées avec succès dans contact.csv !");
        });

        JButton btnQuitter = new JButton("Sauvegarder et Quitter");
        btnQuitter.addActionListener(e -> {
            gestionnaire.sauvegarderContacts();
            JOptionPane.showMessageDialog(this, "Données sauvegardées avec succès.Cliquer sur OK pour quitter !");
            System.exit(0);
        });

        bottomPanel.add(btnSauvegarder);
        bottomPanel.add(btnQuitter);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        this.getContentPane().add(mainPanel);
    }

    private void modifierContact(String telephone) {
        Contact contact = gestionnaire.contacts.stream()
                .filter(c -> c.getTelephone().equals(telephone))
                .findFirst()
                .orElse(null);

        if (contact != null) {
            String nouveauNom = JOptionPane.showInputDialog(this, "Nouveau nom :", contact.getNom());
            String nouveauPrenom = JOptionPane.showInputDialog(this, "Nouveau prénom :", contact.getPrenom());
            String nouveauTel = JOptionPane.showInputDialog(this, "Nouveau téléphone :", contact.getTelephone());
            String nouvelEmail = JOptionPane.showInputDialog(this, "Nouvel email :", contact.getEmail());

            boolean telephoneExists = gestionnaire.contacts.stream()
                    .anyMatch(c -> !c.getTelephone().equals(telephone) && c.getTelephone().equals(nouveauTel));
            boolean emailExists = gestionnaire.contacts.stream()
                    .anyMatch(c -> !c.getEmail().equals(contact.getEmail()) && c.getEmail().equals(nouvelEmail));

            if (telephoneExists) {
                JOptionPane.showMessageDialog(this, "Un contact avec ce numéro de téléphone existe déjà.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (emailExists) {
                JOptionPane.showMessageDialog(this, "Un contact avec cet email existe déjà.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            gestionnaire.modifierContact(telephone, new Contact(nouveauNom, nouveauPrenom, nouveauTel, nouvelEmail));
            JOptionPane.showMessageDialog(this, "Contact modifié avec succès !");
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Contact non trouvé !");
        }
    }

    private void supprimerContact(String telephone) {
        gestionnaire.supprimerContact(telephone);
        JOptionPane.showMessageDialog(this, "Contact supprimé avec succès !");
        refreshTable();
    }

    private void refreshTable() {
        dispose();
        new InterfacePrincipale(gestionnaire).setVisible(true);
    }

    public static void main(String[] args) {
        GestionnaireDeContacts gestionnaire = new GestionnaireDeContacts("contacts.csv");
        gestionnaire.chargerContacts();
        SwingUtilities.invokeLater(() -> new InterfacePrincipale(gestionnaire).setVisible(true));
    }
}
