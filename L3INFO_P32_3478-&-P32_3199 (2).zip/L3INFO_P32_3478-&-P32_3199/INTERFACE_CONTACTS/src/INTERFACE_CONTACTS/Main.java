package INTERFACE_CONTACTS;
import javax.swing.SwingUtilities;

public class Main {
	public static void main(String[] args) {
        GestionnaireDeContacts gestionnaire = new GestionnaireDeContacts("contacts.csv");
        gestionnaire.chargerContacts();
        SwingUtilities.invokeLater(() -> new InterfacePrincipale(gestionnaire).setVisible(true));
    }  
}