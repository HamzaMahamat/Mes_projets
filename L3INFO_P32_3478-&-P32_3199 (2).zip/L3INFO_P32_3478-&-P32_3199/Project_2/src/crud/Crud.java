package crud;
import java.util.Properties;
//import java.sql.*;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Crud {
	    private static Connection connection;
	    
	    public void connectToDatabase() {
	        try {
	            // Charger le fichier de configuration
	            Properties properties = new Properties();
	            FileInputStream inputStream = new FileInputStream("Configuration/config.properties");
	            properties.load(inputStream);
	            inputStream.close();

	            // Récupérer les informations depuis le fichier de configuration
	            String url = properties.getProperty("db.url");
	            String user = properties.getProperty("db.username");
	            String password = properties.getProperty("db.password");

	            // Se connecter à la base de données
	            connection = DriverManager.getConnection(url, user, password);
	            System.out.println("Connexion à la base de données réussie !");
	        } catch (SQLException | IOException e) {
	            e.printStackTrace();
	            throw new RuntimeException("Erreur de connexion à la base de données", e);
	        }
	    }


	    public static void main(String[] args) {
	    	Crud crud=new Crud();
//	    	String url = "jdbc:postgresql://localhost:5432/gestion_etudiant";
//	        String user = "postgres"; 
//	        String password ="Hamza";
	        
	        crud.connectToDatabase();

	            Scanner scanner = new Scanner(System.in);
	            int choix;

	            do {
	                System.out.println("\nMenu :");
	                System.out.println("1. Ajouter un étudiant");
	                System.out.println("2. Ajouter un cours");
	                System.out.println("3. Afficher les étudiants");
	                System.out.println("4. Afficher les cours");
	                System.out.println("5. Mettre à jour un étudiant");
	                System.out.println("6. Mettre à jour un cours");
	                System.out.println("7. Supprimer un étudiant");
	                System.out.println("8. Supprimer un cours");
	                System.out.println("0. Quitter");
	                System.out.print("Votre choix : ");
	                choix = scanner.nextInt();

	                switch (choix) {
	                    case 1:
	                        ajouterEtudiant(scanner);
	                        break;
	                    case 2:
	                        ajouterCours(scanner);
	                        break;
	                    case 3:
	                        afficherEtudiants();
	                        break;
	                    case 4:
	                        afficherCours();
	                        break;
	                    case 5:
	                        mettreAJourEtudiant(scanner);
	                        break;
	                    case 6:
	                        mettreAJourCours(scanner);
	                        break;
	                    case 7:
	                        supprimerEtudiant(scanner);
	                        break;
	                    case 8:
	                        supprimerCours(scanner);
	                        break;
	                    case 0:
	                        System.out.println("Au revoir !");
	                        break;
	                    default:
	                        System.out.println("Choix invalide.");
	                }
	            } while (choix != 0);
	    }

	    private static void ajouterEtudiant(Scanner scanner) {
	        try {
	            scanner.nextLine();

	            System.out.print("Nom : ");
	            String nom = scanner.nextLine(); 

	            System.out.print("Prénom : ");
	            String prenom = scanner.nextLine();

	            System.out.print("Email : ");
	            String email = scanner.nextLine();

	            System.out.print("Téléphone : ");
	            String telephone = scanner.nextLine();

	            String query = "INSERT INTO etudiants (nom, prenom, email, telephone) VALUES (?, ?, ?, ?)";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setString(1, nom);
	            statement.setString(2, prenom);
	            statement.setString(3, email);
	            statement.setString(4, telephone);

	            int rowsInserted = statement.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Étudiant ajouté avec succès.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static void ajouterCours(Scanner scanner) {
	        try {
	        	scanner.nextLine();
	            // Demande du nom du cours
	            System.out.print("Nom du cours : ");
	            String nomCours = scanner.nextLine(); // Permet les espaces

	            // Demande de la description
	            System.out.print("Description : ");
	            String description = scanner.nextLine(); // Permet les espaces

	            // Vérification que le nom du cours n'est pas vide après la saisie
	            if (nomCours.trim().isEmpty()) {
	                System.out.println("Erreur : Le nom du cours ne peut pas être vide.");
	                return; // Sortir de la fonction si l'entrée est invalide
	            }

	            // Vérification que la description n'est pas vide après la saisie
	            if (description.trim().isEmpty()) {
	                System.out.println("Erreur : La description ne peut pas être vide.");
	                return; // Sortir de la fonction si l'entrée est invalide
	            }

	            // Requête d'insertion dans la base de données
	            String query = "INSERT INTO cours (nom_cours, description) VALUES (?, ?)";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setString(1, nomCours);
	            statement.setString(2, description);

	            // Exécution de la mise à jour et confirmation
	            int rowsInserted = statement.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Cours ajouté avec succès.");
	            } else {
	                System.out.println("Échec de l'ajout du cours.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static void afficherEtudiants() {
	        try {
	            String query = "SELECT * FROM etudiants";
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery(query);

	            System.out.println("\nListe des étudiants :");
	            while (resultSet.next()) {
	                System.out.println("ID : " + resultSet.getInt("id") + ", Nom : " + resultSet.getString("nom") + ", Prénom : " + resultSet.getString("prenom") + ", Email : " + resultSet.getString("email") + ", Téléphone : " + resultSet.getString("telephone"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static void afficherCours() {
	        try {
	            String query = "SELECT * FROM cours";
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery(query);

	            System.out.println("\nListe des cours :");
	            while (resultSet.next()) {
	                System.out.println("ID : " + resultSet.getInt("id") + ", Nom du cours : " + resultSet.getString("nom_cours") + ", Description : " + resultSet.getString("description"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
    
	    private static void mettreAJourEtudiant(Scanner scanner) {
	        try {
	            System.out.print("ID de l'étudiant à modifier : ");
	            int id = scanner.nextInt();
	            scanner.nextLine(); 

	            String querySelect = "SELECT * FROM etudiants WHERE id = ?";
	            PreparedStatement selectStatement = connection.prepareStatement(querySelect);
	            selectStatement.setInt(1, id);

	            ResultSet resultSet = selectStatement.executeQuery();
	            if (resultSet.next()) {
	                System.out.println("Informations actuelles de l'étudiant :");
	                System.out.println("Nom : " + resultSet.getString("nom"));
	                System.out.println("Prénom : " + resultSet.getString("prenom"));
	                System.out.println("Téléphone : " + resultSet.getString("telephone"));

	               
	                System.out.print("Nouveau nom (laisser vide pour conserver) : ");
	                String nouveauNom = scanner.nextLine();
	                
	                System.out.print("Nouveau prénom (laisser vide pour conserver) : ");
	                String nouveauPrenom = scanner.nextLine();

	                System.out.print("Nouveau téléphone (laisser vide pour conserver) : ");
	                String nouveauTelephone = scanner.nextLine();

	                
	                String queryUpdate = "UPDATE etudiants SET nom = ?, prenom = ?, telephone = ? WHERE id = ?";
	                PreparedStatement updateStatement = connection.prepareStatement(queryUpdate);

	       
	                updateStatement.setString(1, nouveauNom.isEmpty() ? resultSet.getString("nom") : nouveauNom);
	                updateStatement.setString(2, nouveauPrenom.isEmpty() ? resultSet.getString("prenom") : nouveauPrenom);
	                updateStatement.setString(3, nouveauTelephone.isEmpty() ? resultSet.getString("telephone") : nouveauTelephone);
	                updateStatement.setInt(4, id);

	                int rowsUpdated = updateStatement.executeUpdate();
	                if (rowsUpdated > 0) {
	                    System.out.println("Étudiant mis à jour avec succès.");
	                }
	            } else {
	                System.out.println("Aucun étudiant trouvé avec cet ID.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    private static void mettreAJourCours(Scanner scanner) {
	        try {
	            System.out.print("ID du cours à modifier : ");
	            int id = scanner.nextInt();
	            scanner.nextLine(); 

	            String querySelect = "SELECT * FROM cours WHERE id = ?";
	            PreparedStatement selectStatement = connection.prepareStatement(querySelect);
	            selectStatement.setInt(1, id);

	            ResultSet resultSet = selectStatement.executeQuery();
	            if (resultSet.next()) {
	                System.out.println("\nInformations actuelles du cours :");
	                System.out.println("Nom du cours : " + resultSet.getString("nom_cours"));
	                System.out.println("Description : " + resultSet.getString("description"));

	                
	                System.out.print("Nouveau nom du cours (laisser vide pour conserver) : ");
	                String nouveauNom = scanner.nextLine();

	                System.out.print("Nouvelle description (laisser vide pour conserver) : ");
	                String nouvelleDescription = scanner.nextLine();

	                
	                String queryUpdate = "UPDATE cours SET nom_cours = ?, description = ? WHERE id = ?";
	                PreparedStatement updateStatement = connection.prepareStatement(queryUpdate);

	                
	                updateStatement.setString(1, nouveauNom.isEmpty() ? resultSet.getString("nom_cours") : nouveauNom);
	                updateStatement.setString(2, nouvelleDescription.isEmpty() ? resultSet.getString("description") : nouvelleDescription);
	                updateStatement.setInt(3, id);

	                int rowsUpdated = updateStatement.executeUpdate();
	                if (rowsUpdated > 0) {
	                    System.out.println("Cours mis à jour avec succès.");
	                } else {
	                    System.out.println("Échec de la mise à jour du cours.");
	                }
	            } else {
	                System.out.println("Aucun cours trouvé avec cet ID.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }



	    private static void supprimerEtudiant(Scanner scanner) {
	        try {
	            System.out.print("ID de l'étudiant à supprimer : ");
	            int id = scanner.nextInt();

	            String query = "DELETE FROM etudiants WHERE id = ?";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setInt(1, id);

	            int rowsDeleted = statement.executeUpdate();
	            if (rowsDeleted > 0) {
	                System.out.println("Étudiant supprimé avec succès.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    private static void supprimerCours(Scanner scanner) {
	        try {
	            System.out.print("ID du Cours à supprimer : ");
	            int id = scanner.nextInt();

	            String query = "DELETE FROM cours WHERE id = ?";
	            PreparedStatement statement = connection.prepareStatement(query);
	            statement.setInt(1, id);

	            int rowsDeleted = statement.executeUpdate();
	            if (rowsDeleted > 0) {
	                System.out.println("Cours supprimé avec succès.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}

