/**
 * 
 */
/**
 * 
 */
module Projet_2 {
    requires java.sql;
    requires org.postgresql.jdbc; // Ajoutez cette ligne pour PostgreSQL
}

