
import numpy as np

# Fonction d'activation : sigmoid et sa dérivée
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

# Données XOR
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

y = np.array([[0],
              [1],
              [1],
              [0]])

# Initialisation aléatoire des poids
np.random.seed(1)
input_neurons = 2
hidden_neurons = 2
output_neurons = 1

# Poids entre entrée et couche cachée (2x2) + biais
W1 = np.random.uniform(-1, 1, (input_neurons, hidden_neurons))
b1 = np.zeros((1, hidden_neurons))

# Poids entre couche cachée et sortie (2x1) + biais
W2 = np.random.uniform(-1, 1, (hidden_neurons, output_neurons))
b2 = np.zeros((1, output_neurons))

# Paramètres d'apprentissage
learning_rate = 0.1
epochs = 10000

# Entraînement
for epoch in range(epochs):
    # Forward pass
    hidden_input = np.dot(X, W1) + b1
    hidden_output = sigmoid(hidden_input)

    final_input = np.dot(hidden_output, W2) + b2
    final_output = sigmoid(final_input)

    # Calcul de l'erreur
    error = y - final_output
    loss = np.mean(error ** 2)

    # Rétropropagation
    d_output = error * sigmoid_derivative(final_output)
    d_hidden = d_output.dot(W2.T) * sigmoid_derivative(hidden_output)

    # Mise à jour des poids
    W2 += hidden_output.T.dot(d_output) * learning_rate
    b2 += np.sum(d_output, axis=0, keepdims=True) * learning_rate

    W1 += X.T.dot(d_hidden) * learning_rate
    b1 += np.sum(d_hidden, axis=0, keepdims=True) * learning_rate

    # Afficher la perte tous les 1000 pas
    if epoch % 1000 == 0:
        print(f"Epoch {epoch} - Loss: {loss:.6f}")

# Prédictions
print("\nPrédictions après entraînement :")
for i in range(len(X)):
    hidden = sigmoid(np.dot(X[i], W1) + b1)
    output = sigmoid(np.dot(hidden, W2) + b2)
    print(f"{X[i]} => {output[0][0]:.4f} (arrondi: {np.round(output[0][0])})")
