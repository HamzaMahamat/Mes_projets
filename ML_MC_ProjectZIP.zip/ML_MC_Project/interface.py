import tkinter as tk
from tkinter import messagebox
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from keras.utils import to_categorical
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# --- 1. Charger et préparer les données ---
with open("processed.cleveland.data", "r") as fic:
    lignes = fic.readlines()

data_list = []
for l in lignes:
    if '?' not in l:
        parts = l.strip().split(',')
        data_list.append([float(x) for x in parts])

data_list = np.array(data_list)
X = data_list[:, :-1]
Y= data_list[:, -1].astype(int)  
y_cat = to_categorical(Y, num_classes=5)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_cat, test_size=0.1, random_state=42)

# --- 2. Construire le modèle multi-classes ---
model = Sequential()
model.add(Dense(32, input_dim=X_train.shape[1], activation='relu'))
model.add(Dense(16, activation='relu'))
model.add(Dense(16, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(5, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X_train, y_train, epochs=1000)

scores = model.evaluate(X_test, y_test)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
print(model.predict(X_test[:5]).round())
model.summary()
# --- 3. Interface graphique ---
root = tk.Tk()
root.title("Prédicteur de Maladie Cardiaque (0-4)")
root.geometry("1000x600")
root.configure(bg="#f0f4f8")

main_frame = tk.Frame(root, bg="#f0f4f8")
main_frame.pack(fill="both", expand=True)

form_frame = tk.Frame(main_frame, bg="#f0f4f8")
form_frame.pack(side="left", fill="y", padx=30, pady=30)

tk.Label(form_frame, text="Données Médicales", font=("Helvetica", 16), bg="#f0f4f8").pack(pady=10)

labels_text = [
    "Âge", "Sexe", "Type douleur", "Pression au repos", "Cholestérol",
    "Sucre > 120", "ECG", "Fréquence max", "Angine",
    "Oldpeak", "Pente ST", "Nb vaisseaux", "Thal"
]

entries = []
for text in labels_text:
    frame = tk.Frame(form_frame, bg="#f0f4f8")
    frame.pack(pady=3)
    tk.Label(frame, text=text + " :", width=18, anchor="w", font=("Arial", 10), bg="#f0f4f8").pack(side="left")
    entry = tk.Entry(frame, width=10)
    entry.pack(side="left")
    entries.append(entry)

# Résultat
result_label = tk.Label(form_frame, text="", font=("Helvetica", 16, "bold"), bg="#f0f4f8")
result_label.pack(pady=20)

# Bouton
btn = tk.Button(form_frame, text="Tester", font=("Arial", 14), bg="#2ecc71", fg="white", padx=20, pady=8)
btn.pack()

# Graphique à droite
graph_frame = tk.Frame(main_frame, bg="#f0f4f8")
graph_frame.pack(side="right", fill="both", expand=True, padx=20, pady=20)

fig, ax = plt.subplots(figsize=(5, 5))
canvas = FigureCanvasTkAgg(fig, master=graph_frame)
canvas.get_tk_widget().pack(fill="both", expand=True)

# --- 4. Fonction prédiction ---
def predict():
    try:
        values = np.array([[float(e.get()) for e in entries]])
        values_scaled = scaler.transform(values)
        pred = model.predict(values_scaled)[0]
        classe = np.argmax(pred)

        if classe == 0:
            message = "Sain (aucune maladie cardiaque détectée)"
            couleur = "#27ae60"
        else:
            message = f"Malade (Gravité : {classe} / 4)"
            couleur = "#e74c3c"

        result_label.config(text="Résultat : " + message, fg=couleur)

        # Affichage graphique
        ax.clear()
        ax.scatter(X_scaled[Y == 0, 0], X_scaled[Y == 0, 7], label="Sain", c="green", alpha=0.4)
        ax.scatter(X_scaled[Y > 0, 0], X_scaled[Y > 0, 7], label="Malade", c="red", alpha=0.4)
        ax.scatter(values_scaled[0][0], values_scaled[0][7], c=couleur, marker="x", s=150, label="Patient")
        ax.set_xlabel("Âge (normalisé)")
        ax.set_ylabel("Fréquence cardiaque max (normalisée)")
        ax.set_title("Projection : Âge vs Fréquence max")
        ax.legend()
        canvas.draw()

    except Exception as e:
        messagebox.showerror("Erreur", f"Entrée invalide : {e}")

btn.config(command=predict)

# --- 5. Lancer ---
root.mainloop()
