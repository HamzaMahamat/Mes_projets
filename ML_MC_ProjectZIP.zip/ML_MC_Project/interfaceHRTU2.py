import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

BD= np.loadtxt("HTRU_2.csv", delimiter=",")
inputs_list= BD[:, :-1]
outputs_list=BD[:, -1].reshape(-1, 1)

scalerData= StandardScaler()
X_scaled = scalerData.fit_transform(inputs_list)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, outputs_list,
                                        test_size=0.2, random_state=42)



model = Sequential()
model.add(Dense(16, input_dim=8, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(4, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
model.compile(loss='binary_crossentropy',optimizer='rmsprop',metrics=['binary_accuracy'])
history=model.fit(X_train, y_train, epochs=50)
scores = model.evaluate(X_test, y_test)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))
print(model.predict(X_test[:5]).round())
model.summary()

#gradient descent
plt.figure(figsize=(8, 5))
plt.plot(history.history['loss'], label="Loss (train)", color='blue')
plt.title("Courbe de la descente de gradient")
plt.xlabel("Époques")
plt.ylabel("Loss (erreur binaire)")
plt.grid(True)
plt.legend()
plt.show()
#graphe
pca = PCA(n_components=2)
X_2D = pca.fit_transform(X_scaled)
y_flat = outputs_list.flatten()


plt.figure(figsize=(8, 6))
plt.scatter(X_2D[y_flat == 0, 0], X_2D[y_flat == 0, 1], label='Bruit (0)', alpha=0.5)
plt.scatter(X_2D[y_flat == 1, 0], X_2D[y_flat == 1, 1], label='Pulsar (1)', alpha=0.5)
plt.title("Projection PCA des données HTRU2")
plt.xlabel("Composante Principale 1")
plt.ylabel("Composante Principale 2")
plt.legend()
plt.grid(True)
plt.show()
# === Interface graphique ===
features = [
    "Profil_moyenne", "Profil_stdev", "Profil_asymétrie", "Profil_kurtosis",
    "DM_moyenne", "DM_stdev", "DM_skewness", "DM_kurtosis"
]

root = tk.Tk()
root.title("Prédicteur de Pulsars")
root.geometry("1000x400")  # 👈 Agrandit la fenêtre

# Titre
title = tk.Label(root, text="Données HTRU2 - Prédicteur de Pulsars", font=("Arial", 20, "bold"))
title.grid(row=0, column=0, columnspan=3, pady=20)

# Champs d'entrée
entries = []
for i, name in enumerate(features):
    tk.Label(root, text=f"{name} :", font=("Arial", 12)).grid(row=i+1, column=0, sticky="e", padx=10, pady=5)
    entry = tk.Entry(root, font=("Arial", 12), width=20)
    entry.grid(row=i+1, column=1, pady=5)
    entries.append(entry)

# Espace pour le graphique
fig = plt.Figure(figsize=(5, 4), dpi=100)
ax = fig.add_subplot(111)
canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().grid(row=1, column=2, rowspan=9, padx=30)

def tester():
    try:
        # Récupération des valeurs saisies par l'utilisateur
        values = np.array([float(e.get()) for e in entries]).reshape(1, -1)
        values_scaled = scalerData.transform(values)

        # Prédiction du modèle
        prediction = model.predict(values_scaled)[0][0]
        classe = "Pulsar" if prediction >= 0.5 else "Bruit"
        couleur = "blue" if prediction >= 0.5 else "orange"

        # Nettoyage du graphe
        ax.clear()

        # Tracé des points du dataset HTRU2
        ax.scatter(X_scaled[outputs_list.flatten() == 0, 0], X_scaled[outputs_list.flatten() == 0, 7],
                   label="Bruit (0)", c="green", alpha=0.4)
        ax.scatter(X_scaled[outputs_list.flatten() == 1, 0], X_scaled[outputs_list.flatten() == 1, 7],
                   label="Pulsar (1)", c="red", alpha=0.4)

        # Tracé du nouveau point saisi par l'utilisateur
        ax.scatter(values_scaled[0][0], values_scaled[0][7],
                   c=couleur, marker="x", s=150, label="Observation testée")

        # Étiquetage des axes et titre
        ax.set_xlabel("Integrated Profile Mean (normalisé)")
        ax.set_ylabel("DM-SNR Skewness (normalisé)")
        ax.set_title("Projection : IP Mean vs DM-SNR Skewness")
        ax.legend()

        # Affichage du graphe dans l'interface
        canvas.draw()

        # Message de prédiction
        messagebox.showinfo("Résultat", f"Prédiction : {classe} (Score : {prediction:.2f})")

    except ValueError:
        messagebox.showerror("Erreur", "Veuillez entrer des valeurs valides.")

# Bouton de test
btn = tk.Button(root, text="Tester", command=tester, bg="green", fg="white", font=("Arial", 14, "bold"), width=20)
btn.grid(row=10, column=0, columnspan=2, pady=20)

root.mainloop()

