# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 09:28:40 2025

@author: deribordo.six
"""

import numpy as np

# Fonction d'activation et sa dérivée
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

# Chargement des données
def load_data(filepath):
    data = []
    with open(filepath, 'r') as file:
        for line in file:
            if '?' not in line:  # Exclure les lignes avec données manquantes
                fields = line.strip().split(',')
                data.append([float(x) for x in fields])
    return np.array(data)

# Normalisation min-max
def normalize(X):
    return (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0) + 1e-8)

# Charger et préparer les données
data = load_data("processed.cleveland.data")

X_raw = data[:, :-1]   # 13 attributs
y_raw = data[:, -1]    # Classe cible (0 à 4)

# Transformer la sortie en binaire : 0 = absence de maladie, 1 = présence
y_raw = np.where(y_raw == 0, 0, 1).reshape(-1, 1)

# Normalisation des entrées
X = normalize(X_raw)
y = y_raw

# Architecture du réseau
np.random.seed(42)
input_neurons = X.shape[1]      # 13
hidden_neurons = 8
output_neurons = 1

# Poids + biais
W1 = np.random.uniform(-1, 1, (input_neurons, hidden_neurons))
b1 = np.zeros((1, hidden_neurons))

W2 = np.random.uniform(-1, 1, (hidden_neurons, output_neurons))
b2 = np.zeros((1, output_neurons))

# Entraînement
learning_rate = 0.1
epochs = 10000

for epoch in range(epochs):
    # Forward pass
    hidden_input = np.dot(X, W1) + b1
    hidden_output = sigmoid(hidden_input)

    final_input = np.dot(hidden_output, W2) + b2
    final_output = sigmoid(final_input)

    # Erreur
    error = y - final_output
    loss = np.mean(error ** 2)

    # Backpropagation
    d_output = error * sigmoid_derivative(final_output)
    d_hidden = d_output.dot(W2.T) * sigmoid_derivative(hidden_output)

    # Mise à jour des poids
    W2 += hidden_output.T.dot(d_output) * learning_rate
    b2 += np.sum(d_output, axis=0, keepdims=True) * learning_rate

    W1 += X.T.dot(d_hidden) * learning_rate
    b1 += np.sum(d_hidden, axis=0, keepdims=True) * learning_rate

    if epoch % 1000 == 0:
        print(f"Epoch {epoch} - Loss: {loss:.6f}")

# Évaluation
print("\nPrédictions finales (valeurs arrondies) :")
preds = sigmoid(np.dot(sigmoid(np.dot(X, W1) + b1), W2) + b2)
preds_binary = (preds > 0.5).astype(int)

for i in range(10):  # Afficher les 10 premiers
    print(f"Entrée: {X[i]} => Prédit: {preds[i][0]:.4f} (classe: {preds_binary[i][0]}, réel: {y[i][0]})")
