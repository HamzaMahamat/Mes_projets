import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

import tkinter as tk
from tkinter import messagebox


# 1. Charger le fichier brut
with open("processed.cleveland.data", "r") as fic:
    lignes = fic.readlines()

data_list = []
for l in lignes:
    if '?' not in l:
        parts = l.strip().split(',')
        data_list.append([float(x) for x in parts])

data_list = np.array(data_list)

X1 = data_list[:, :-1]       
Y1= data_list[:, -1]     

y = np.where(Y1 > 0, 1, 0).reshape(-1, 1)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X1)

X_training, X_testing, y_training, y_testing =train_test_split(X_scaled, y,
                                       test_size=0.2, random_state=42)



model = Sequential()
model.add(Dense(16, input_dim=X_training.shape[1], activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='rmsprop',
              metrics=['binary_accuracy'])
model.fit(X_training, y_training, epochs=1000)


scores = model.evaluate(X_testing, y_testing)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))


print(model.predict(X_testing).round())

model.summary()





pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Couleurs : bleu = sain (0), rouge = malade (1)
colors = ['blue' if label == 0 else 'red' for label in y.flatten()]

# Tracer les données projetées
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=colors, alpha=0.6)
plt.title("Projection PCA des patients (bleu = sain, rouge = malade)")
plt.xlabel("Composante principale 1")
plt.ylabel("Composante principale 2")
plt.grid(True)
plt.show()
####

def tester_patient():
    try:
        valeurs = [float(entry.get()) for entry in entrees]
        valeurs = np.array(valeurs).reshape(1, -1)
        valeurs_scaled = scaler.transform(valeurs)
        prediction = model.predict(valeurs_scaled)[0][0]
        etat = "Malade" if prediction > 0.5 else "Sain"
        messagebox.showinfo("Résultat", f"Probabilité: {prediction:.2f} → {etat}")
    except ValueError:
        messagebox.showerror("Erreur", "Veuillez entrer 13 valeurs numériques.")

# Interface graphique
fenetre = tk.Tk()
fenetre.title("Test de Maladie Cardiaque (MLP)")

etiquettes = [
    "Âge", "Sexe", "Type de douleur", "Pression artérielle", "Cholestérol",
    "Sucre > 120", "Résultat ECG", "Fréquence max", "Angine", "Oldpeak",
    "Slope", "Nbre vaisseaux", "Thal"
]

entrees = []
for i, label in enumerate(etiquettes):
    tk.Label(fenetre, text=label).grid(row=i, column=0)
    entry = tk.Entry(fenetre)
    entry.grid(row=i, column=1)
    entrees.append(entry)

btn = tk.Button(fenetre, text="Tester", command=tester_patient)
btn.grid(row=13, column=0, columnspan=2, pady=10)

fenetre.mainloop()


