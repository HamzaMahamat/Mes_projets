
import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. Charger les données depuis un CSV avec NumPy
data = np.loadtxt("winequality-red.csv", delimiter=";", skiprows=1)

# 2. Séparer les features (X) et la cible (y)
X = data[:, :-1]              # toutes les colonnes sauf la dernière
y_raw = data[:, -1]           # dernière colonne = "quality"

# 3. Transformer la sortie en binaire (ex: qualité >= 6 => 1)
y = np.where(y_raw >= 6, 1, 0).reshape(-1, 1)

# 4. Normaliser les entrées
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 5. Séparer en train/test
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 6. Créer le modèle
model = Sequential()
model.add(Dense(16, input_dim=X_train.shape[1], activation='relu'))  # input_dim=11
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# 7. Compiler et entraîner
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['binary_accuracy'])
model.fit(X_train, y_train, epochs=500, verbose=1)

# 8. Évaluation
scores = model.evaluate(X_test, y_test)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))

# 9. Prédictions sur quelques exemples
print(model.predict(X_test[:5]).round())

# 10. Résumé du modèle
model.summary()
