import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. Charger les données HTRU2 depuis le fichier CSV
data = np.loadtxt("HTRU_2.csv", delimiter=",")

# 2. Séparer les features (X) et la cible (y)
X = data[:, :-1]      # Les 8 premières colonnes sont les entrées
y = data[:, -1].reshape(-1, 1)  # La dernière colonne est la classe (0 ou 1)

# 3. Normaliser les entrées
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. Séparer en données d'entraînement et de test
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 5. Créer un modèle de réseau de neurones
model = Sequential()
model.add(Dense(16, input_dim=X_train.shape[1], activation='relu'))  # 8 entrées
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# 6. Compiler et entraîner
model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['binary_accuracy'])
model.fit(X_train, y_train, epochs=10)

# 7. Évaluation du modèle
scores = model.evaluate(X_test, y_test)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))

# 8. Prédictions sur quelques exemples
print(model.predict(X_test[:5]).round())

# 9. Résumé du modèle
model.summary()
