# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 10:08:29 2025

@author: deribordo.six
"""



from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np

# Chargement et préparation des données
with open("processed.cleveland.data", "r") as f:
    lines = f.readlines()

data = []
for line in lines:
    if '?' not in line:
        parts = line.strip().split(',')
        data.append([float(x) for x in parts])

data = np.array(data)
X = data[:, :-1]
y = data[:, -1].astype(int)  # les classes : 0,1,2,3,4

# Standardisation des features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Séparation des données
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Encodage one-hot des classes
from keras.utils import to_categorical
y_train_categorical = to_categorical(y_train, num_classes=5)
y_test_categorical = to_categorical(y_test, num_classes=5)

# 🌐 Création du modèle profond
model = Sequential()
model.add(Dense(64, activation='relu', input_shape=(X.shape[1],)))
model.add(Dense(32, activation='relu'))
model.add(Dense(16, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(5, activation='softmax'))

# Compilation
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Entraînement
model.fit(X_train, y_train_categorical, epochs=1000, batch_size=32, verbose=1, validation_split=0.1)

# Évaluation
loss, acc = model.evaluate(X_test, y_test_categorical)
print(f"\n✅ Précision sur le test : {acc:.4f}")

# Prédiction sur tout l'ensemble d'entraînement
predictions = model.predict(X_train)

# Affichage des prédictions
print("\n🔍 Exemples de prédictions (probabilités par classe) :")
print(predictions[:5])

# Prédictions en tant que classes finales
predicted_classes = np.argmax(predictions, axis=1)
print("\n🎯 Classes prédites :")
print(predicted_classes[:20])
print("✔️ Classe réelle :", y_train[:20])
