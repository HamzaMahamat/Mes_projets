#include "ChargeurCSV.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

QVector<Processus> ChargeurCSV::chargerProcessusDepuisCSV(const QString& cheminFichier) {
    QVector<Processus> processus;
    QFile fichier(cheminFichier);

    if (!fichier.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Erreur : Impossible d'ouvrir le fichier CSV.";
        return processus;
    }

    QTextStream flux(&fichier);
    QString ligne = flux.readLine();

    while (!flux.atEnd()) {
        ligne = flux.readLine();
        QStringList elements = ligne.split(',');

        if (elements.size() == 4) {
            int id = elements[0].toInt();
            int dateArrivee = elements[1].toInt();
            int dureeExecution = elements[2].toInt();
            int priorite = elements[3].toInt();

            // Créer un objet Processus et l'ajouter à la liste
            processus.append(Processus(id, dateArrivee, dureeExecution, priorite));
        }
    }

    fichier.close();
    return processus;
}
