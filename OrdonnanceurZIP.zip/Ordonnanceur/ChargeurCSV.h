#ifndef CHARGEURCSV_H
#define CHARGEURCSV_H

#include <QString>
#include <QVector>
#include "Processus.h"

class ChargeurCSV {
public:
    static QVector<Processus> chargerProcessusDepuisCSV(const QString& cheminFichier);
};

#endif // CHARGEURCSV_H
