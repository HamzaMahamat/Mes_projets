 #include "ChargeurCSV2.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>


QVector<Processus_es> ChargeurCSV2::chargerProcessusDepuisCSV2(const QString& cheminFichier) {
    QVector<Processus_es> processus;
    QFile fichier(cheminFichier);

    if (!fichier.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Erreur : Impossible d'ouvrir le fichier CSV : " << cheminFichier;
        return processus;
    }

    QTextStream flux(&fichier);
    QString ligne = flux.readLine();
    while (!flux.atEnd()) {
        ligne = flux.readLine();
        QStringList elements = ligne.split(',');


        if (elements.size() >= 3) {
            int id = elements[0].toInt();
            int dateArrivee = elements[1].toInt();
            int priorite = elements[2].toInt();
            QVector<int> tempsCalcul;
            QVector<int> tempsEntreeSortie;

            for (int i = 3; i < elements.size(); ++i) {
                QString value = elements[i].trimmed();
                if (!value.isEmpty()) {
                    if (i % 2 == 1) { // Colonne "calcul" (impair après id, dateArrivee, priorite)
                        tempsCalcul.append(value.toInt());
                    } else { // Colonne "entrée/sortie" (pair après id, dateArrivee, priorite)
                        tempsEntreeSortie.append(value.toInt());
                    }
                }
            }

            Processus_es p(id, dateArrivee, priorite, tempsCalcul, tempsEntreeSortie);
            processus.append(p);

        } else {
            // Avertir si une ligne n'a pas le bon format
            qWarning() << "Ligne ignorée (format incorrect) :" << ligne;
        }
    }

    fichier.close(); // Fermer le fichier après lecture
    return processus; // Retourner la liste des processus
}
