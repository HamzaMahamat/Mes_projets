#ifndef CHARGEURCSV2_H
#define CHARGEURCSV2_H

#include <QString>
#include <QVector>
#include "Processus_es.h"

class ChargeurCSV2 {
public:

    static QVector<Processus_es> chargerProcessusDepuisCSV2(const QString& cheminFichier);
};

#endif
