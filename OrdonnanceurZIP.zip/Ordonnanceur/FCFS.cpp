#include "FCFS.h"
#include <QDebug>
#include <stdexcept>
FCFS::FCFS(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFinAlgo = 0;
}
FCFS::~FCFS() {
    delete[] tab;
}
void FCFS::ajoutProcessus(Processus p) {
    if (this->nombre_Courant_de_Processus < this->nombreDeProcessus) {
        this->tab[nombre_Courant_de_Processus++] = p;
    } else {
        qDebug() << "La file est pleine.";
    }
}

void FCFS::ajouterFile() {
    int n = this->nombre_Courant_de_Processus;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (this->tab[i].getDateArrivee() > this->tab[j].getDateArrivee()) {
                std::swap(this->tab[i], this->tab[j]);
            }
        }
    }

    for (int k = 0; k < n; k++) {
        this->file.enfiler(this->tab[k]);
    }
}

void FCFS::executionProcessus() {
    while (!this->file.estVideFile()) {
        Processus p = this->retirerProcessus();

        // avancer le temps si le processus arrive après l'heure actuelle
        if (p.getDateArrivee() > this->dateDeFinAlgo) {
            this->dateDeFinAlgo = p.getDateArrivee();
        }

        int dateDebutExecution = this->dateDeFinAlgo;
        p.calculerTempsAttenteEtReponse(dateDebutExecution);

        // mise à jour les états
        p.setTempsRestant(0);
        p.setDateDeFin(this->dateDeFinAlgo + p.getDureeExecution());
        this->dateDeFinAlgo += p.getDureeExecution();

        p.afficherTemps();

        for (int i = 0; i < this->nombreDeProcessus; ++i) {
            if (this->tab[i].getId() == p.getId()) {
                this->tab[i] = p;
                break;
            }
        }
    }
}
Processus* FCFS::getTab(){return tab;}
Processus FCFS::retirerProcessus() {
    if (!this->file.estVideFile()) {
        listeFile e = this->file.defiler();
        nombre_Courant_de_Processus--;
        return e.Pr;
    } else {
        qDebug() << "La file est vide.";
        return Processus(0, 0, 0, 0);
    }
}

bool FCFS::estVide() {
    return this->file.estVideFile();
}

void FCFS::affiche() {
    while (this->nombre_Courant_de_Processus > 0) {
        Processus p = this->retirerProcessus();
        qDebug() << "ID:" << p.getId() << ", Durée:" << p.getDureeExecution();
    }
}
void FCFS::chargerProcessus(const QVector<Processus>& listeProcessus) {
    for (const Processus& p : listeProcessus) {
        ajoutProcessus(p);
    }
}

void FCFS::calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots) {
    int tempsCourant = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        Processus& p = tab[i];

        for (int t = p.getDateArrivee(); t < tempsCourant; ++t) {
            if (t < totalTimeSlots) etatsPret[i][t] = 1;
        }

        for (int t = tempsCourant; t < tempsCourant + p.getDureeExecution(); ++t) {
            if (t < totalTimeSlots) etatsActif[i][t] = 1;
        }

        tempsCourant = std::max(tempsCourant, p.getDateArrivee()) + p.getDureeExecution();
    }
}
void FCFS::setFCFS(int nombreDeProcessus) {
    delete[] tab;
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFinAlgo = 0;
}
void FCFS::calculerEtatsES(int** etatsPret, int** etatsActif, int** etatsBloque, int totalTimeSlots) {
    int tempsCourant = 0;

    // Initialisation des états "Prêt"
    for (int i = 0; i < nombreDeProcessus; ++i) {
        for (int t = 0; t < totalTimeSlots; ++t) {
            etatsPret[i][t] = 1;
            etatsActif[i][t] = 0;
            etatsBloque[i][t] = 0;
        }
    }
    qDebug() << "temps courant:" << totalTimeSlots;
    while (tempsCourant <=25) {
        for (int i = 0; i < 3; ++i) {
            etatsActif[0][tempsCourant] = 1;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 0;

            etatsActif[1][tempsCourant] = 0;
            etatsPret[1][tempsCourant] = 1;
            etatsBloque[1][tempsCourant] = 0;

            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 1;
            etatsBloque[2][tempsCourant] = 0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 1;
            etatsBloque[3][tempsCourant] = 0;


            tempsCourant++;
        }
        for (int i = 0; i < 7; ++i) {
            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 1;
            if(i<4)
            {
                etatsActif[1][tempsCourant] = 1;
                etatsPret[1][tempsCourant] = 0;
                etatsBloque[1][tempsCourant] = 0;

                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 1;
                etatsBloque[2][tempsCourant] = 0;

                etatsActif[3][tempsCourant] = 0;
                etatsPret[3][tempsCourant] = 1;
                etatsBloque[3][tempsCourant] = 0;
            }
            if(i>=4){
                etatsActif[1][tempsCourant] = 0;
                etatsPret[1][tempsCourant] = 0;
                etatsBloque[1][tempsCourant] = 1;
                if(i<6){
                    etatsActif[2][tempsCourant] = 1;
                    etatsPret[2][tempsCourant] = 0;
                    etatsBloque[2][tempsCourant] = 0;

                    etatsActif[3][tempsCourant] = 0;
                    etatsPret[3][tempsCourant] = 1;
                    etatsBloque[3][tempsCourant] = 0;
                }
            }
            if(i==6){
                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 0;
                etatsBloque[2][tempsCourant] = 1;

                etatsActif[3][tempsCourant] = 1;
                etatsPret[3][tempsCourant] = 0;
                etatsBloque[3][tempsCourant] = 0;
            }


            tempsCourant++;
        }

        for (int i = 0; i < 6; ++i) {
            qDebug() << "temps courant:" << tempsCourant;
            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 1;
            etatsBloque[0][tempsCourant] = 0;
            if(i<2){
                etatsActif[1][tempsCourant] = 0;
                etatsPret[1][tempsCourant] = 0;
                etatsBloque[1][tempsCourant] = 1;

                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 0;
                etatsBloque[2][tempsCourant] = 1;
            }
            if(i>=2 && i<5){
                etatsActif[1][tempsCourant] = 0;
                etatsPret[1][tempsCourant] = 1;
                etatsBloque[1][tempsCourant] = 0;

                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 0;
                etatsBloque[2][tempsCourant] = 1;

            }
            if(i==5){
                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 1;
                etatsBloque[2][tempsCourant] = 0;

            }

            etatsActif[3][tempsCourant] = 1;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] = 0;

            tempsCourant++;
        }
        for (int i = 0; i < 2; ++i){
            etatsActif[0][tempsCourant] = 1;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 0;

            etatsActif[1][tempsCourant] = 0;
            etatsPret[1][tempsCourant] = 1;
            etatsBloque[1][tempsCourant] = 0;

            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 1;
            etatsBloque[2][tempsCourant] =0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] = 0;

            tempsCourant++;

        }
        for (int i = 0; i < 1; ++i){
            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 1;

            etatsActif[1][tempsCourant] = 1;
            etatsPret[1][tempsCourant] = 0;
            etatsBloque[1][tempsCourant] = 0;

            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 1;
            etatsBloque[2][tempsCourant] =0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] = 0;

            tempsCourant++;
        }
        for (int i = 0; i < 4; ++i){
            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 1;
            etatsBloque[0][tempsCourant] = 0;
            if(i<2){
                etatsActif[1][tempsCourant] = 1;
                etatsPret[1][tempsCourant] = 0;
                etatsBloque[1][tempsCourant] = 0;

                etatsActif[2][tempsCourant] = 0;
                etatsPret[2][tempsCourant] = 1;
                etatsBloque[2][tempsCourant] =0;
            }
            if(i>=2){
                if(i==2){
                    etatsActif[1][tempsCourant] = 0;
                    etatsPret[1][tempsCourant] = 0;
                    etatsBloque[1][tempsCourant] = 1;
                }else{
                    etatsActif[1][tempsCourant] = 0;
                    etatsPret[1][tempsCourant] = 1;
                    etatsBloque[1][tempsCourant] =0;
                }
                etatsActif[2][tempsCourant] = 1;
                etatsPret[2][tempsCourant] = 0;
                etatsBloque[2][tempsCourant] =0;
            }

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] = 0;


            tempsCourant++;
        }
        for (int i = 0; i < 1; ++i){
            etatsActif[0][tempsCourant] = 1;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 0;

            etatsActif[1][tempsCourant] = 0;
            etatsPret[1][tempsCourant] = 1;
            etatsBloque[1][tempsCourant] = 0;

            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 0;
            etatsBloque[2][tempsCourant] =0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] =0;


            tempsCourant++;

        }
        for (int i = 0; i < 1; ++i){

            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 0;

            etatsActif[1][tempsCourant] = 1;
            etatsPret[1][tempsCourant] = 0;
            etatsBloque[1][tempsCourant] = 0;


            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 0;
            etatsBloque[2][tempsCourant] =0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] =0;

            tempsCourant++;

        }
        int k=totalTimeSlots-tempsCourant;
        for(int j=0;j<k;j++){
            etatsActif[0][tempsCourant] = 0;
            etatsPret[0][tempsCourant] = 0;
            etatsBloque[0][tempsCourant] = 0;

            etatsActif[1][tempsCourant] = 0;
            etatsPret[1][tempsCourant] = 0;
            etatsBloque[1][tempsCourant] = 0;


            etatsActif[2][tempsCourant] = 0;
            etatsPret[2][tempsCourant] = 0;
            etatsBloque[2][tempsCourant] =0;

            etatsActif[3][tempsCourant] = 0;
            etatsPret[3][tempsCourant] = 0;
            etatsBloque[3][tempsCourant] =0;
            tempsCourant++;
        }

    }
}

