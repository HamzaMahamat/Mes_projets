#ifndef FCFS_H
#define FCFS_H

#include "File.h"
#include "Processus.h"

class FCFS {
protected:

    int nombreDeProcessus;
    int nombre_Courant_de_Processus;
    int dateDeFinAlgo;
     File file;
public:
    Processus* tab;
    FCFS(int nombreDeProcessus);
    ~FCFS();
    void ajoutProcessus(Processus p);
    void ajouterFile();
    void executionProcessus();
    Processus retirerProcessus();
    bool estVide();
    void affiche();
    void setFCFS(int nombreDeProcessus);
    void calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots);
    void calculerEtatsES(int** etatsPret, int** etatsActif, int** etatsBloque, int totalTimeSlots);
    void chargerProcessus(const QVector<Processus>& listeProcessus);
    Processus* getTab();
};

#endif
