#include "File.h"
#include <QDebug>
#include <stdexcept>

File::File() : teteFile(nullptr), queueFile(nullptr) {}

File::~File() {
    while (!estVideFile()) {
        defiler();
    }
}

bool File::estVideFile() const {
    return teteFile == nullptr;
}

void File::enfiler(const Processus& p) {
    listeFile* nouv = new listeFile(p);
    if (estVideFile()) {
        teteFile = queueFile = nouv;
    } else {
        queueFile->next = nouv;
        queueFile = nouv;
    }
}

Processus File::defiler() {
    if (estVideFile()) {
        throw std::runtime_error("La file est vide, impossible de défiler.");
    }
    listeFile* temp = teteFile;
    Processus p = teteFile->Pr;
    teteFile = teteFile->next;
    if (teteFile == nullptr) {
        queueFile = nullptr;
    }
    delete temp;
    return p;
}
QVector<Processus> File::getProcessus() const {
    QVector<Processus> listeProcessus;
    listeFile* current = teteFile;

    while (current != nullptr) {
        listeProcessus.append(current->Pr);
        current = current->next;
    }

    return listeProcessus;
}
Processus File::premier() const {
    if (estVideFile()) {
        throw std::runtime_error("La file est vide, impossible d'accéder au premier élément.");
    }
    return teteFile->Pr;
}

