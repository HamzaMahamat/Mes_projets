#ifndef FILE_H
#define FILE_H
#include "Processus.h"

struct listeFile {
    Processus Pr;
    listeFile* next;
    listeFile(Processus p) : Pr(p), next(nullptr) {}
};

class File {
protected:
    listeFile* teteFile;
    listeFile* queueFile;
public:
    File();
    ~File();
    bool estVideFile() const;
    void enfiler(const Processus& p);
    Processus defiler();
    QVector<Processus> getProcessus() const;
    Processus premier() const;
};

#endif
