#include "PCTE.h"
#include "Processus.h"
#include <QDebug>
#include <algorithm>

PCTE::PCTE(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFin_de_algo = 0;
}


void PCTE::ajoutProcessus(Processus p) {
    if (this->nombre_Courant_de_Processus < this->nombreDeProcessus) {
        this->tab[nombre_Courant_de_Processus++] = p;
    } else {
        qWarning() << "La file est pleine";
    }
}

void PCTE::ajouterFile() {
    int n = this->nombre_Courant_de_Processus;
    Processus tmp;

    if (n <= 0) {
        qCritical() << "Erreur: aucun processus à trier.";
        return;
    }

    for (int i = 0; i < n; i++) {
        for (int j = i; j < n - 1; j++) {
            if (this->tab[i].getDureeExecution() >= this->tab[j + 1].getDureeExecution()) {
                tmp = this->tab[i];
                this->tab[i] = this->tab[j + 1];
                this->tab[j + 1] = tmp;
            }
        }
    }

    for (int k = 0; k < n; k++) {
        this->file.enfiler(this->tab[k]);
    }
}


void PCTE::executionProcessus() {

    while (!this->file.estVideFile()) {
        Processus p = this->retirerProcessus();
        qDebug() << "P" << p.getId() << " commence";
        qDebug() << "Temps d'attente : " << this->dateDeFin_de_algo;
        this->dateDeFin_de_algo += p.getDureeExecution();
        p.setTempsRestant(0);
        p.setDateDeFin(this->dateDeFin_de_algo);
        qDebug() << "Exécution complète : " << p.getDateDeFin();
    }
}

Processus PCTE::retirerProcessus() {
    if (this->nombre_Courant_de_Processus != 0) {
        listeFile e = this->file.defiler();
        nombre_Courant_de_Processus--;
        return e.Pr;
    } else {
        qCritical() << "La file est vide";
        Processus p(0, 0, 0, 0);
        return p;
    }
}

bool PCTE::estVide() {
    return this->file.estVideFile();
}

void PCTE::affiche() {
    while (this->nombre_Courant_de_Processus > 0) {
        Processus p = this->retirerProcessus();
        qDebug() << p.getId() << " " << p.getDureeExecution();
    }
}

void PCTE::chargerProcessus(const QVector<Processus>& listeProcessus) {
    for (const Processus& p : listeProcessus) {
        ajoutProcessus(p);
    }
}

void PCTE::calculerEtatsPCTE(int** etatsPret, int** etatsActif, int totalTimeSlots) {
    int tempsCourant = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        Processus& p = tab[i];


        for (int t = p.getDateArrivee(); t < tempsCourant; ++t) {
            if (t < totalTimeSlots) etatsPret[i][t] = 1;
        }

        for (int t = tempsCourant; t < tempsCourant + p.getDureeExecution(); ++t) {
            if (t < totalTimeSlots) etatsActif[i][t] = 1;
        }

        tempsCourant = std::max(tempsCourant, p.getDateArrivee()) + p.getDureeExecution();
    }
}

void PCTE::calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots) {
    int tempsCourant = 0;
    QVector<Processus> fileArrivee(tab, tab + nombreDeProcessus);
    QVector<Processus> filePret;

    std::sort(fileArrivee.begin(), fileArrivee.end(), [](const Processus& a, const Processus& b) {
        return a.getDateArrivee() < b.getDateArrivee();
    });

    while (!fileArrivee.isEmpty() || !filePret.isEmpty()) {

        while (!fileArrivee.isEmpty() && fileArrivee.front().getDateArrivee() <= tempsCourant) {
            filePret.push_back(fileArrivee.front());
            fileArrivee.pop_front();
        }

        std::sort(filePret.begin(), filePret.end(), [](const Processus& a, const Processus& b) {
            return a.getDureeExecution() < b.getDureeExecution();
        });

        if (!filePret.isEmpty()) {
            Processus p = filePret.front();
            filePret.pop_front();

            for (int t = p.getDateArrivee(); t < tempsCourant && t < totalTimeSlots; ++t) {
                etatsPret[p.getId() - 1][t] = 1;
            }

            for (int t = tempsCourant; t < tempsCourant + p.getDureeExecution() && t < totalTimeSlots; ++t) {
                etatsElu[p.getId() - 1][t] = 1;
            }

            tempsCourant += p.getDureeExecution();
        } else {
            if (!fileArrivee.isEmpty()) {
                tempsCourant = fileArrivee.front().getDateArrivee();
            }
        }
    }
}
void PCTE::setPCTE(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFin_de_algo = 0;
}


