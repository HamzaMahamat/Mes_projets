#ifndef PCTE_H
#define PCTE_H

#include "File.h"
#include "Processus.h"
#include <vector>
#include <algorithm>

class PCTE {
protected:
    File file;
    Processus* tab;
    int nombreDeProcessus;
    int nombre_Courant_de_Processus;
    int dateDeFin_de_algo;

public:
    PCTE(int nombreDeProcessus);
    void ajoutProcessus(Processus p);
    void deroulement();
    Processus retirerProcessus();  
    void ajouterFile();
    void executionProcessus();
    bool estVide();
    void affiche();
    void setPCTE(int nombreDeProcessus);
    void chargerProcessus(const QVector<Processus>& listeProcessus);
    void calculerEtatsPCTE(int** etatsPret, int** etatsActif, int totalTimeSlots);
    void calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots);
};

#endif // PCTE_H
