#include "PCTER.h"
#include "Processus.h"
#include <QDebug>
#include <algorithm>

PCTER::PCTER(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFin_de_algo = 0;
}


void PCTER::ajoutProcessus(Processus p) {
    if (this->nombre_Courant_de_Processus < this->nombreDeProcessus) {
        this->tab[nombre_Courant_de_Processus++] = p;
    } else {
        qWarning() << "La file est pleine";
    }
}
void PCTER::setPCTER(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = new Processus[nombreDeProcessus];
    this->nombre_Courant_de_Processus = 0;
    this->dateDeFin_de_algo = 0;
}
void PCTER::ajouterFile() {
    for (int i = 0; i < nombreDeProcessus; i++) {
        this->file.enfiler(this->tab[i]);
    }
}

void PCTER::executionProcessus() {
    while (!this->file.estVideFile()) {
        Processus p = this->retirerProcessus();
        qDebug() << "P" << p.getId() << " commence";
        qDebug() << "Temps d'attente : " << this->dateDeFin_de_algo;
        this->dateDeFin_de_algo += p.getDureeExecution();
        p.setTempsRestant(0);
        p.setDateDeFin(this->dateDeFin_de_algo);
        qDebug() << "Exécution complète : " << p.getDateDeFin();
    }
}

Processus PCTER::retirerProcessus() {
    if (this->nombre_Courant_de_Processus != 0) {
        listeFile e = this->file.defiler();
        nombre_Courant_de_Processus--;
        return e.Pr;
    } else {
        qCritical() << "La file est vide";
        Processus p(0, 0, 0, 0);
        return p;
    }
}

bool PCTER::estVide() {
    return this->file.estVideFile();
}

void PCTER::affiche() {
    while (this->nombre_Courant_de_Processus > 0) {
        Processus p = this->retirerProcessus();
        qDebug() << p.getId() << " " << p.getDureeExecution();
    }
}

void PCTER::chargerProcessus(const QVector<Processus>& listeProcessus) {
    for (const Processus& p : listeProcessus) {
        ajoutProcessus(p);
    }
}

void PCTER::calculerEtatsPCTER(int** etatsPret, int** etatsElu, int totalTimeSlots) {
    int tempsCourant = 0;
    File fileArrivee;
    File filePret;
    Processus processusEnCours;
    bool enExecution = false;
    int tempsRestant = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        fileArrivee.enfiler(tab[i]);
    }

    while (tempsCourant < totalTimeSlots) {
        while (!fileArrivee.estVideFile() && fileArrivee.premier().getDateArrivee() <= tempsCourant) {
            filePret.enfiler(fileArrivee.defiler());
        }

        // Si un processus est en cours d'exécution et un processus avec une durée plus courte est arrivé
        if (enExecution && !filePret.estVideFile()) {
            Processus prochain = filePret.premier();
            if (prochain.getDureeExecution() < tempsRestant) {
                // Interrompre le processus en cours et le remettre dans la file prête
                processusEnCours.setTempsRestant(tempsRestant);
                filePret.enfiler(processusEnCours);

                // Sélectionner le processus avec la plus courte durée d'exécution
                processusEnCours = filePret.defiler();
                tempsRestant = processusEnCours.getTempsRestant();
            }
        }

        // Si aucun processus n'est en cours d'exécution, en choisir un dans la file prête
        if (!enExecution && !filePret.estVideFile()) {
            processusEnCours = filePret.defiler();
            tempsRestant = processusEnCours.getDureeExecution();
            enExecution = true;
        }

        if (enExecution) {
            // Marquer l'état "Élu" pour le processus en cours
            etatsElu[processusEnCours.getId() - 1][tempsCourant] = 1;
            tempsRestant--;

            // Si le processus est terminé, réinitialiser le processus en cours
            if (tempsRestant == 0) {
                processusEnCours.setDateDeFin(tempsCourant + 1);
                enExecution = false;
            }
        }


        QVector<Processus> listeProcessus = filePret.getProcessus();
        for (const Processus& p : listeProcessus) {
            etatsPret[p.getId() - 1][tempsCourant] = 1;
        }

        tempsCourant++;
    }
}

