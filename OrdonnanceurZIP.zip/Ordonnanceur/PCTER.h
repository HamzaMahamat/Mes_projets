#ifndef PCTER_H
#define PCTER_H

#include "File.h"
#include "Processus.h"
#include <vector>
#include <algorithm>

class PCTER {
protected:
    File file;
    Processus* tab;
    int nombreDeProcessus;
    int nombre_Courant_de_Processus;
    int dateDeFin_de_algo;

public:
    PCTER(int nombreDeProcessus);
    void ajoutProcessus(Processus p);
    void ajouterFile();
    void setPCTER(int nombreDeProcessus);
    void executionProcessus();
    void affiche() ;
    Processus retirerProcessus();
    bool estVide();
    void chargerProcessus(const QVector<Processus>& listeProcessus);
    void calculerEtatsPCTER(int** etatsPret, int** etatsElu, int totalTimeSlots);
};

#endif // PCTER_H
