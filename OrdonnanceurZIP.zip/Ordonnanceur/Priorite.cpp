#include "Priorite.h"
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

Priorite::Priorite(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = (Processus*)malloc(nombreDeProcessus * sizeof(Processus));
    this->nombreCourantProcessus = 0;
    this->dateDeFinAlgo = 0;
}

void Priorite::setPriorite(int nombreDeProcessus) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = (Processus*)malloc(nombreDeProcessus * sizeof(Processus));
    this->nombreCourantProcessus = 0;
    this->dateDeFinAlgo = 0;
}

void Priorite::ajoutProcessus(Processus p) {
    if (this->nombreCourantProcessus < this->nombreDeProcessus) {
        this->tab[nombreCourantProcessus++] = p;
    } else {
        cout << "La file est pleine\n";
    }
}

void Priorite::ajouterFile() {
    int n = this->nombreCourantProcessus;

    sort(this->tab, this->tab + n, [](const Processus& a, const Processus& b) {
        if (a.getPriorite() == b.getPriorite()) {
            return a.getId() <b.getId();
        }
        return a.getPriorite() < b.getPriorite();
    });

    for (int i = 0; i < n; i++) {
        this->file.enfiler(this->tab[i]);
    }
}

void Priorite::deroulement() {
    vector<Processus> tabTrié;
    while (!this->file.estVideFile()) {
        Processus p = this->retirerProcessus();
        tabTrié.push_back(p);
    }

    sort(tabTrié.begin(), tabTrié.end(), [](Processus& a, Processus& b) {
        return a.getPriorite() > b.getPriorite();
    });

    for (Processus& p : tabTrié) {
        cout << "P" << p.getId() << " commence\n";
        this->dateDeFinAlgo += p.getDureeExecution();
        p.setDateDeFin(this->dateDeFinAlgo);
        cout << "Exécution complète: " << p.getDateDeFin() << endl;
    }
}

Processus Priorite::retirerProcessus() {
    if (this->nombreCourantProcessus != 0) {
        listeFile e = this->file.defiler();
        nombreCourantProcessus--;
        return e.Pr;
    } else {
        cout << "La file est vide\n";
        Processus p(0, 0, 0, 0);
        return p;
    }
}

bool Priorite::estVide() {
    return this->file.estVideFile();
}

void Priorite::affiche() {
    while (this->nombreCourantProcessus > 0) {
        Processus p = this->retirerProcessus();
        cout << p.getId() << " " << p.getDureeExecution() << "\n";
    }
}
void Priorite::chargerProcessus(const QVector<Processus>& listeProcessus) {
    for (const Processus& p : listeProcessus) {
        ajoutProcessus(p);
    }
}

void Priorite::calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots) {
    vector<Processus> tabTrié;

    while (!this->file.estVideFile()) {
        Processus p = this->retirerProcessus();
        tabTrié.push_back(p);
    }

    sort(tabTrié.begin(), tabTrié.end(), [](const Processus& a, const Processus& b) {
        if (a.getDateArrivee() == b.getDateArrivee()) {
            return a.getPriorite() > b.getPriorite();
        }
        return a.getDateArrivee() < b.getDateArrivee();
    });
    int tempsCourant = 0;

    for (Processus& p : tabTrié) {

        for (int t = max(0, p.getDateArrivee()); t < tempsCourant && t < totalTimeSlots; ++t) {
            if (etatsActif[p.getId() - 1][t] == 0) { // Vérifier qu'il n'est pas actif
                etatsPret[p.getId() - 1][t] = 1;
            }
        }

        tempsCourant = max(tempsCourant, p.getDateArrivee());

        for (int t = tempsCourant; t < tempsCourant + p.getDureeExecution() && t < totalTimeSlots; ++t) {
            etatsActif[p.getId() - 1][t] = 1;
        }

        tempsCourant += p.getDureeExecution();

        p.setDateDeFin(tempsCourant);
    }
}

void Priorite::calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots) {
    QVector<Processus> fileLocale;
    int tempsCourant = 0;

    while (tempsCourant < totalTimeSlots || !fileLocale.isEmpty()) {

        for (int i = 0; i < nombreDeProcessus; ++i) {
            if (tab[i].getDateArrivee() <= tempsCourant && tab[i].getTempsRestant() > 0) {
                fileLocale.append(tab[i]);
                tab[i].setTempsRestant(0);  // Empêcher de réajouter le même processus
            }
        }

        std::sort(fileLocale.begin(), fileLocale.end(), [](const Processus& a, const Processus& b) {
            return a.getPriorite() < b.getPriorite();
        });

        if (!fileLocale.isEmpty()) {
            // Sélectionner le processus avec la plus haute priorité
            Processus p = fileLocale.front();
            fileLocale.pop_front();

            // Marquer l'état "Élu" pour le processus en cours pendant une unité de temps
            etatsElu[p.getId() - 1][tempsCourant] = 1;

            // Diminuer le temps restant du processus
            p.setTempsRestant(p.getTempsRestant() - 1);

            // Si le processus est terminé, enregistrer sa date de fin
            if (p.getTempsRestant() == 0) {
                p.setDateDeFin(tempsCourant + 1);
            } else {
                // Sinon, remettre le processus non terminé dans la file
                fileLocale.append(p);
            }
        } else {
            // Aucun processus prêt, avancer le temps
            tempsCourant++;
            continue;
        }

        // Marquer les processus restants dans la file comme "Prêt" (au temps courant uniquement)
        for (const Processus& autre : fileLocale) {
            if (autre.getTempsRestant() > 0) {
                etatsPret[autre.getId() - 1][tempsCourant] = 1;
            }
        }

        // Avancer le temps
        tempsCourant++;
    }
}
