#ifndef PRIORITE_H
#define PRIORITE_H

#include "File.h"
#include "Processus.h"
#include <vector>
#include <algorithm>

class Priorite {
protected:
    File file;
    Processus* tab;
    int nombreDeProcessus;
    int nombreCourantProcessus;
    int dateDeFinAlgo;

public:
    Priorite(int nombreDeProcessus);
    void ajoutProcessus(Processus p);
    void deroulement();
    Processus retirerProcessus();
    void  ajouterFile();
    bool estVide();
    void affiche();
    void setPriorite(int nombreDeProcessus);
    void calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots);
    void calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots);
    void chargerProcessus(const QVector<Processus>& listeProcessus) ;
};

#endif // PRIORITE_H
