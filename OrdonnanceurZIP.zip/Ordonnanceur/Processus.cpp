#include "Processus.h"

Processus::Processus()
    : numP(0), dateArrivee(0), dureeExecution(0), tempsRestant(0),
    dateDeFin(0), tempsReponse(0), priorite(0), tempsAttente(0) {}

Processus::Processus(int numP, int dateArrivee, int dureeExecution, int priorite)
    : numP(numP), dateArrivee(dateArrivee), dureeExecution(dureeExecution),
    tempsRestant(dureeExecution), dateDeFin(0), tempsReponse(0),
    priorite(priorite),  tempsAttente(0) {}

Processus::~Processus() {}

void Processus::afficher() const {
    qDebug() << "Numéro de processus:" << numP;
    qDebug() << "Date d'arrivée:" << dateArrivee;
    qDebug() << "Durée d'exécution:" << dureeExecution;
    qDebug() << "Temps restant:" << tempsRestant;
    qDebug() << "Date de fin:" << dateDeFin;
    qDebug() << "Temps de réponse:" << tempsReponse;
}

int Processus::getId() const { return numP; }
int Processus::getTempsRestant() const { return tempsRestant; }
void Processus::setTempsRestant(int temps) { tempsRestant = temps; }
int Processus::getDateArrivee() const { return dateArrivee; }
int Processus::getDureeExecution() const { return dureeExecution; }
int Processus::getDateDeFin() const { return dateDeFin; }
void Processus::setDureeExecution(int duree) {
    dureeExecution = duree;
    tempsRestant = duree;
}
void Processus::setDateDeFin(int date) { dateDeFin = date; }
void Processus::setTempsReponse(int temps) { tempsReponse = temps; }
int Processus::getTempsReponse() const { return tempsReponse; }
int Processus::getPriorite() const { return priorite; }
void Processus::calculerTempsAttenteEtReponse(int dateFin) {
    tempsReponse = dateFin - dateArrivee;

}
void Processus::afficherTemps() const {
    qDebug() << "Numéro de processus:" << numP;
    qDebug() << "Temps d'attente:" << tempsAttente;
    qDebug() << "Temps de réponse:" << tempsReponse;
    qDebug() << "Date de fin:" << dateDeFin;
}
