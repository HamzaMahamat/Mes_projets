#ifndef PROCESSUS_H
#define PROCESSUS_H

#include <QString>
#include <QDebug>

class Processus {
private:
    int numP;
    int dateArrivee;
    int dureeExecution;
    int tempsRestant;
    int dateDeFin;
    int tempsReponse;
    int priorite;
    int tempsAttente;
public:
    Processus();
    Processus(int numP, int dateArrivee, int dureeExecution, int priorite);
    ~Processus();

    void afficher() const;
    int getId() const;
    int getTempsRestant() const;
    void setTempsRestant(int temps);
    int getDateArrivee() const;
    int getDureeExecution() const;
    int getDateDeFin() const;
    void setDureeExecution(int duree);
    void setDateDeFin(int date);
    void setTempsReponse(int temps);
    int getTempsReponse() const;
    int getPriorite() const;
    void calculerTempsAttenteEtReponse(int dateDebut);
    void afficherTemps() const;
};

#endif // PROCESSUS_H
