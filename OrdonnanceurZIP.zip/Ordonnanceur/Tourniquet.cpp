#include "Tourniquet.h"
#include <iostream>
using namespace std;

Tourniquet::Tourniquet(int nombreDeProcessus, int quantum) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = (Processus*)malloc(nombreDeProcessus * sizeof(Processus));
    this->nombreCourantProcessus = 0;
    this->dateDeFinTourniquet = 0;
    this->quantum = quantum;
}
void Tourniquet::setTour(int nombreDeProcessus, int quantum) {
    this->nombreDeProcessus = nombreDeProcessus;
    this->tab = (Processus*)malloc(nombreDeProcessus * sizeof(Processus));
    this->nombreCourantProcessus = 0;
    this->dateDeFinTourniquet = 0;
    this->quantum = quantum;
}

void Tourniquet::ajoutProcessus(Processus p) {
    if (this->nombreCourantProcessus < this->nombreDeProcessus) {
        this->tab[nombreCourantProcessus++]=p;
    } else {
        cout << "La file est pleine\n";
    }
}
void Tourniquet::ajouterFile()
{
    int n=this->nombreCourantProcessus;
    Processus tmp;
    for(int i=0;i<n;i++){
        for(int j=i;j<n;j++){
            if(this->tab[i].getDateArrivee() >= this->tab[j+1].getDateArrivee()){
                tmp=this->tab[i];
                this->tab[i]=this->tab[j+1];
                this->tab[j+1]=tmp;
            }
        }
    }

    for(int k=0;k<n;k++){
        cout << this->tab[k].getId() <<endl;
    }

    for(int k=0;k<n;k++){
        this->file.enfiler(this->tab[k]);
    }

}
void Tourniquet::executionProcessus() {
    while (!this->file.estVideFile()) {
        cout << "************************************************************" <<endl;

        Processus p = this->retirerProcessus();
        cout << "P" << p.getId() << " commence \n";
        if (p.getDureeExecution() <= this->quantum) {

            this->dateDeFinTourniquet += p.getDureeExecution();
            p.setTempsRestant(0);
            p.setDateDeFin(this->dateDeFinTourniquet);
            cout << "Execution complète: " <<p.getDateDeFin() << endl;
        } else {
            // si le processus a encore du temps à exécuter après le quantum
            p.setDureeExecution(p.getDureeExecution() - this->quantum);
            this->dateDeFinTourniquet += this->quantum;
            cout<<"Execution partielle, date de fin partielle: " << this->dateDeFinTourniquet << endl;
            this->file.enfiler(p);
            nombreCourantProcessus++;
        }
    }
}
void Tourniquet::chargerProcessus(const QVector<Processus>& listeProcessus) {
    for (const Processus& p : listeProcessus) {
        this->ajoutProcessus(p);
    }
}

Processus Tourniquet::retirerProcessus() {
    if (this->nombreCourantProcessus != 0) {
        listeFile e = this->file.defiler();
        nombreCourantProcessus--;
        return e.Pr;
    } else {
        cout << "La file est vide\n";
        Processus p(0, 0, 0,0);
        return p;
    }
}

bool Tourniquet::estVide() {
    return this->file.estVideFile();
}

void Tourniquet::affiche() {
    while (this->nombreCourantProcessus > 0) {
        Processus p = this->retirerProcessus();
        cout << p.getId() << " " << p.getDureeExecution() << "\n";
    }
}
void Tourniquet::calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots) {
    int tempsCourant = 0;

    QVector<Processus> fileLocale;
    for (int i = 0; i < nombreDeProcessus; ++i) {
        fileLocale.push_back(tab[i]);
    }

    while (!fileLocale.isEmpty()) {
        Processus p = fileLocale.front();
        fileLocale.pop_front();
        if (p.getDateArrivee() > tempsCourant) {
            tempsCourant = p.getDateArrivee();
        }

        for (const Processus& autre : fileLocale) {
            for (int t = tempsCourant; t < tempsCourant + quantum; ++t) {
                if (t < totalTimeSlots) {
                    etatsPret[autre.getId() - 1][t] = 1; // Marquer "Prêt" pour les processus en attente
                }
            }
        }
        int dureeExecution = std::min(quantum, p.getTempsRestant());

        for (int t = tempsCourant; t < tempsCourant + dureeExecution; ++t) {
            if (t < totalTimeSlots) {
                etatsActif[p.getId() - 1][t] = 1;
                etatsPret[p.getId() - 1][t] = 0;
            }
        }

        tempsCourant += dureeExecution;
        p.setTempsRestant(p.getTempsRestant() - dureeExecution);

        if (p.getTempsRestant() > 0) {
            fileLocale.push_back(p);
        } else {
            p.setDateDeFin(tempsCourant);
            for (int i = 0; i < nombreDeProcessus; ++i) {
                if (tab[i].getId() == p.getId()) {
                    tab[i] = p;
                    break;
                }
            }
        }
    }
}



void Tourniquet::calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots) {
    int tempsCourant = 0;

    QVector<Processus> fileAttente;  // File des processus en attente (par date d'arrivée)
    QVector<Processus> filePret;     // File des processus prêts
    QVector<Processus> fileElu;      // Processus actuellement élu (en exécution)

    // Initialisation : tous les processus commencent en attente
    for (int i = 0; i < nombreDeProcessus; ++i) {
        fileAttente.push_back(tab[i]);
    }

    while (!fileAttente.isEmpty() || !filePret.isEmpty() || !fileElu.isEmpty()) {
        // Déplacer les processus arrivés dans la file des prêts
        while (!fileAttente.isEmpty() && fileAttente.front().getDateArrivee() <= tempsCourant) {
            filePret.push_back(fileAttente.front());
            fileAttente.pop_front();
        }

        if (!fileElu.isEmpty()) {
            // Exécuter le processus élu pour une durée maximale égale au quantum
            Processus& p = fileElu.front();
            int dureeExecution = std::min(quantum, p.getTempsRestant());

            // Marquer l'état "Élu" pendant l'exécution
            for (int t = tempsCourant; t < tempsCourant + dureeExecution && t < totalTimeSlots; ++t) {
                etatsElu[p.getId() - 1][t] = 1;
            }

            // Mettre à jour le temps restant du processus et le temps courant
            tempsCourant += dureeExecution;
            p.setTempsRestant(p.getTempsRestant() - dureeExecution);

            // Si le processus est terminé, le retirer de la file "Élu"
            if (p.getTempsRestant() <= 0) {
                p.setDateDeFin(tempsCourant);
                fileElu.pop_front();
            } else {
                // Sinon, remettre dans la file des prêts
                filePret.push_back(p);
                fileElu.pop_front();
            }
        }

        // Si aucun processus n'est élu, en choisir un parmi les prêts
        if (fileElu.isEmpty() && !filePret.isEmpty()) {
            Processus p = filePret.front();
            filePret.pop_front();
            fileElu.push_back(p);
        }

        // Marquer les processus prêts
        for (const Processus& p : filePret) {
            if (tempsCourant < totalTimeSlots) {
                etatsPret[p.getId() - 1][tempsCourant] = 1;
            }
        }

        // Si aucun processus n'est prêt ni élu, avancer le temps courant
        if (fileElu.isEmpty() && filePret.isEmpty() && !fileAttente.isEmpty()) {
            tempsCourant = fileAttente.front().getDateArrivee();
        } else {
            tempsCourant++;  // Avancer le temps de manière normale
        }
    }

    // Mettre à jour les processus terminés dans le tableau
    for (const Processus& p : fileElu) {
        for (int i = 0; i < nombreDeProcessus; ++i) {
            if (tab[i].getId() == p.getId()) {
                tab[i] = p;
                break;
            }
        }
    }
}
