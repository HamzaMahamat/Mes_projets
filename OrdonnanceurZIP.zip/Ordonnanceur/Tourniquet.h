#ifndef TOURNIQUET_H
#define TOURNIQUET_H
#include "File.h"
#include "Processus.h"

class Tourniquet {
protected:
    File file;
    Processus* tab;
    int nombreDeProcessus;
    int nombreCourantProcessus;
    int dateDeFinTourniquet;
    int quantum;
public:
    Tourniquet(int nombreDeProcessus, int quantum);
    void ajoutProcessus(Processus p);
    void executionProcessus();
    Processus retirerProcessus();
    void  ajouterFile();
    bool estVide();
    void affiche();
    void setTour(int nombreDeProcessus, int quantum);
    void chargerProcessus(const QVector<Processus>& listeProcessus);
    void calculerEtats(int** etatsPret, int** etatsActif, int totalTimeSlots);
    void calculerEtatsInterface2(int** etatsPret, int** etatsElu, int totalTimeSlots);


};

#endif // TOURNIQUET_H

