#include "interfacerequisition.h"
#include "ui_interfacerequisition.h"
#include "ChargeurCSV.h"
#include "ChargeurCSV2.h"
#include <QGraphicsScene>
#include <QMessageBox>
#include <QGraphicsTextItem>
#include <QGraphicsRectItem>

#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QtCharts/QBarCategoryAxis>


InterfaceRequisition::InterfaceRequisition(QWidget *parent)
    : QDialog(parent),
    ui(new Ui::InterfaceRequisition),
    sceneTourniquet(new QGraphicsScene(this)),
    scenePriorite(new QGraphicsScene(this)),
    scenePCTE(new QGraphicsScene(this)),
    sceneFCFS(new QGraphicsScene(this)),
    scenePCTER(new QGraphicsScene(this)),
    sceneFIFO_ES(new QGraphicsScene(this))
{
    qApp->setStyleSheet("QWidget { background-color: #E0FFFF; color: black; }");


    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::WindowMinimizeButtonHint | Qt::WindowMaximizeButtonHint | Qt::WindowCloseButtonHint);

    // Associer les scènes aux GraphicsView
    ui->graphicsViewTourniquet->setScene(sceneTourniquet);
    ui->graphicsViewPriorite->setScene(scenePriorite);
    ui->graphicsViewPCTE->setScene(scenePCTE);
    ui->graphicsViewFCFS->setScene(sceneFCFS);
    ui->graphicsViewPCTER->setScene(scenePCTER);
    ui->graphicsViewFIFO_ES->setScene(sceneFIFO_ES);

    // Connecter les actions du menu
    connect(ui->actionFCFS, &QAction::triggered, this, &InterfaceRequisition::afficherPageFCFS);
    connect(ui->actionFIFO_ES, &QAction::triggered, this, &InterfaceRequisition::afficherPageFIFO_ES);
    connect(ui->actionTourniquetRequisition, &QAction::triggered, this, &InterfaceRequisition::afficherPageTourniquet);
    connect(ui->actionPrioriteRequisition, &QAction::triggered, this, &InterfaceRequisition::afficherPagePriorite);
    connect(ui->actionPCTE, &QAction::triggered, this, &InterfaceRequisition::afficherPagePCTE);
    connect(ui->actionPCTER, &QAction::triggered, this, &InterfaceRequisition::afficherPagePCTER);
    connect(ui->actionRecapitulatif, &QAction::triggered, this, &InterfaceRequisition::afficherPageRecapitulatif);

}

InterfaceRequisition::~InterfaceRequisition() {
    delete ui;
}
void InterfaceRequisition::afficherPageFCFS() {
    ui->stackedWidget->setCurrentWidget(ui->pageFCFS); //Pour afficher la page FCFS

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherFCFS(processus, totalTimeSlots);
}
void InterfaceRequisition::pauseChrono(int temps){
    top.setSingleShot(true);
    top.start(temps);
    while(top.isActive()){
        QApplication::processEvents();
    }
}
void InterfaceRequisition::afficherPageTourniquet() {
    ui->stackedWidget->setCurrentWidget(ui->pageTourniquet);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    int quantum = 1;
    chargerEtAfficherTourniquet(processus, totalTimeSlots, quantum);
}

void InterfaceRequisition::afficherPagePriorite() {
    ui->stackedWidget->setCurrentWidget(ui->pagePriorite);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherPriorite(processus, totalTimeSlots);
}
void InterfaceRequisition::afficherPagePCTE() {
    ui->stackedWidget->setCurrentWidget(ui->pagePCTE);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherPCTE(processus, totalTimeSlots);
}
void InterfaceRequisition::afficherPagePCTER() {
    ui->stackedWidget->setCurrentWidget(ui->pagePCTER);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherPCTER(processus, totalTimeSlots);
}
void InterfaceRequisition::afficherPageRecapitulatif() {
    ui->stackedWidget->setCurrentWidget(ui->pageRecapitulatif);

    // Remplir le tableau avec les données calculées pour les temps d'attente et de réponse
    remplirTableauRecapitulatif();
    tracerGraphiqueRecapitulatif();
}
void InterfaceRequisition::afficherPageFIFO_ES() {
    ui->stackedWidget->setCurrentWidget(ui->pageFIFO);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus3.csv";
    QVector<Processus_es> processus;

    try {
        processus = ChargeurCSV2::chargerProcessusDepuisCSV2(cheminFichier);
    } catch (const std::exception& e) {
        QMessageBox::critical(this, "Erreur", "Impossible de charger le fichier CSV : " + QString::fromStdString(e.what()));
        return;
    }

    if (processus.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Le fichier CSV est vide ou invalide.");
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherFIFO_ES(processus, totalTimeSlots);
}
void InterfaceRequisition::chargerEtAfficherFCFS(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    int tempsCourant = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        Processus p = processus[i];

        // Avancer le temps si le processus arrive après le temps courant
        if (p.getDateArrivee() > tempsCourant) {
            tempsCourant = p.getDateArrivee();
        }

        // Marquer l'état "Prêt" avant l'exécution
        for (int t = p.getDateArrivee(); t < tempsCourant; ++t) {
            if (t < totalTimeSlots) etatsPret[i][t] = 1;
        }

        // Marquer l'état "Actif" pendant l'exécution
        for (int t = tempsCourant; t < tempsCourant + p.getDureeExecution(); ++t) {
            if (t < totalTimeSlots) etatsActif[i][t] = 1;
        }

        // Mettre à jour le temps courant
        tempsCourant += p.getDureeExecution();
    }

    // Nettoyer l'ancienne scène
    sceneFCFS->clear();

    // Dessiner le chronogramme
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        sceneFCFS->addText("P" + QString::number(processus[i].getId()))
        ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        sceneFCFS->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight);
        sceneFCFS->addText("Actif")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);

        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = sceneFCFS->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
            pauseChrono(5);

            QGraphicsRectItem* rectActif = sceneFCFS->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }

    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = sceneFCFS->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}


void InterfaceRequisition::chargerEtAfficherTourniquet(const QVector<Processus>& processus, int totalTimeSlots, int quantum) {
    int nombreDeProcessus = processus.size();
    int** etatsElu = new int*[nombreDeProcessus];
    int** etatsPret = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsElu[i] = new int[totalTimeSlots]();
        etatsPret[i] = new int[totalTimeSlots]();
    }

    QVector<Processus> fileAttente = processus; // File des processus par ordre d’arrivée
    QVector<Processus> filePret;                // File des processus prêts
    int tempsCourant = 0;

    while (tempsCourant < totalTimeSlots) {
        // Déplacer les processus arrivés dans la file "Prêt"
        while (!fileAttente.isEmpty() && fileAttente.front().getDateArrivee() <= tempsCourant) {
            filePret.push_back(fileAttente.front());
            fileAttente.pop_front();
        }

        if (filePret.isEmpty()) {
            // Si aucun processus n'est prêt, avancer le temps
            tempsCourant++;
            continue;
        }

        // Sélectionner le premier processus de la file "Prêt" pour exécution
        Processus p = filePret.front();
        filePret.pop_front();

        // Marquer les processus restants dans la file comme "Prêt"
        for (const Processus& procPret : filePret) {
            for (int t = tempsCourant; t < tempsCourant + quantum && t < totalTimeSlots; ++t) {
                etatsPret[procPret.getId() - 1][t] = 1;
            }
        }

        // Exécuter le processus sélectionné et marquer comme "Élu"
        int dureeExecution = std::min(quantum, p.getTempsRestant());
        for (int t = tempsCourant; t < tempsCourant + dureeExecution && t < totalTimeSlots; ++t) {
            etatsElu[p.getId() - 1][t] = 1;
        }

        // Mettre à jour le temps courant et le temps restant du processus
        tempsCourant += dureeExecution;
        p.setTempsRestant(p.getTempsRestant() - dureeExecution);

        // Si le processus n’est pas terminé, le remettre dans la file "Prêt"
        if (p.getTempsRestant() > 0) {
            filePret.push_back(p);
        }
    }

    // Nettoyer l'ancienne scène
    sceneTourniquet->clear();

    // Dessiner le chronogramme
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        sceneTourniquet->addText("P" + QString::number(processus[i].getId()))
        ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        sceneTourniquet->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);
        sceneTourniquet->addText("Élu")->setPos(50, yOffset + i * 3 * cellHeight + 2 * cellHeight);

        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = sceneTourniquet->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);

            QGraphicsRectItem* rectElu = sceneTourniquet->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + 2 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectElu->setBrush(etatsElu[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }


    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = sceneTourniquet->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsElu[i];
        delete[] etatsPret[i];
    }
    delete[] etatsElu;
    delete[] etatsPret;
}


void InterfaceRequisition::chargerEtAfficherPriorite(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();

    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }

    QVector<Processus> fileLocale = processus;
    int tempsCourant = 0;

    while (tempsCourant < totalTimeSlots) {
        // Trouver le processus prêt avec la plus haute priorité
        int indexElu = -1;
        int prioriteMax = INT_MAX;

        for (int i = 0; i < nombreDeProcessus; ++i) {
            if (fileLocale[i].getTempsRestant() > 0 && fileLocale[i].getDateArrivee() <= tempsCourant) {
                if (fileLocale[i].getPriorite() < prioriteMax) {
                    prioriteMax = fileLocale[i].getPriorite();
                    indexElu = i;
                }
            }
        }

        // Si aucun processus n'est prêt, avancer le temps
        if (indexElu == -1) {
            tempsCourant++;
            continue;
        }

        // Marquer les états "Élu" pour le processus sélectionné
        etatsElu[indexElu][tempsCourant] = 1;

        // Marquer les états "Prêt" pour les autres processus
        for (int i = 0; i < nombreDeProcessus; ++i) {
            if (i != indexElu && fileLocale[i].getTempsRestant() > 0 && fileLocale[i].getDateArrivee() <= tempsCourant) {
                etatsPret[i][tempsCourant] = 1;
            }
        }

        // Réduire le temps restant du processus élu
        fileLocale[indexElu].setTempsRestant(fileLocale[indexElu].getTempsRestant() - 1);

        // Passer au slot de temps suivant
        tempsCourant++;
    }

    // Nettoyer l'ancienne scène
    scenePriorite->clear();

    // Dessiner le chronogramme
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        scenePriorite->addText("P" + QString::number(processus[i].getId()))
        ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        scenePriorite->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);
        scenePriorite->addText("Élu")->setPos(50, yOffset + i * 3 * cellHeight + 2 * cellHeight);

        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = scenePriorite->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);

            QGraphicsRectItem* rectElu = scenePriorite->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + 2 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectElu->setBrush(etatsElu[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }

    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = scenePriorite->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }

    delete[] etatsPret;
    delete[] etatsElu;
}

void InterfaceRequisition::chargerEtAfficherPCTE(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();

    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {

        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }


    PCTE pcte(nombreDeProcessus);
    pcte.chargerProcessus(processus);
    pcte.calculerEtatsInterface2(etatsPret, etatsElu, totalTimeSlots);

    // Nettoyer l'ancienne scène
    scenePCTE->clear();

    // Dessiner le chronogramme pour PCTE
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        // Ajouter l'étiquette du processus
        scenePCTE->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // Ajouter les étiquettes "Prêt", "Élu"
        scenePCTE->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);
        scenePCTE->addText("Élu")->setPos(50, yOffset + i * 3 * cellHeight + 2 * cellHeight);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = scenePCTE->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);
        }

        // Dessiner les états "Élu"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectElu = scenePCTE->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + 2 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectElu->setBrush(etatsElu[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }

    // Ajouter une ligne de temps en bas
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = scenePCTE->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {

        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }

    delete[] etatsPret;
    delete[] etatsElu;
}
void InterfaceRequisition::chargerEtAfficherPCTER(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();

    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }

    // Initialiser l'algorithme PCTER et calculer les états
    PCTER pcter(nombreDeProcessus);
    pcter.chargerProcessus(processus);
    pcter.calculerEtatsPCTER(etatsPret, etatsElu, totalTimeSlots);

    // Nettoyer l'ancienne scène
    scenePCTER->clear();

    // Dessiner le chronogramme pour PCTER
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        // Ajouter l'étiquette du processus
        scenePCTER->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // Ajouter les étiquettes "Prêt" et "Élu"
        scenePCTER->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);
        scenePCTER->addText("Élu")->setPos(50, yOffset + i * 3 * cellHeight + 2 * cellHeight);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = scenePCTER->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);
        }

        // Dessiner les états "Élu"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectElu = scenePCTER->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + 2 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectElu->setBrush(etatsElu[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }

    // Ajouter une ligne de temps en bas
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = scenePCTER->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }

    delete[] etatsPret;
    delete[] etatsElu;
}
void InterfaceRequisition::remplirTableauRecapitulatif() {
    // Charger les processus depuis le fichier CSV
    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int nombreDeProcessus = processus.size();
    if (nombreDeProcessus == 0) {
        qDebug() << "Aucun processus à afficher dans le tableau récapitulatif.";
        return;
    }

    // Préparer le tableau
    ui->tableWidgetRecapitulatif->setRowCount(nombreDeProcessus + 1); // +1 pour les moyennes
    ui->tableWidgetRecapitulatif->setColumnCount(14); // 1 pour le numéro de processus + 2*5 pour les algorithmes
    ui->tableWidgetRecapitulatif->setHorizontalHeaderLabels({
        "Processus", "Date d'arrivée", "Durée d'exécution", "Priorité",
        "FCFS:t_att", "FCFS:t_rep",
        "Tourniquet:t_att", "Tourniquet:t_rep",
        "Priorité:t_att", "Priorité:t_rep",
        "PCTE:t_att", "PCTE:t_rep",
        "PCTER:t_att", "PCTER:t_rep"
    });

    QVector<int> fcfsTempsAttente, fcfsTempsReponse;
    QVector<int> tourniquetTempsAttente, tourniquetTempsReponse;
    QVector<int> prioriteTempsAttente, prioriteTempsReponse;
    QVector<int> pcteTempsAttente, pcteTempsReponse;
    QVector<int> pcterTempsAttente, pcterTempsReponse;

    // Calculer les temps pour chaque algorithme
    calculerFCFS(processus, fcfsTempsAttente, fcfsTempsReponse);
    calculerTourniquet(processus, tourniquetTempsAttente, tourniquetTempsReponse, 2);
    calculerPriorite(processus, prioriteTempsAttente, prioriteTempsReponse);
    calculerPCTE(processus, pcteTempsAttente, pcteTempsReponse);
    calculerPCTER(processus, pcterTempsAttente, pcterTempsReponse); // Appel de la nouvelle méthode pour PCTER

    // Remplir le tableau
    double moyenneAttenteFCFS = 0, moyenneReponseFCFS = 0;
    double moyenneAttenteTourniquet = 0, moyenneReponseTourniquet = 0;
    double moyenneAttentePriorite = 0, moyenneReponsePriorite = 0;
    double moyenneAttentePCTE = 0, moyenneReponsePCTE = 0;
    double moyenneAttentePCTER = 0, moyenneReponsePCTER = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        const Processus& p = processus[i];

        // Remplir les colonnes "Date d'arrivée", "Durée d'exécution", et "Priorité"
        ui->tableWidgetRecapitulatif->setItem(i, 0, new QTableWidgetItem("P" + QString::number(p.getId())));
        ui->tableWidgetRecapitulatif->setItem(i, 1, new QTableWidgetItem(QString::number(p.getDateArrivee())));
        ui->tableWidgetRecapitulatif->setItem(i, 2, new QTableWidgetItem(QString::number(p.getDureeExecution())));
        ui->tableWidgetRecapitulatif->setItem(i, 3, new QTableWidgetItem(QString::number(p.getPriorite())));

        ui->tableWidgetRecapitulatif->setItem(i, 4, new QTableWidgetItem(QString::number(fcfsTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 5, new QTableWidgetItem(QString::number(fcfsTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 6, new QTableWidgetItem(QString::number(tourniquetTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 7, new QTableWidgetItem(QString::number(tourniquetTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 8, new QTableWidgetItem(QString::number(prioriteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 9, new QTableWidgetItem(QString::number(prioriteTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 10, new QTableWidgetItem(QString::number(pcteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 11, new QTableWidgetItem(QString::number(pcteTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 12, new QTableWidgetItem(QString::number(pcterTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 13, new QTableWidgetItem(QString::number(pcterTempsReponse[i])));

        moyenneAttenteFCFS += fcfsTempsAttente[i];
        moyenneReponseFCFS += fcfsTempsReponse[i];
        moyenneAttenteTourniquet += tourniquetTempsAttente[i];
        moyenneReponseTourniquet += tourniquetTempsReponse[i];
        moyenneAttentePriorite += prioriteTempsAttente[i];
        moyenneReponsePriorite += prioriteTempsReponse[i];
        moyenneAttentePCTE += pcteTempsAttente[i];
        moyenneReponsePCTE += pcteTempsReponse[i];
        moyenneAttentePCTER += pcterTempsAttente[i];
        moyenneReponsePCTER += pcterTempsReponse[i];
    }

    // Calcul des moyennes
    moyenneAttenteFCFS /= nombreDeProcessus;
    moyenneReponseFCFS /= nombreDeProcessus;
    moyenneAttenteTourniquet /= nombreDeProcessus;
    moyenneReponseTourniquet /= nombreDeProcessus;
    moyenneAttentePriorite /= nombreDeProcessus;
    moyenneReponsePriorite /= nombreDeProcessus;
    moyenneAttentePCTE /= nombreDeProcessus;
    moyenneReponsePCTE /= nombreDeProcessus;
    moyenneAttentePCTER /= nombreDeProcessus;
    moyenneReponsePCTER /= nombreDeProcessus;

    int lastRow = nombreDeProcessus;
    ui->tableWidgetRecapitulatif->setItem(lastRow, 3, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 4, new QTableWidgetItem(QString::number(moyenneAttenteFCFS, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 5, new QTableWidgetItem(QString::number(moyenneReponseFCFS, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 6, new QTableWidgetItem(QString::number(moyenneAttenteTourniquet, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 7, new QTableWidgetItem(QString::number(moyenneReponseTourniquet, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 8, new QTableWidgetItem(QString::number(moyenneAttentePriorite, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 9, new QTableWidgetItem(QString::number(moyenneReponsePriorite, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 10, new QTableWidgetItem(QString::number(moyenneAttentePCTE, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 11, new QTableWidgetItem(QString::number(moyenneReponsePCTE, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 12, new QTableWidgetItem(QString::number(moyenneAttentePCTER, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 13, new QTableWidgetItem(QString::number(moyenneReponsePCTER, 'f', 2)));

    double tempsMin = std::min({moyenneAttenteFCFS, moyenneAttenteTourniquet, moyenneAttentePriorite, moyenneAttentePCTE, moyenneAttentePCTER});

    ui->textEditConclusion->setPlainText("Le temps moyen d'attente minimal est : " + QString::number(tempsMin, 'f', 2));
    ui->textEditConclusion->append("\nConclusion :\n"
                                   "L'algorithme PCTER montre un temps d'attente minimal de " + QString::number(tempsMin) +" "
                                                                 "Cela suggère que,cet algorithme optimise efficacement le temps d'attente .\n");
}
void InterfaceRequisition::calculerFCFS(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50;
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }
    FCFS fcfs(nombreDeProcessus);
    fcfs.chargerProcessus(processus);
    fcfs.ajouterFile();
    fcfs.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;
            if (etatsActif[i][t] == 1) reponse = t + 1;
        }
        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}
void InterfaceRequisition::calculerTourniquet(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse, int quantum) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50;
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    Tourniquet tourniquet(nombreDeProcessus, quantum);
    tourniquet.chargerProcessus(processus);
    tourniquet.executionProcessus();
    tourniquet.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;
            if (etatsActif[i][t] == 1) reponse = t + 1;
        }
        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}
void InterfaceRequisition::calculerPriorite(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50;
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }

    // Initialiser la file locale pour gérer les processus
    QVector<Processus> fileLocale;
    QVector<Processus> processusRestants = processus;
    int tempsCourant = 0;

    while (tempsCourant < totalTimeSlots || !fileLocale.isEmpty()) {
        // Ajouter les processus arrivés au temps courant à la file locale
        for (int i = 0; i < processusRestants.size(); ++i) {
            if (processusRestants[i].getDateArrivee() <= tempsCourant) {
                fileLocale.append(processusRestants[i]);
                processusRestants.removeAt(i);
                --i;
            }
        }

        // Trier la file locale selon la priorité (priorité plus grande = valeur plus basse)
        std::sort(fileLocale.begin(), fileLocale.end(), [](const Processus& a, const Processus& b) {
            return a.getPriorite() < b.getPriorite();
        });

        if (!fileLocale.isEmpty()) {
            // Sélectionner le processus avec la plus haute priorité
            Processus& p = fileLocale.front();

            // Marquer l'état "Élu" pour le processus pendant une unité de temps
            etatsElu[p.getId() - 1][tempsCourant] = 1;

            // Diminuer le temps restant du processus
            p.setTempsRestant(p.getTempsRestant() - 1);

            // Si le processus est terminé, enregistrer son temps de fin et le retirer de la file
            if (p.getTempsRestant() == 0) {
                p.setDateDeFin(tempsCourant + 1);
                fileLocale.pop_front();
            }
        }

        // Marquer les processus restants dans la file comme "Prêt"
        for (int i = 1; i < fileLocale.size(); ++i) {
            etatsPret[fileLocale[i].getId() - 1][tempsCourant] = 1;
        }

        // Avancer le temps
        tempsCourant++;
    }

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0;
        int tempsFin = 0;

        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;  // Compter les cases "Prêt"
            if (etatsElu[i][t] == 1) tempsFin = t + 1;  // Trouver la dernière case "Élu"
        }

        int reponse = tempsFin - processus[i].getDateArrivee();  // Calculer le temps de réponse

        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }
    delete[] etatsPret;
    delete[] etatsElu;
}


void InterfaceRequisition::calculerPCTE(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50;
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }


    PCTE pcte(nombreDeProcessus);
    pcte.chargerProcessus(processus);
    pcte.calculerEtatsInterface2(etatsPret, etatsElu, totalTimeSlots);


    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;
            if (etatsElu[i][t] == 1) reponse = t + 1;
        }
        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }
    delete[] etatsPret;
    delete[] etatsElu;
}
void InterfaceRequisition::calculerPCTER(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50;
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsElu = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsElu[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer les états PCTER
    PCTER pcter(nombreDeProcessus);
    pcter.chargerProcessus(processus);
    pcter.calculerEtatsPCTER(etatsPret, etatsElu, totalTimeSlots);

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;
            if (etatsElu[i][t] == 1) reponse = t + 1;
        }
        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsElu[i];
    }
    delete[] etatsPret;
    delete[] etatsElu;
}
void InterfaceRequisition::tracerGraphiqueRecapitulatif(){
    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus2.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int nombreDeProcessus = processus.size();
    if (nombreDeProcessus == 0) {
        qDebug() << "Aucun processus à afficher dans le tableau récapitulatif.";
        return;
    }


    QVector<int> fcfsTempsAttente, fcfsTempsReponse;
    QVector<int> tourniquetTempsAttente, tourniquetTempsReponse;
    QVector<int> prioriteTempsAttente, prioriteTempsReponse;
    QVector<int> pcteTempsAttente, pcteTempsReponse;
    QVector<int> pcterTempsAttente, pcterTempsReponse;

    calculerFCFS(processus, fcfsTempsAttente, fcfsTempsReponse);
    calculerTourniquet(processus, tourniquetTempsAttente, tourniquetTempsReponse, 2);
    calculerPriorite(processus, prioriteTempsAttente, prioriteTempsReponse);
    calculerPCTE(processus, pcteTempsAttente, pcteTempsReponse);
    calculerPCTER(processus, pcterTempsAttente, pcterTempsReponse);

    // Remplir le tableau
    double moyenneAttenteFCFS = 0;
    double moyenneAttenteTourniquet = 0;
    double moyenneAttentePriorite = 0;
    double moyenneAttentePCTE = 0;
    double moyenneAttentePCTER = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        const Processus& p = processus[i];

        // Remplir les colonnes "Date d'arrivée", "Durée d'exécution", et "Priorité"
        ui->tableWidgetRecapitulatif->setItem(i, 0, new QTableWidgetItem("P" + QString::number(p.getId())));
        ui->tableWidgetRecapitulatif->setItem(i, 1, new QTableWidgetItem(QString::number(p.getDateArrivee())));
        ui->tableWidgetRecapitulatif->setItem(i, 2, new QTableWidgetItem(QString::number(p.getDureeExecution())));
        ui->tableWidgetRecapitulatif->setItem(i, 3, new QTableWidgetItem(QString::number(p.getPriorite())));

        ui->tableWidgetRecapitulatif->setItem(i, 4, new QTableWidgetItem(QString::number(fcfsTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 6, new QTableWidgetItem(QString::number(tourniquetTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 8, new QTableWidgetItem(QString::number(prioriteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 10, new QTableWidgetItem(QString::number(pcteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 12, new QTableWidgetItem(QString::number(pcterTempsAttente[i])));

        moyenneAttenteFCFS += fcfsTempsAttente[i];
        moyenneAttenteTourniquet += tourniquetTempsAttente[i];
        moyenneAttentePriorite += prioriteTempsAttente[i];
        moyenneAttentePCTE += pcteTempsAttente[i];
        moyenneAttentePCTER += pcterTempsAttente[i];
    }

    // Calcul des moyennes
    moyenneAttenteFCFS /= nombreDeProcessus;
    moyenneAttenteTourniquet /= nombreDeProcessus;
    moyenneAttentePriorite /= nombreDeProcessus;
    moyenneAttentePCTE /= nombreDeProcessus;
    moyenneAttentePCTER /= nombreDeProcessus;

    QVector<double> moyennesTempsAttente = {
        moyenneAttenteFCFS,
        moyenneAttenteTourniquet,
        moyenneAttentePriorite,
        moyenneAttentePCTE,
        moyenneAttentePCTER
    };

    // Les noms des algorithmes
    QStringList categories = {"FCFS", "Tourniquet", "Priorité", "PCTE", "PCTER"};

    // Créer un ensemble de barres pour les moyennes
    QBarSet *set = new QBarSet("Temps Moyen d'Attente");
    for (double moyenne : moyennesTempsAttente) {
        *set << moyenne;
    }

    // Ajouter l'ensemble à une série
    QBarSeries *series = new QBarSeries();
    series->append(set);

    // Créer un objet QChart et ajouter la série
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Temps Moyen d'Attente par Algorithme");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // Configurer l'axe des catégories (X)
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // Configurer l'axe des valeurs (Y)
    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, *std::max_element(moyennesTempsAttente.begin(), moyennesTempsAttente.end()) + 1);
    axisY->setTitleText("Temps Moyen d'Attente (ms)");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    // Créer une vue pour afficher le graphique
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(chartView);
    QWidget *graphWidget = new QWidget();
    graphWidget->setLayout(layout);
    graphWidget->setWindowTitle("Courbe_Récapitulatif");
    graphWidget->resize(600, 400);
    graphWidget->show();
}
void InterfaceRequisition::chargerEtAfficherFIFO_ES(const QVector<Processus_es>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();

    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];
    int** etatsBloque = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
        etatsBloque[i] = new int[totalTimeSlots]();
    }

    FCFS fcfs(nombreDeProcessus);
    //fcfs.chargerProcessus(processus);
    //fcfs.ajouterFile();
    fcfs.calculerEtatsES(etatsPret, etatsActif, etatsBloque, totalTimeSlots);

    sceneFIFO_ES->clear();
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        sceneFIFO_ES->addText("P" + QString::number(i + 1))->setPos(10, yOffset + i * 4 * cellHeight - cellHeight / 2);

        sceneFIFO_ES->addText("Prêt")->setPos(50, yOffset + i * 4 * cellHeight);
        sceneFIFO_ES->addText("Actif")->setPos(50, yOffset + i * 4 * cellHeight + cellHeight);
        sceneFIFO_ES->addText("Bloqué")->setPos(50, yOffset + i * 4 * cellHeight + 2 * cellHeight);

        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = sceneFIFO_ES->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 4 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
            pauseChrono(5);

            QGraphicsRectItem* rectActif = sceneFIFO_ES->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 4 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
            pauseChrono(5);

            QGraphicsRectItem* rectBloque = sceneFIFO_ES->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 4 * cellHeight + 2 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectBloque->setBrush(etatsBloque[i][t] == 1 ? Qt::red : Qt::white);
            pauseChrono(5);
        }
    }
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = sceneFIFO_ES->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 4 * cellHeight + 5);
    }

    ui->graphicsViewFIFO_ES->setScene(sceneFIFO_ES);
}

