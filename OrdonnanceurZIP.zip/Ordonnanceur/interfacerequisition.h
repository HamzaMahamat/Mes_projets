#ifndef INTERFACEREQUISITION_H
#define INTERFACEREQUISITION_H

#include <QDialog>
#include <QGraphicsScene>
#include <QVector>
#include<QTimer>
#include "Processus.h"
#include "Processus_es.h"
#include "Tourniquet.h"
#include "Priorite.h"
#include "PCTE.h"
#include "PCTER.h"
#include "FCFS.h"

QT_BEGIN_NAMESPACE
namespace Ui { class InterfaceRequisition; }
QT_END_NAMESPACE

class InterfaceRequisition : public QDialog {
    Q_OBJECT

public:
    explicit InterfaceRequisition(QWidget *parent = nullptr);
    ~InterfaceRequisition();

private slots:
    void afficherPageTourniquet();
    void afficherPagePriorite();
    void afficherPagePCTE();
    void afficherPageFCFS();
    void afficherPagePCTER();
    void afficherPageRecapitulatif();
    void afficherPageFIFO_ES();

private:
    Ui::InterfaceRequisition *ui;
    QGraphicsScene* sceneTourniquet;
    QGraphicsScene* scenePriorite;
    QGraphicsScene* scenePCTE;
    QGraphicsScene* sceneFCFS;
    QGraphicsScene* sceneFIFO_ES;
    QGraphicsScene* scenePCTER;
    QTimer top;

    QVector<Processus> chargerProcessusDepuisCSV(const QString& cheminFichier);
    QVector<Processus_es> chargerProcessusDepuisCSV2(const QString& cheminFichier);
    void chargerEtAfficherFCFS(const QVector<Processus>& processus, int totalTimeSlots);
    void chargerEtAfficherTourniquet(const QVector<Processus>& processus, int totalTimeSlots, int quantum);
    void chargerEtAfficherPriorite(const QVector<Processus>& processus, int totalTimeSlots);
    void remplirTableauRecapitulatif();
    void chargerEtAfficherPCTE(const QVector<Processus>& processus, int totalTimeSlots);
    void chargerEtAfficherPCTER(const QVector<Processus>& processus, int totalTimeSlots);
    void calculerEtatsTourniquet(const QVector<Processus>& processus, int** etatsAttente, int** etatsPret, int** etatsElu, int totalTimeSlots, int quantum);
    void calculerEtatsPriorite(const QVector<Processus>& processus, int** etatsAttente, int** etatsPret, int** etatsElu, int totalTimeSlots);
    void calculerFCFS(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void calculerTourniquet(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse, int quantum);
    void calculerPriorite(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void calculerPCTE(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void calculerPCTER(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void pauseChrono(int temps);
    void tracerGraphiqueRecapitulatif();
    void chargerEtAfficherFIFO_ES(const QVector<Processus_es>& processus, int totalTimeSlots);
};

#endif // INTERFACEREQUISITION_H
