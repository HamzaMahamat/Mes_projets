#include "MainWindow.h"
#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    MainWindow w;
    w.setWindowTitle("Simulation d'Algorithmes");
    w.resize(800, 600);
    w.show();

    return app.exec();
}
