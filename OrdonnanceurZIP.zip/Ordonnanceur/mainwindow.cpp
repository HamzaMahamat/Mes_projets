#include "mainwindow.h"
#include "interfacerequisition.h"
#include "ui_mainwindow.h"
#include "ChargeurCSV.h"
#include <QGraphicsScene>
#include <QMessageBox>

#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QCategoryAxis>

#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QValueAxis>
#include <QtCharts/QBarCategoryAxis>

#include <QGraphicsTextItem>
#include <QGraphicsRectItem>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    sceneFCFS(new QGraphicsScene(this)),
    sceneTourniquet(new QGraphicsScene(this)),
    scenePriorite(new QGraphicsScene(this)),
    scenePCTE(new QGraphicsScene(this)) // Scène pour PCTE
{
    qApp->setStyleSheet("QWidget { background-color: #E0FFFF; color: black; }");


    ui->setupUi(this);

    // Associer les scènes aux GraphicsView
    ui->graphicsViewFCFS->setScene(sceneFCFS);
    ui->graphicsViewTourniquet->setScene(sceneTourniquet);
    ui->graphicsViewPriorite->setScene(scenePriorite);
    ui->graphicsViewPCTE->setScene(scenePCTE); // Vue pour PCTE

    // Connecter les actions du menu
    connect(ui->actionFCFS, &QAction::triggered, this, &MainWindow::afficherPageFCFS);
    connect(ui->actionTourniquet, &QAction::triggered, this, &MainWindow::afficherPageTourniquet);
    connect(ui->actionPriorite, &QAction::triggered, this, &MainWindow::afficherPagePriorite);
    connect(ui->actionPCTE, &QAction::triggered, this, &MainWindow::afficherPagePCTE); // Action pour PCTE
    connect(ui->actionRecapitulatif, &QAction::triggered, this, &MainWindow::afficherPageRecapitulatif);
    connect(ui->actionRequisition, &QAction::triggered, this, &MainWindow::ouvrirInterfaceRequisition);
    connect(ui->actionQuitter, &QAction::triggered, QApplication::quit);

}

MainWindow::~MainWindow() {
    delete ui;
}
void MainWindow::pauseChrono(int temps){
    top.setSingleShot(true);
    top.start(temps);
    while(top.isActive()){
        QApplication::processEvents();
    }
}
void MainWindow::ouvrirInterfaceRequisition() {
    InterfaceRequisition *requisitionDialog = new InterfaceRequisition(this);
    requisitionDialog->show();
}

void MainWindow::afficherPageFCFS() {
    ui->stackedWidget->setCurrentWidget(ui->pageFCFS);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);


    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherFCFS(processus, totalTimeSlots);
}
void MainWindow::afficherPageTourniquet() {
    ui->stackedWidget->setCurrentWidget(ui->pageTourniquet);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);


    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int totalTimeSlots = 50;
    int quantum = 1;
    chargerEtAfficherTourniquet(processus, totalTimeSlots, quantum);
}
void MainWindow::afficherPagePriorite() {
    ui->stackedWidget->setCurrentWidget(ui->pagePriorite);

    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);


    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int totalTimeSlots = 50;
    chargerEtAfficherPriorite(processus, totalTimeSlots);
}

void MainWindow::chargerEtAfficherFCFS(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }


    FCFS fcfs(nombreDeProcessus);
    fcfs.chargerProcessus(processus);
    fcfs.ajouterFile();
    fcfs.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

   
    sceneFCFS->clear();

    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        sceneFCFS->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // les étiquettes "Prêt" et "Actif"
        sceneFCFS->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight);
        sceneFCFS->addText("Actif")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);

        // les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = sceneFCFS->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
            pauseChrono(5);
        }

        //les états "Actif"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectActif = sceneFCFS->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
            pauseChrono(5);
        }
    }
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = sceneFCFS->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }
    int somme=0;
    // Mettre à jour la table des résultats
    ui->graphicsViewFCFS->setScene(sceneFCFS);
    int totalExecutionTime = 0;
    int totalWaitingTime = 0;
    // Remplir le tableau des résultats
    ui->tableWidgetFCFS->setRowCount(nombreDeProcessus + 1);
    ui->tableWidgetFCFS->setColumnCount(3);
    ui->tableWidgetFCFS->setHorizontalHeaderLabels({"PId", "Temps d'exécution", "Temps d'attente"});


    for (int i = 0; i < nombreDeProcessus; ++i) {
        int tempsExecution =0;
        int tempsAttente = 0;
        if(i==0){
            tempsAttente = 0;
            tempsExecution=processus[i].getDureeExecution();
        }
        else{
            tempsAttente = somme;
            tempsExecution=processus[i].getDureeExecution()+somme;
        }
        somme+=processus[i].getDureeExecution();


        totalExecutionTime += tempsExecution;
        totalWaitingTime += tempsAttente;

        ui->tableWidgetFCFS->setItem(i, 0, new QTableWidgetItem("P" + QString::number(processus[i].getId())));
        ui->tableWidgetFCFS->setItem(i, 1, new QTableWidgetItem(QString::number(tempsExecution)));
        ui->tableWidgetFCFS->setItem(i, 2, new QTableWidgetItem(QString::number(tempsAttente)));
    }

    double moyenneTempsExecution = static_cast<double>(totalExecutionTime) / nombreDeProcessus;
    double moyenneTempsAttente = static_cast<double>(totalWaitingTime) / nombreDeProcessus;

    int lastRow = nombreDeProcessus;
    ui->tableWidgetFCFS->setItem(lastRow, 0, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetFCFS->setItem(lastRow, 1, new QTableWidgetItem(QString::number(moyenneTempsExecution, 'f', 2)));
    ui->tableWidgetFCFS->setItem(lastRow, 2, new QTableWidgetItem(QString::number(moyenneTempsAttente, 'f', 2)));


    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}
void MainWindow::chargerEtAfficherTourniquet(const QVector<Processus>& processus, int totalTimeSlots, int quantum) {
    int nombreDeProcessus = processus.size();
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer l'algorithme Tourniquet
    Tourniquet tourniquet(nombreDeProcessus, quantum);
    tourniquet.chargerProcessus(processus);
    tourniquet.executionProcessus();
    tourniquet.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    // Nettoyer l'ancienne scène
    sceneTourniquet->clear();

    // Dessiner le chronogramme pour Tourniquet
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        // Ajouter l'étiquette du processus (P1, P2, etc.)
        sceneTourniquet->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // Ajouter les étiquettes "Prêt" et "Actif"
        sceneTourniquet->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight);
        sceneTourniquet->addText("Actif")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = sceneTourniquet->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);
        }

        // Dessiner les états "Actif"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectActif = sceneTourniquet->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }
    }
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = sceneTourniquet->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Calcul des temps d'attente et d'exécution
    ui->graphicsViewTourniquet->setScene(sceneTourniquet);
    int totalExecutionTime = 0;
    int totalWaitingTime = 0;

    ui->tableWidgetTourniquet->setRowCount(nombreDeProcessus + 1);
    ui->tableWidgetTourniquet->setColumnCount(3);
    ui->tableWidgetTourniquet->setHorizontalHeaderLabels({"PId", "T_Reponse", "T_Attente"});

    for (int i = 0; i < nombreDeProcessus; ++i) {
        int tempsAttente = 0;
        int tempsExecution = 0;

        // Parcourir les états pour calculer les temps
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) {
                tempsAttente++;
            }
            if (etatsActif[i][t] == 1) {
                tempsExecution = t + 1; // Dernière case active
            }
        }

        totalExecutionTime += tempsExecution;
        totalWaitingTime += tempsAttente;

        // Ajouter les données au tableau
        ui->tableWidgetTourniquet->setItem(i, 0, new QTableWidgetItem("P" + QString::number(processus[i].getId())));
        ui->tableWidgetTourniquet->setItem(i, 1, new QTableWidgetItem(QString::number(tempsExecution)));
        ui->tableWidgetTourniquet->setItem(i, 2, new QTableWidgetItem(QString::number(tempsAttente)));
    }

    // Calcul des moyennes
    double moyenneTempsExecution = static_cast<double>(totalExecutionTime) / nombreDeProcessus;
    double moyenneTempsAttente = static_cast<double>(totalWaitingTime) / nombreDeProcessus;

    // Ajouter la ligne des moyennes
    int lastRow = nombreDeProcessus;
    ui->tableWidgetTourniquet->setItem(lastRow, 0, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetTourniquet->setItem(lastRow, 1, new QTableWidgetItem(QString::number(moyenneTempsExecution, 'f', 2)));
    ui->tableWidgetTourniquet->setItem(lastRow, 2, new QTableWidgetItem(QString::number(moyenneTempsAttente, 'f', 2)));

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}

void MainWindow::chargerEtAfficherPriorite(const QVector<Processus>& processus, int totalTimeSlots) {
    int nombreDeProcessus = processus.size();
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer l'algorithme Priorité
    Priorite priorite(nombreDeProcessus);
    priorite.chargerProcessus(processus);
    priorite.ajouterFile();
    priorite.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    // Nettoyer l'ancienne scène
    scenePriorite->clear();

    // Dessiner le chronogramme pour Priorité
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        // Ajouter l'étiquette du processus
        scenePriorite->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // Ajouter les étiquettes "Prêt" et "Actif"
        scenePriorite->addText("Prêt")->setPos(50, yOffset + i * 3* cellHeight);
        scenePriorite->addText("Actif")->setPos(50, yOffset + i * 3* cellHeight + cellHeight);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
                QGraphicsRectItem* rectPret = scenePriorite->addRect(
                    xOffset + t * cellWidth,
                    yOffset + i * 3 * cellHeight,
                    cellWidth,
                    cellHeight,
                    QPen(Qt::black)
                    );
                rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
                 pauseChrono(5);
        }

        // Dessiner les états "Actif"
        for (int t = 0; t < totalTimeSlots; ++t) {
                QGraphicsRectItem* rectActif = scenePriorite->addRect(
                    xOffset + t * cellWidth,
                    yOffset + i * 3 * cellHeight + cellHeight,
                    cellWidth,
                    cellHeight,
                    QPen(Qt::black)
                    );
                rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
                 pauseChrono(5);

        }
    }
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = scenePriorite->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }

    // Mettre à jour la table des résultats
    ui->tableWidgetPriorite->setRowCount(nombreDeProcessus + 1);
    ui->tableWidgetPriorite->setColumnCount(3);
    ui->tableWidgetPriorite->setHorizontalHeaderLabels({"PId", "T_eponse", "T_attente"});

    int totalExecutionTime = 0;
    int totalWaitingTime = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        int tempsAttente = 0;
        int tempsExecution = 0;

        // Calcul des temps à partir des états
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) {
                tempsAttente++;
            }
            if (etatsActif[i][t] == 1) {
                tempsExecution = t + 1; // Dernière case verte
            }
        }

        totalExecutionTime += tempsExecution;
        totalWaitingTime += tempsAttente;

        // Mise à jour du tableau
        ui->tableWidgetPriorite->setItem(i, 0, new QTableWidgetItem("P" + QString::number(processus[i].getId())));
        ui->tableWidgetPriorite->setItem(i, 1, new QTableWidgetItem(QString::number(tempsExecution)));
        ui->tableWidgetPriorite->setItem(i, 2, new QTableWidgetItem(QString::number(tempsAttente)));
    }

    double moyenneTempsExecution = static_cast<double>(totalExecutionTime) / nombreDeProcessus;
    double moyenneTempsAttente = static_cast<double>(totalWaitingTime) / nombreDeProcessus;

    int lastRow = nombreDeProcessus;
    ui->tableWidgetPriorite->setItem(lastRow, 0, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetPriorite->setItem(lastRow, 1, new QTableWidgetItem(QString::number(moyenneTempsExecution, 'f', 2)));
    ui->tableWidgetPriorite->setItem(lastRow, 2, new QTableWidgetItem(QString::number(moyenneTempsAttente, 'f', 2)));

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}


void MainWindow::calculerFCFS(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50; // Adapter selon vos besoins
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer les états FCFS
    FCFS fcfs(nombreDeProcessus);
    fcfs.chargerProcessus(processus);
    fcfs.ajouterFile();
    fcfs.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;

        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;       // Compter les cases jaunes (prêt)
            if (etatsActif[i][t] == 1) reponse = t + 1; // Trouver la dernière case verte (réponse)
        }

        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}

void MainWindow::calculerTourniquet(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse, int quantum) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50; // Adapter selon vos besoins
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer les états pour Tourniquet
    Tourniquet tourniquet(nombreDeProcessus, quantum);
    tourniquet.chargerProcessus(processus);
    tourniquet.executionProcessus();
    tourniquet.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;

        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;       // Compter les cases jaunes (prêt)
            if (etatsActif[i][t] == 1) reponse = t + 1; // Trouver la dernière case verte (réponse)
        }

        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}

void MainWindow::calculerPriorite(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50; // Adapter selon vos besoins
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer les états pour Priorité
    Priorite priorite(nombreDeProcessus);
    for (const Processus& p : processus) {
        priorite.ajoutProcessus(p);
    }
    priorite.ajouterFile();
    priorite.calculerEtats(etatsPret, etatsActif, totalTimeSlots);

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;

        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;       // Compter les cases jaunes (prêt)
            if (etatsActif[i][t] == 1) reponse = t + 1; // Trouver la dernière case verte (réponse)
        }

        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}

void MainWindow::afficherChronogrammePCTE(int** etatsPret, int** etatsActif, const QVector<Processus>& processus, int totalTimeSlots) {
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;
    int somme = 0;

    int totalExecutionTime = 0;
    int totalWaitingTime = 0;

    // Préparer le tableau
    ui->tableWidgetPCTE->setRowCount(processus.size() + 1); // +1 pour la ligne des moyennes
    ui->tableWidgetPCTE->setColumnCount(3); // 3 colonnes : PId, Temps d'exécution, Temps d'attente
    ui->tableWidgetPCTE->setHorizontalHeaderLabels({"PId", "Temps d'exécution", "Temps d'attente"});

    for (int i = 0; i < processus.size(); ++i) {
        // Dessiner le titre pour chaque processus
        scenePCTE->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight + cellHeight / 2);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = scenePCTE->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);
             pauseChrono(5);
        }

        // Dessiner les états "Actif"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectActif = scenePCTE->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);
             pauseChrono(5);
        }

        // Calculer les temps pour chaque processus
        int tempsExecution =0;
        int tempsAttente = 0;
        if(i==0){
            tempsAttente = 0;
            tempsExecution=processus[i].getDureeExecution();
        }
        else{
            tempsAttente = somme;
            tempsExecution=processus[i].getDureeExecution()+somme;
        }
        somme+=processus[i].getDureeExecution();


        totalExecutionTime += tempsExecution;
        totalWaitingTime += tempsAttente;


        // Ajouter les données dans le tableau
        ui->tableWidgetPCTE->setItem(i, 0, new QTableWidgetItem("P" + QString::number(processus[i].getId()))); // PId
        ui->tableWidgetPCTE->setItem(i, 1, new QTableWidgetItem(QString::number(tempsExecution)));            // Temps d'exécution
        ui->tableWidgetPCTE->setItem(i, 2, new QTableWidgetItem(QString::number(tempsAttente)));              // Temps d'attente
    }

    // Calculer et afficher les moyennes
    int nombreProcessus = processus.size();
    double moyenneTempsExecution = static_cast<double>(totalExecutionTime) / nombreProcessus;
    double moyenneTempsAttente = static_cast<double>(totalWaitingTime) / nombreProcessus;

    // Ajouter la ligne pour les moyennes
    ui->tableWidgetPCTE->setItem(nombreProcessus, 0, new QTableWidgetItem("Moyenne"));                       // Moyenne (label)
    ui->tableWidgetPCTE->setItem(nombreProcessus, 1, new QTableWidgetItem(QString::number(moyenneTempsExecution, 'f', 2))); // Moyenne temps d'exécution
    ui->tableWidgetPCTE->setItem(nombreProcessus, 2, new QTableWidgetItem(QString::number(moyenneTempsAttente, 'f', 2)));   // Moyenne temps d'attente
}
void MainWindow::afficherPagePCTE() {
    ui->stackedWidget->setCurrentWidget(ui->pagePCTE); // Afficher la page PCTE
    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        QMessageBox::critical(this, "Erreur", "Le fichier CSV est vide ou invalide.");
        return;
    }

    std::sort(processus.begin(), processus.end(), [](const Processus& a, const Processus& b) {
        return a.getDureeExecution() <= b.getDureeExecution();
    });

    int totalTimeSlots = 50;
    int nombreDeProcessus = processus.size();
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    PCTE pcte(nombreDeProcessus);
    pcte.chargerProcessus(processus);
    pcte.ajouterFile();
    pcte.calculerEtatsPCTE(etatsPret, etatsActif, totalTimeSlots);

    // Afficher le chronogramme sur graphicsViewPCTE
    QGraphicsScene* scene = new QGraphicsScene(this);
    int cellWidth = 20;
    int cellHeight = 20;
    int xOffset = 100;
    int yOffset = 50;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        // Ajouter les étiquettes des processus
        scene->addText("P" + QString::number(processus[i].getId()))
            ->setPos(10, yOffset + i * 3 * cellHeight - cellHeight / 2);

        // Ajouter les étiquettes "Prêt" et "Actif"
        scene->addText("Prêt")->setPos(50, yOffset + i * 3 * cellHeight);
        scene->addText("Actif")->setPos(50, yOffset + i * 3 * cellHeight + cellHeight);

        // Dessiner les états "Prêt"
        for (int t = 0; t < totalTimeSlots; ++t) {
            QGraphicsRectItem* rectPret = scene->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectPret->setBrush(etatsPret[i][t] == 1 ? Qt::yellow : Qt::white);

            QGraphicsRectItem* rectActif = scene->addRect(
                xOffset + t * cellWidth,
                yOffset + i * 3 * cellHeight + cellHeight,
                cellWidth,
                cellHeight,
                QPen(Qt::black)
                );
            rectActif->setBrush(etatsActif[i][t] == 1 ? Qt::green : Qt::white);

        }
    }
    // Ajouter les étiquettes de temps en bas du chronogramme
    for (int t = 0; t < totalTimeSlots; ++t) {
        QGraphicsTextItem* textItem = scene->addText(QString::number(t));
        textItem->setPos(xOffset + t * cellWidth + cellWidth / 4, yOffset + nombreDeProcessus * 3 * cellHeight + 5);
    }


    ui->graphicsViewPCTE->setScene(scene);

    // Remplir le tableau des résultats
    int totalExecutionTime = 0;
    int totalWaitingTime = 0;
    ui->tableWidgetPCTE->setRowCount(nombreDeProcessus + 1);
    ui->tableWidgetPCTE->setColumnCount(3);
    ui->tableWidgetPCTE->setHorizontalHeaderLabels({"PId", "Temps d'exécution", "Temps d'attente"});

    for (int i = 0; i < nombreDeProcessus; ++i) {
        int tempsExecution = 0;
        int tempsAttente = 0;

        // Calculer les temps d'exécution et d'attente à partir des états
        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) tempsAttente++;
            if (etatsActif[i][t] == 1) tempsExecution = t + 1;
        }

        totalExecutionTime += tempsExecution;
        totalWaitingTime += tempsAttente;

        ui->tableWidgetPCTE->setItem(i, 0, new QTableWidgetItem("P" + QString::number(processus[i].getId())));
        ui->tableWidgetPCTE->setItem(i, 1, new QTableWidgetItem(QString::number(tempsExecution)));
        ui->tableWidgetPCTE->setItem(i, 2, new QTableWidgetItem(QString::number(tempsAttente)));
    }

    double moyenneTempsExecution = static_cast<double>(totalExecutionTime) / nombreDeProcessus;
    double moyenneTempsAttente = static_cast<double>(totalWaitingTime) / nombreDeProcessus;

    int lastRow = nombreDeProcessus;
    ui->tableWidgetPCTE->setItem(lastRow, 0, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetPCTE->setItem(lastRow, 1, new QTableWidgetItem(QString::number(moyenneTempsExecution, 'f', 2)));
    ui->tableWidgetPCTE->setItem(lastRow, 2, new QTableWidgetItem(QString::number(moyenneTempsAttente, 'f', 2)));

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}

void MainWindow::calculerPCTE(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse) {
    int nombreDeProcessus = processus.size();
    int totalTimeSlots = 50; // Adapter selon vos besoins
    int** etatsPret = new int*[nombreDeProcessus];
    int** etatsActif = new int*[nombreDeProcessus];

    for (int i = 0; i < nombreDeProcessus; ++i) {
        etatsPret[i] = new int[totalTimeSlots]();
        etatsActif[i] = new int[totalTimeSlots]();
    }

    // Initialiser et calculer les états pour PCTE
    PCTE pcte(nombreDeProcessus);
    pcte.chargerProcessus(processus);
    pcte.ajouterFile();
    pcte.calculerEtatsPCTE(etatsPret, etatsActif, totalTimeSlots);

    // Calculer les temps d'attente et de réponse
    for (int i = 0; i < nombreDeProcessus; ++i) {
        int attente = 0, reponse = 0;

        for (int t = 0; t < totalTimeSlots; ++t) {
            if (etatsPret[i][t] == 1) attente++;       // Compter les cases jaunes (prêt)
            if (etatsActif[i][t] == 1) reponse = t + 1; // Trouver la dernière case verte (réponse)
        }

        tempsAttente.append(attente);
        tempsReponse.append(reponse);
    }

    // Libérer la mémoire
    for (int i = 0; i < nombreDeProcessus; ++i) {
        delete[] etatsPret[i];
        delete[] etatsActif[i];
    }
    delete[] etatsPret;
    delete[] etatsActif;
}
void MainWindow::remplirTableauRecapitulatif() {
    // Charger les processus depuis le fichier CSV
    QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int nombreDeProcessus = processus.size();
    if (nombreDeProcessus == 0) {
        qDebug() << "Aucun processus à afficher dans le tableau récapitulatif.";
        return;
    }

    // Préparer le tableau
    ui->tableWidgetRecapitulatif->setRowCount(nombreDeProcessus + 1); // +1 pour les moyennes
    ui->tableWidgetRecapitulatif->setColumnCount(12); // 1 pour le numéro de processus + 2*4 pour les algorithmes
    ui->tableWidgetRecapitulatif->setHorizontalHeaderLabels({
         "Processus", "Date d'arrivée", "Durée d'exécution", "Priorité",
        "FCFS:t_att", "FCFS:t_rep",
        "Tourniquet:t_att", "Tourniquet:t_rep",
        "Priorité:t_att", "Priorité:t_rep",
        "PCTE:t_att", "PCTE:t_rep"
    });

    QVector<int> fcfsTempsAttente, fcfsTempsReponse;
    QVector<int> tourniquetTempsAttente, tourniquetTempsReponse;
    QVector<int> prioriteTempsAttente, prioriteTempsReponse;
    QVector<int> pcteTempsAttente, pcteTempsReponse;

    // Calculer les temps pour chaque algorithme
    calculerFCFS(processus, fcfsTempsAttente, fcfsTempsReponse);
    calculerTourniquet(processus, tourniquetTempsAttente, tourniquetTempsReponse, 2);
    calculerPriorite(processus, prioriteTempsAttente, prioriteTempsReponse);
    calculerPCTE(processus, pcteTempsAttente, pcteTempsReponse);

    // Remplir le tableau
    double moyenneAttenteFCFS = 0, moyenneReponseFCFS = 0;
    double moyenneAttenteTourniquet = 0, moyenneReponseTourniquet = 0;
    double moyenneAttentePriorite = 0, moyenneReponsePriorite = 0;
    double moyenneAttentePCTE = 0, moyenneReponsePCTE = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        const Processus& p = processus[i];

        // Remplir les colonnes "Date d'arrivée", "Durée d'exécution", et "Priorité"
        ui->tableWidgetRecapitulatif->setItem(i, 0, new QTableWidgetItem("P" + QString::number(p.getId())));
        ui->tableWidgetRecapitulatif->setItem(i, 1, new QTableWidgetItem(QString::number(p.getDateArrivee())));
        ui->tableWidgetRecapitulatif->setItem(i, 2, new QTableWidgetItem(QString::number(p.getDureeExecution())));
        ui->tableWidgetRecapitulatif->setItem(i, 3, new QTableWidgetItem(QString::number(p.getPriorite())));



        ui->tableWidgetRecapitulatif->setItem(i, 4, new QTableWidgetItem(QString::number(fcfsTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 5, new QTableWidgetItem(QString::number(fcfsTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 6, new QTableWidgetItem(QString::number(tourniquetTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 7, new QTableWidgetItem(QString::number(tourniquetTempsReponse[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 8, new QTableWidgetItem(QString::number(prioriteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 9, new QTableWidgetItem(QString::number(prioriteTempsReponse[i])));

        ui->tableWidgetRecapitulatif->setItem(i, 10, new QTableWidgetItem(QString::number(pcteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 11, new QTableWidgetItem(QString::number(pcteTempsReponse[i])));

        moyenneAttenteFCFS += fcfsTempsAttente[i];
        moyenneReponseFCFS += fcfsTempsReponse[i];
        moyenneAttenteTourniquet += tourniquetTempsAttente[i];
        moyenneReponseTourniquet += tourniquetTempsReponse[i];
        moyenneAttentePriorite += prioriteTempsAttente[i];
        moyenneReponsePriorite += prioriteTempsReponse[i];
        moyenneAttentePCTE += pcteTempsAttente[i];
        moyenneReponsePCTE += pcteTempsReponse[i];
    }

    // Moyennes
    moyenneAttenteFCFS /= nombreDeProcessus;
    moyenneReponseFCFS /= nombreDeProcessus;
    moyenneAttenteTourniquet /= nombreDeProcessus;
    moyenneReponseTourniquet /= nombreDeProcessus;
    moyenneAttentePriorite /= nombreDeProcessus;
    moyenneReponsePriorite /= nombreDeProcessus;
    moyenneAttentePCTE /= nombreDeProcessus;
    moyenneReponsePCTE /= nombreDeProcessus;

    int lastRow = nombreDeProcessus;
    ui->tableWidgetRecapitulatif->setItem(lastRow, 3, new QTableWidgetItem("Moyenne"));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 4, new QTableWidgetItem(QString::number(moyenneAttenteFCFS, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 5, new QTableWidgetItem(QString::number(moyenneReponseFCFS, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 6, new QTableWidgetItem(QString::number(moyenneAttenteTourniquet, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 7, new QTableWidgetItem(QString::number(moyenneReponseTourniquet, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 8, new QTableWidgetItem(QString::number(moyenneAttentePriorite, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 9, new QTableWidgetItem(QString::number(moyenneReponsePriorite, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 10, new QTableWidgetItem(QString::number(moyenneAttentePCTE, 'f', 2)));
    ui->tableWidgetRecapitulatif->setItem(lastRow, 11, new QTableWidgetItem(QString::number(moyenneReponsePCTE, 'f', 2)));

    double tempsMin = std::min({moyenneAttenteFCFS, moyenneAttenteTourniquet, moyenneAttentePriorite, moyenneAttentePCTE});

    ui->textEditConclusion->setPlainText("Le temps moyen d'attente minimal est : " + QString::number(tempsMin, 'f', 2));
    ui->textEditConclusion->append("\nConclusion :\n"
                                   "L'algorithme PCTE montre un temps d'attente minimal de " + QString::number(tempsMin) +" "
                                                                            "Cela suggère que, dans ce cas où tous les processus viennent en meme temps, cet algorithme optimise efficacement le temps d'attente .\n");
}

void MainWindow::afficherPageRecapitulatif() {
    ui->stackedWidget->setCurrentWidget(ui->pageRecapitulatif);

    // Remplir le tableau avec les données calculées pour les temps d'attente et de réponse
    remplirTableauRecapitulatif();
    tracerGraphiqueRecapitulatif();
}
void MainWindow::tracerGraphiqueRecapitulatif() {
     QString cheminFichier = "C:/Users/Abdoulaye/Documents/Ordonnanceur/data/processus.csv";
    QVector<Processus> processus = ChargeurCSV::chargerProcessusDepuisCSV(cheminFichier);

    if (processus.isEmpty()) {
        qDebug() << "Le fichier CSV est vide ou invalide.";
        return;
    }

    int nombreDeProcessus = processus.size();
    if (nombreDeProcessus == 0) {
        qDebug() << "Aucun processus à afficher dans le tableau récapitulatif.";
        return;
    }

    QVector<int> fcfsTempsAttente, fcfsTempsReponse;
    QVector<int> tourniquetTempsAttente, tourniquetTempsReponse;
    QVector<int> prioriteTempsAttente, prioriteTempsReponse;
    QVector<int> pcteTempsAttente, pcteTempsReponse;

    // Calculer les temps pour chaque algorithme
    calculerFCFS(processus, fcfsTempsAttente, fcfsTempsReponse);
    calculerTourniquet(processus, tourniquetTempsAttente, tourniquetTempsReponse, 2);
    calculerPriorite(processus, prioriteTempsAttente, prioriteTempsReponse);
    calculerPCTE(processus, pcteTempsAttente, pcteTempsReponse);

    // Remplir le tableau
    double moyenneAttenteFCFS = 0;
    double moyenneAttenteTourniquet = 0;
    double moyenneAttentePriorite = 0;
    double moyenneAttentePCTE = 0;

    for (int i = 0; i < nombreDeProcessus; ++i) {
        const Processus& p = processus[i];

        // Remplir les colonnes "Date d'arrivée", "Durée d'exécution", et "Priorité"
        ui->tableWidgetRecapitulatif->setItem(i, 0, new QTableWidgetItem("P" + QString::number(p.getId())));
        ui->tableWidgetRecapitulatif->setItem(i, 1, new QTableWidgetItem(QString::number(p.getDateArrivee())));
        ui->tableWidgetRecapitulatif->setItem(i, 2, new QTableWidgetItem(QString::number(p.getDureeExecution())));
        ui->tableWidgetRecapitulatif->setItem(i, 3, new QTableWidgetItem(QString::number(p.getPriorite())));



        ui->tableWidgetRecapitulatif->setItem(i, 4, new QTableWidgetItem(QString::number(fcfsTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 6, new QTableWidgetItem(QString::number(tourniquetTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 8, new QTableWidgetItem(QString::number(prioriteTempsAttente[i])));
        ui->tableWidgetRecapitulatif->setItem(i, 10, new QTableWidgetItem(QString::number(pcteTempsAttente[i])));

        moyenneAttenteFCFS += fcfsTempsAttente[i];
        moyenneAttenteTourniquet += tourniquetTempsAttente[i];
        moyenneAttentePriorite += prioriteTempsAttente[i];
        moyenneAttentePCTE += pcteTempsAttente[i];
    }

    // Moyennes
    moyenneAttenteFCFS /= nombreDeProcessus;
    moyenneAttenteTourniquet /= nombreDeProcessus;
    moyenneAttentePriorite /= nombreDeProcessus;
    moyenneAttentePCTE /= nombreDeProcessus;




    QVector<double> moyennesTempsAttente = {
        moyenneAttenteFCFS,
        moyenneAttenteTourniquet,
        moyenneAttentePriorite,
        moyenneAttentePCTE
    };

    QStringList categories = {"FCFS", "Tourniquet", "Priorité", "PCTE"};

    QBarSet *set = new QBarSet("Temps Moyen d'Attente");
    for (double moyenne : moyennesTempsAttente) {
        *set << moyenne;
    }

    QBarSeries *series = new QBarSeries();
    series->append(set);

    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Temps Moyen d'Attente par Algorithme");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // Configurer l'axe des catégories (X)
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // Configurer l'axe des valeurs (Y)
    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, *std::max_element(moyennesTempsAttente.begin(), moyennesTempsAttente.end()) + 1);
    axisY->setTitleText("Temps Moyen d'Attente (ms)");
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(chartView);
    QWidget *graphWidget = new QWidget();
    graphWidget->setLayout(layout);
    graphWidget->setWindowTitle("Courbe_Récapitulatif");
    graphWidget->resize(600, 400);
    graphWidget->show();
}
