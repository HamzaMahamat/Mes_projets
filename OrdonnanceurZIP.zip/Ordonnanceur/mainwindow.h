#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QMainWindow>
#include <QGraphicsScene>
#include <QVector>

#include<QTimer>
#include "Processus.h"
#include "FCFS.h"
#include "PCTE.h"
#include "Tourniquet.h"
#include "Priorite.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void afficherPageFCFS();
    void afficherPageTourniquet();
    void afficherPagePriorite();
    void afficherPageRecapitulatif();
    void afficherPagePCTE();
    void ouvrirInterfaceRequisition();


private:
    Ui::MainWindow *ui;
    QGraphicsScene* sceneFCFS;
    QGraphicsScene* sceneTourniquet;
    QGraphicsScene* scenePriorite;
    QGraphicsScene* scenePCTE;


    QTimer top;
    void chargerEtAfficherFCFS(const QVector<Processus>& processus, int totalTimeSlots);
    void chargerEtAfficherTourniquet(const QVector<Processus>& processus, int totalTimeSlots, int quantum);
    void chargerEtAfficherPriorite(const QVector<Processus>& processus, int totalTimeSlots);
    void remplirTableauRecapitulatif();
    void calculerFCFS(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void calculerTourniquet(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse, int quantum);
    void calculerPriorite(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void afficherChronogrammePCTE(int** etatsPret, int** etatsActif, const QVector<Processus>& processus, int totalTimeSlots);
    void calculerPCTE(const QVector<Processus>& processus, QVector<int>& tempsAttente, QVector<int>& tempsReponse);
    void pauseChrono(int temps);
    void tracerGraphiqueRecapitulatif();

};

#endif // MAINWINDOW_H
