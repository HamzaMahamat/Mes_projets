#include "processus_es.h"

Processus_es::Processus_es()
    : numP(0), dateArrivee(0), dureeExecution(0), tempsRestant(0),
    dateDeFin(0), tempsReponse(0), priorite(0), tempsAttente(0) {}
Processus_es::Processus_es(int numP, int dateArrivee, int priorite, const QVector<int>& calculs, const QVector<int>& entreesSorties)
    : numP(numP), dateArrivee(dateArrivee), dureeExecution(0),
    tempsRestant(0), dateDeFin(0), tempsReponse(0), priorite(priorite),
    tempsCalcul(calculs), tempsEntreeSortie(entreesSorties) {
    for (int calcul : calculs) {
        dureeExecution += calcul;
    }
    tempsRestant = dureeExecution;
}
Processus_es::~Processus_es() {}

void Processus_es::afficher() const {
    qDebug() << "Numéro de processus:" << numP;
    qDebug() << "Date d'arrivée:" << dateArrivee;
    qDebug() << "Durée d'exécution:" << dureeExecution;
    qDebug() << "Temps restant:" << tempsRestant;
    qDebug() << "Date de fin:" << dateDeFin;
    qDebug() << "Temps de réponse:" << tempsReponse;
}

int Processus_es::getId() const { return numP; }
int Processus_es::getTempsRestant() const { return tempsRestant; }
void Processus_es::setTempsRestant(int temps) { tempsRestant = temps; }
int Processus_es::getDateArrivee() const { return dateArrivee; }
int Processus_es::getDureeExecution() const { return dureeExecution; }
void Processus_es::setDateArrivee(int date){dateArrivee=date;}
int Processus_es::getDateDeFin() const { return dateDeFin; }
void Processus_es::setDureeExecution(int duree) {
    dureeExecution = duree;
    tempsRestant = duree;
}
void Processus_es::setDateDeFin(int date) { dateDeFin = date; }
void Processus_es::setTempsReponse(int temps) { tempsReponse = temps; }
int Processus_es::getTempsReponse() const { return tempsReponse; }
int Processus_es::getPriorite() const { return priorite; }
void Processus_es::calculerTempsAttenteEtReponse(int dateFin) {
    tempsReponse = dateFin - dateArrivee;

}
void Processus_es::afficherTemps() const {
    qDebug() << "Numéro de processus:" << numP;
    qDebug() << "Temps d'attente:" << tempsAttente;
    qDebug() << "Temps de réponse:" << tempsReponse;
    qDebug() << "Date de fin:" << dateDeFin;
}
