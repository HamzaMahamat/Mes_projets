#ifndef PROCESSUS_ES_H
#define PROCESSUS_ES_H

#include <QString>
#include <QDebug>

class Processus_es {
private:
    int numP;
    int dateArrivee;
    int dureeExecution;
    int tempsRestant;
    int dateDeFin;
    int tempsReponse;
    int priorite;
    int tempsAttente;
    QVector<int> tempsCalcul;           // Liste des temps de calcul
    QVector<int> tempsEntreeSortie;
public:
   Processus_es();
    Processus_es(int numP, int dateArrivee, int priorite, const QVector<int>& calculs, const QVector<int>& entreesSorties);
    ~Processus_es();

    void afficher() const;
    int getId() const;
    int getTempsRestant() const;
    void setTempsRestant(int temps);
    int getDateArrivee() const;
    int getDureeExecution() const;
    int getDateDeFin() const;
    void setDureeExecution(int duree);
    void setDateDeFin(int date);
    void setDateArrivee(int date);
    void setTempsReponse(int temps);
    int getTempsReponse() const;
    int getPriorite() const;
    void calculerTempsAttenteEtReponse(int dateDebut);
    void afficherTemps() const;
};

#endif // PROCESSUS_H
