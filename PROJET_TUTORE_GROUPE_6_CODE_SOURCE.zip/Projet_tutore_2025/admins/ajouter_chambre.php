<?php
include '../config.php';
$connect = connect_database();

if (isset($_GET['id_village']) && !empty($_GET['id_village'])) {
    $id_village = $_GET['id_village'];

    if (isset($_POST['valider'])) {
        $type_chambre = $_POST['type_chambre'];
        $nombre_lits = $_POST['nombre_lits'];
       
        $sql = "INSERT INTO chambre (id_village, type_chambre, nombre_lits) 
                VALUES ('$id_village', '$type_chambre', '$nombre_lits')";
        $result = mysqli_query($connect, $sql);

        if ($result) {
            header("Location: gestion_villages.php");
        } else {
            echo "Erreur lors de l'ajout de la chambre.";
        }
    }
} else {
    echo "ID de village manquant.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter une Chambre</title>
    <link rel="stylesheet" href="ajouter_chambre.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php">Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php">Demandes</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

<h2>Ajouter une Chambre</h2>

<form method="post" action="ajouter_chambre.php?id_village=<?php echo $id_village; ?>">
    <p>
        <label for="type_chambre">Type de Chambre :</label>
        <select name="type_chambre" required>
            <option value="individuelle">Individuelle</option>
            <option value="double">Double</option>
            <option value="dortoir">Dortoir</option>
        </select>
    </p>
    <p>
        <label for="nombre_lits">Nombre de Lits :</label>
        <input type="number" name="nombre_lits" min="1" required>
    </p>
    <p>
        <input type="submit" name="valider" value="Ajouter">
    </p>
</form>

</body>
</html>
