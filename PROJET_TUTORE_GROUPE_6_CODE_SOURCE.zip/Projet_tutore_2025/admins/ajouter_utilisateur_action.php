<?php
include '../config.php';
$connexion = connect_database();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mot_de_passe = password_hash($_POST['mot_de_passe'], PASSWORD_BCRYPT);
    $telephone = $_POST['telephone'];
    $role = $_POST['role'];
    $id_role = ($role == "etudiant") ? 2 : 3; // 2 = étudiant, 3 = chef de village
    
    $sql_user = "
        INSERT INTO users (nom, prenom, email, mot_de_passe, telephone, id_role) 
        VALUES ('$nom', '$prenom', '$email', '$mot_de_passe', '$telephone', '$id_role')
    ";
    
    if (mysqli_query($connexion, $sql_user)) {
        $id_user = mysqli_insert_id($connexion);

        if ($role == "etudiant") {
            $niveau = $_POST['niveau'];
            $code_etudiant = $_POST['code_etudiant'];

            $sql_etudiant = "
                INSERT INTO etudiant (id_user, niveau, code_etudiant) 
                VALUES ('$id_user', '$niveau', '$code_etudiant')
            ";
            mysqli_query($connexion, $sql_etudiant);
        } elseif ($role == "chef_village") {
            $responsabilite = $_POST['responsabilite'];

            $sql_chef = "
                INSERT INTO chef_village (id_user, responsabilite) 
                VALUES ('$id_user', '$responsabilite')
            ";
            mysqli_query($connexion, $sql_chef);
        }

        header("Location: gestion_utilisateurs.php");
        exit;
    } else {
        echo "Erreur lors de l'ajout de l'utilisateur : " . mysqli_error($connexion);
    }
}
?>
