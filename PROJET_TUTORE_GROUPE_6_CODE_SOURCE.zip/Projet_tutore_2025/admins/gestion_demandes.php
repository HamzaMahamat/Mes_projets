<?php
    include '../config.php';
    $connect = connect_database();
   
    $sql_demandes = "SELECT d.id_demande, d.date_soumission, d.type_demande, d.motif, 
                            u.nom, u.prenom, u.email, e.niveau, e.code_etudiant, 
                            c.id_chambre, c.type_chambre
                     FROM demande d
                     JOIN etudiant e ON d.id_etudiant = e.id_etudiant
                     JOIN users u ON e.id_user = u.id_user
                     JOIN chambre c ON d.id_chambre = c.id_chambre
                     WHERE d.statut = 'en attente'";

    $resultat_demandes = mysqli_query($connect, $sql_demandes);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Demandes</title>
    <link rel="stylesheet" href="gestion_demandes.css">
</head>
<body>

<header>
    <h1>Tableau de Bord - Administrateur</h1>
    <nav>
        <ul>
            <li><a href="page_admin.php">Accueil</a></li>
            <li><a href="gestion_utilisateurs.php">Utilisateurs</a></li>
            <li><a href="gestion_villages.php"> Villages</a></li>
            <li><a href="gestion_demandes.php">Demandes</a></li>
            <li><a href="../page_connexion.php">Déconnexion</a></li>
        </ul>
    </nav>
</header>

<h2>Demandes en Attente</h2>
<table>
    <tr>
        <th>ID Demande</th><th>Date Soumission</th><th>Type</th><th>Motif</th>
        <th>Nom Étudiant</th><th>Email</th><th>Niveau</th><th>Code Étudiant</th>
        <th>ID Chambre</th><th>Type Chambre</th><th>Action1</th><th>Action2</th>
    </tr>
    <?php while ($demande = mysqli_fetch_array($resultat_demandes)) { ?>
        <tr>
            <td><?php echo $demande["id_demande"]; ?></td>
            <td><?php echo $demande["date_soumission"]; ?></td>
            <td><?php echo $demande["type_demande"]; ?></td>
            <td><?php echo $demande["motif"]; ?></td>
            <td><?php echo $demande["nom"] . " " . $demande["prenom"]; ?></td>
            <td><?php echo $demande["email"]; ?></td>
            <td><?php echo $demande["niveau"]; ?></td>
            <td><?php echo $demande["code_etudiant"]; ?></td>
            <td><?php echo $demande["id_chambre"]; ?></td>
            <td><?php echo $demande["type_chambre"]; ?></td>
            <td>
                <a class="btn-accept" href="traiter_demande.php?id_demande=<?php echo $demande['id_demande']; ?>&action=accepter">Accepter</a>
            </td>
            <td>
                <a class="btn-refuse" href="traiter_demande.php?id_demande=<?php echo $demande['id_demande']; ?>&action=refuser">Refuser</a>
            </td>
        </tr>
    <?php } ?>
</table>

</body>
</html>
