<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Utilisateur</title>
    <link rel="stylesheet" href="gestion_utilisateurs_ajouter.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php">Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php">Demandes</a></li>
                <li><a href="page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <h3>Ajouter un Utilisateur</h3>

    <form method="post" action="ajouter_utilisateur_action.php">
        <p>
            <label for="nom">Nom :</label>
            <input type="text" name="nom" required />
        </p>
        <p>
            <label for="prenom">Prénom :</label>
            <input type="text" name="prenom" required />
        </p>
        <p>
            <label for="email">Email :</label>
            <input type="email" name="email" required />
        </p>
        <p>
            <label for="mot_de_passe">Mot de Passe :</label>
            <input type="password" name="mot_de_passe" required />
        </p>
        <p>
            <label for="telephone">Téléphone :</label>
            <input type="text" name="telephone" />
        </p>
        <p>
            <label for="role">Rôle :</label>
            <select name="role" id="role" required>
                <option value="">-- Sélectionner un rôle --</option>
                <option value="etudiant">Étudiant</option>
                <option value="chef_village">Chef de Village</option>
            </select>
        </p>
   
        <div id="etudiant_fields" style="display: none;">
            <p>
                <label for="niveau">Niveau :</label>
                <input type="text" name="niveau" />
            </p>
            <p>
                <label for="code_etudiant">Code Étudiant :</label>
                <input type="text" name="code_etudiant" />
            </p>
        </div>
     
        <div id="chef_fields" style="display: none;">
            <p>
                <label for="responsabilite">Responsabilité :</label>
                <input type="text" name="responsabilite" />
            </p>
        </div>

        <p>
            <input id='boutton' type="submit" value="Ajouter">
        </p>
    </form>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const roleSelect = document.getElementById("role");
            const etudiantFields = document.getElementById("etudiant_fields");
            const chefFields = document.getElementById("chef_fields");

            function toggleFields() {
                const role = roleSelect.value;
                etudiantFields.style.display = role === "etudiant" ? "block" : "none";
                chefFields.style.display = role === "chef_village" ? "block" : "none";
            }
            toggleFields();
       
            roleSelect.addEventListener("change", toggleFields);
        });
    </script>
</body>
</html>
