<?php
include '../config.php';
$connect = connect_database();

$sql_etudiants = "
    SELECT u.id_user, u.nom, u.prenom, u.email, u.telephone, e.niveau, e.code_etudiant
    FROM users u
    INNER JOIN etudiant e ON u.id_user = e.id_user
";
$resultat_etudiants = mysqli_query($connect, $sql_etudiants);

$sql_chefs = "
    SELECT u.id_user, u.nom, u.prenom, u.email, u.telephone, c.responsabilite
    FROM users u
    INNER JOIN chef_village c ON u.id_user = c.id_user
";
$resultat_chefs = mysqli_query($connect, $sql_chefs);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs</title>
    <link rel="stylesheet" href="gestion_utilisateurs.css">
</head>
<body>
<header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php">Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php">Demandes</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <h2>Liste des Étudiants</h2>
    <p>
        <button id="boutton" onclick="window.location.href='gestion_utilisateur_ajouter.php'">
              Ajouter un etudiant
        </button>
    </p>

    <table border="1">
        <tr>
            <th>ID Utilisateur</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Niveau</th>
            <th>Code Étudiant</th>
            <th>Modification</th>
            <th>Suppression</th>
        </tr>
        <?php while($ligne = mysqli_fetch_assoc($resultat_etudiants)) { ?>
            <tr>
                <td><?php echo $ligne["id_user"]; ?></td>
                <td><?php echo $ligne["nom"]; ?></td>
                <td><?php echo $ligne["prenom"]; ?></td>
                <td><?php echo $ligne["email"]; ?></td>
                <td><?php echo $ligne["telephone"]; ?></td>
                <td><?php echo $ligne["niveau"]; ?></td>
                <td><?php echo $ligne["code_etudiant"]; ?></td>
                <td><a href="modifier_utilisateur.php?id_user=<?php echo $ligne["id_user"]; ?>">Modifier</a></td>
                <td><a href="supprimer_utilisateur.php?id_user=<?php echo $ligne["id_user"]; ?>">Supprimer</a></td>
            </tr>
        <?php } ?>
    </table>

    <h2>Liste des Chefs de Village</h2>
    <p>
        <button id="boutton" onclick="window.location.href='gestion_utilisateur_ajouter.php'">
              Ajouter un chef de village
        </button>
    </p>

    <table border="1">
        <tr>
            <th>ID Utilisateur</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Responsabilité</th>
            <th>Modification</th>
            <th>Suppression</th>
        </tr>
        <?php while($ligne = mysqli_fetch_assoc($resultat_chefs)) { ?>
            <tr>
                <td><?php echo $ligne["id_user"]; ?></td>
                <td><?php echo $ligne["nom"]; ?></td>
                <td><?php echo $ligne["prenom"]; ?></td>
                <td><?php echo $ligne["email"]; ?></td>
                <td><?php echo $ligne["telephone"]; ?></td>
                <td><?php echo $ligne["responsabilite"]; ?></td>
                <td><a href="modifier_utilisateur.php?id_user=<?php echo $ligne["id_user"]; ?>">Modifier</a></td>
                <td><a href="supprimer_utilisateur.php?id_user=<?php echo $ligne["id_user"]; ?>">Supprimer</a></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>

<?php mysqli_close($connect); ?>
