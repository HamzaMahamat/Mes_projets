<?php
include '../config.php';
$connect = connect_database();

$sql_villages = "SELECT * FROM village";
$resultat_villages = mysqli_query($connect, $sql_villages);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Villages</title>
    <link rel="stylesheet" href="gestion_villages.css">
</head>
<body>

    <header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php"> Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php"> Demandes</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

<h2>Liste des Villages et Chambres Disponibles</h2>

<?php while ($village = mysqli_fetch_array($resultat_villages)) { ?>
    <div class="village-container">
        <h3>🏡 Village : <?php echo $village["nom_village"]; ?></h3>
        <table>
            <tr>
                <th>ID Chambre</th><th>Type</th><th>Nombre de Lits</th><th>Actions</th>
            </tr>
            <?php
                $id_village = $village["id_village"];
                $sql_chambres = "SELECT * FROM chambre WHERE id_village = $id_village";
                $resultat_chambres = mysqli_query($connect, $sql_chambres);
                
                while ($chambre = mysqli_fetch_array($resultat_chambres)) {
            ?>
                <tr>
                    <td><?php echo $chambre["id_chambre"]; ?></td>
                    <td><?php echo $chambre["type_chambre"]; ?></td>
                    <td><?php echo $chambre["nombre_lits"]; ?></td>
                    <td>
                        <a class="btn-delete" href="supprimer_chambre.php?id_chambre=<?php echo $chambre['id_chambre']; ?>">❌ Supprimer</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
      
        <p>
            <button id="boutton" onclick="window.location.href='ajouter_chambre.php?id_village=<?php echo $id_village; ?>'">
                ➕ Ajouter une chambre
            </button>
        </p>
    </div>
<?php } ?>

</body>
</html>
