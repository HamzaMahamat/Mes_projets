<?php
include '../config.php';
$connexion = connect_database();

if (isset($_GET['id_user'])) {
    $id = $_GET['id_user'];
  
    $sql_etudiant = "
        SELECT u.id_user, u.nom, u.prenom, u.email, u.telephone, e.niveau, e.code_etudiant 
        FROM users u 
        INNER JOIN etudiant e ON u.id_user = e.id_user 
        WHERE u.id_user='$id'
    ";
    $resultat_etudiant = mysqli_query($connexion, $sql_etudiant);
    
    if ($ligne = mysqli_fetch_assoc($resultat_etudiant)) {
        $type = "etudiant";
        $nom = $ligne['nom'];
        $prenom = $ligne['prenom'];
        $email = $ligne['email'];
        $telephone = $ligne['telephone'];
        $niveau = $ligne['niveau'];
        $code_etudiant = $ligne['code_etudiant'];
    } else {
        $sql_chef = "
            SELECT u.id_user, u.nom, u.prenom, u.email, u.telephone, c.responsabilite 
            FROM users u 
            INNER JOIN chef_village c ON u.id_user = c.id_user 
            WHERE u.id_user='$id'
        ";
        $resultat_chef = mysqli_query($connexion, $sql_chef);

        if ($ligne = mysqli_fetch_assoc($resultat_chef)) {
            $type = "chef_village";
            $nom = $ligne['nom'];
            $prenom = $ligne['prenom'];
            $email = $ligne['email'];
            $telephone = $ligne['telephone'];
            $responsabilite = $ligne['responsabilite'];
        } else {
            echo "Utilisateur non trouvé.";
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Utilisateur</title>
    <link rel="stylesheet" href="modifier_utilisateur.css">
</head>
<body>
<header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php">Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php">Demandes</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <h1>Modifier Utilisateur</h1>
    <form method="POST" action="modifier_utilisateur_action.php">
        <input type="hidden" name="id_user" value="<?php echo $id; ?>">
        
        <p>
            <label for="nom">Nom :</label>
            <input type="text" name="nom" value="<?php echo $nom; ?>">
        </p>
        
        <p>
            <label for="prenom">Prénom :</label>
            <input type="text" name="prenom" value="<?php echo $prenom; ?>">
        </p>

        <p>
            <label for="email">Email :</label>
            <input type="email" name="email" value="<?php echo $email; ?>">
        </p>

        <p>
            <label for="telephone">Téléphone :</label>
            <input type="text" name="telephone" value="<?php echo $telephone; ?>">
        </p>

        <?php if ($type == "etudiant") { ?>
            <p>
                <label for="niveau">Niveau :</label>
                <input type="text" name="niveau" value="<?php echo $niveau; ?>">
            </p>

            <p>
                <label for="code_etudiant">Code Étudiant :</label>
                <input type="text" name="code_etudiant" value="<?php echo $code_etudiant; ?>">
            </p>
        <?php } else { ?>
            <p>
                <label for="responsabilite">Responsabilité :</label>
                <input type="text" name="responsabilite" value="<?php echo $responsabilite; ?>">
            </p>
        <?php } ?>

        <p>
            <input id='boutton' type="submit" value="Modifier">
        </p>
    </form>
</body>
</html>
