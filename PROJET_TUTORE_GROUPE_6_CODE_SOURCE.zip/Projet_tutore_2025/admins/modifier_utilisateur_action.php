<?php
include '../config.php';
$connexion = connect_database();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_user'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];

    $sql_check = "SELECT id_user FROM etudiant WHERE id_user = '$id'";
    $result_check = mysqli_query($connexion, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        $niveau = $_POST['niveau'];
        $code_etudiant = $_POST['code_etudiant'];

        $sql_update = "
            UPDATE users SET nom='$nom', prenom='$prenom', email='$email', telephone='$telephone' WHERE id_user='$id';
            UPDATE etudiant SET niveau='$niveau', code_etudiant='$code_etudiant' WHERE id_user='$id';
        ";
    } else {
        $responsabilite = $_POST['responsabilite'];

        $sql_update = "
            UPDATE users SET nom='$nom', prenom='$prenom', email='$email', telephone='$telephone' WHERE id_user='$id';
            UPDATE chef_village SET responsabilite='$responsabilite' WHERE id_user='$id';
        ";
    }

    if (mysqli_multi_query($connexion, $sql_update)) {
        header("Location: gestion_utilisateurs.php");
        exit;
    } else {
        echo "Erreur lors de la mise à jour : " . mysqli_error($connexion);
    }
}
?>
