
<?php
include '../config.php'; 

$conn = connect_database();


$query_etudiants = "SELECT COUNT(*) AS total_etudiants FROM etudiant";
$result_etudiants = mysqli_query($conn, $query_etudiants);
$row_etudiants = mysqli_fetch_assoc($result_etudiants);
$total_etudiants = $row_etudiants['total_etudiants'];


$query_demandes = "SELECT COUNT(*) AS total_demandes FROM demande WHERE statut = 'en attente'";
$result_demandes = mysqli_query($conn, $query_demandes);
$row_demandes = mysqli_fetch_assoc($result_demandes);
$total_demandes = $row_demandes['total_demandes'];

mysqli_close($conn); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - Administrateur</title>
    <link rel="stylesheet" href="page_admin.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="page_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php"> Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Villages</a></li>
                <li><a href="gestion_demandes.php">Demandes</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Statistiques Globales</h2>
            <p><?php echo $total_etudiants; ?> étudiants inscrits cette année.</p>
        </section>
        <section class="card">
            <h2>Demandes en Cours</h2>
            <p><?php echo $total_demandes; ?> demandes en cours de traitement.</p>
        </section>
    </main>
</body>
</html>

