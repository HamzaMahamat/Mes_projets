<?php
include '../config.php';
$connect = connect_database();

if (isset($_GET['id_chambre']) && !empty($_GET['id_chambre'])) {
    $id_chambre = $_GET['id_chambre'];
  
    $sql = "DELETE FROM chambre WHERE id_chambre = $id_chambre";
    $result = mysqli_query($connect, $sql);

    if ($result) {
        header("Location: gestion_villages.php");
    } else {
        echo "Erreur lors de la suppression de la chambre.";
    }
} else {
    echo "ID de chambre manquant.";
}
?>
