<?php
if (isset($_GET['id_user'])) {
    include '../config.php';
    $connect = connect_database();
    $id = $_GET['id_user'];
   
    $sql_check = "SELECT id_user FROM etudiant WHERE id_user = '$id'";
    $result_check = mysqli_query($connect, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        $sql_delete = "
            DELETE FROM etudiant WHERE id_user='$id';
            DELETE FROM users WHERE id_user='$id';
        ";
    } else {
        $sql_check = "SELECT id_user FROM chef_village WHERE id_user = '$id'";
        $result_check = mysqli_query($connect, $sql_check);

        if (mysqli_num_rows($result_check) > 0) {
            $sql_delete = "
                DELETE FROM chef_village WHERE id_user='$id';
                DELETE FROM users WHERE id_user='$id';
            ";
        } else {
            echo "Utilisateur non trouvé.";
            exit;
        }
    }

    if (mysqli_multi_query($connect, $sql_delete)) {
        header("Location: gestion_utilisateurs.php");
        exit;
    } else {
        echo "Erreur lors de la suppression : " . mysqli_error($connect);
    }
}
?>
