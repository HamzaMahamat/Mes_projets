<?php
    include '../config.php';
    $connect = connect_database();

    if (isset($_GET['id_demande']) && isset($_GET['action'])) {
        $id_demande = intval($_GET['id_demande']);
        $action = $_GET['action'];
       
        if ($action === 'accepter') {
            $sql = "UPDATE demande SET statut = 'accepte' WHERE id_demande = ?";
        } elseif ($action === 'refuser') {
            $sql = "UPDATE demande SET statut = 'refuse' WHERE id_demande = ?";
        } else {
            echo "Action invalide.";
            exit;
        }
       
        $stmt = mysqli_prepare($connect, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_demande);
        $resultat = mysqli_stmt_execute($stmt);

        if ($resultat) {
            echo "<script>alert('La demande a été mise à jour avec succès.'); window.location.href = 'gestion_demandes.php';</script>";
        } else {
            echo "<script>alert('Erreur lors de la mise à jour de la demande.'); window.location.href = 'gestion_demandes.php';</script>";
        }
       
        mysqli_stmt_close($stmt);
        mysqli_close($connect);
    } else {
        echo "<script>alert('ID de demande ou action manquante.'); window.location.href = 'gestion_demandes.php';</script>";
    }
?>
