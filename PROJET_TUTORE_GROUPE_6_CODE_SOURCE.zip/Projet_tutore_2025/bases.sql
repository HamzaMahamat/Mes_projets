
CREATE TABLE role (
    id_role INT PRIMARY KEY AUTO_INCREMENT,
    libelle_role VARCHAR(20) NOT NULL DEFAULT 'etudiant' check (libelle_role in('admin','etudiant','chef village'))
);
CREATE TABLE users (
    id_user INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    telephone VARCHAR(15),
    id_role INT NOT NULL,
    FOREIGN KEY (id_role) REFERENCES role(id_role)
);

CREATE TABLE etudiant (
    id_etudiant INT PRIMARY KEY AUTO_INCREMENT,
    id_user INT NOT NULL UNIQUE,
    niveau VARCHAR(20),
    code_etudiant VARCHAR(10) NOT NULL UNIQUE,
    FOREIGN KEY (id_user) REFERENCES users(id_user)
);

CREATE TABLE chef_village (
    id_chef_village INT PRIMARY KEY AUTO_INCREMENT,
    id_user INT NOT NULL UNIQUE,
    responsabilite TEXT,
    FOREIGN KEY (id_user) REFERENCES users(id_user)
);

CREATE TABLE village (
    id_village INT PRIMARY KEY AUTO_INCREMENT,
    nom_village VARCHAR(50) NOT NULL UNIQUE,
    id_chef_village INT,
    FOREIGN KEY (id_chef_village) REFERENCES chef_village(id_chef_village)
);

CREATE TABLE chambre (
    id_chambre INT PRIMARY KEY AUTO_INCREMENT,
    id_village INT NOT NULL,
    nombre_lits INT NOT NULL DEFAULT 1,
    type_chambre VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_village) REFERENCES village(id_village)
);

CREATE TABLE lit (
    id_lit INT PRIMARY KEY AUTO_INCREMENT,
    id_chambre INT NOT NULL,
    statut VARCHAR(20) NOT NULL DEFAULT 'libre' check (statut in ('libre','occupe')),
    FOREIGN KEY (id_chambre) REFERENCES chambre(id_chambre)
);

CREATE TABLE demande (
    id_demande INT PRIMARY KEY AUTO_INCREMENT,
    id_etudiant INT NOT NULL,
    id_chambre INT NOT NULL,
    date_soumission DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut VARCHAR(20) NOT NULL DEFAULT 'en attente' (statut in ('en attente','accepte','refuse')),
    motif TEXT,
    type_demande VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_etudiant) REFERENCES etudiant(id_etudiant),
    FOREIGN KEY (id_chambre) REFERENCES chambre(id_chambre)
);

CREATE TABLE paiement (
    id_paiement INT PRIMARY KEY AUTO_INCREMENT,
    id_demande INT NOT NULL,
    montant DECIMAL(10,2) NOT NULL,
    date_paiement DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    methode_paiement VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_demande) REFERENCES demande(id_demande)
);

CREATE TABLE historique_codification (
    id_historique INT PRIMARY KEY AUTO_INCREMENT,
    id_etudiant INT NOT NULL,
    id_chambre INT NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE,
    FOREIGN KEY (id_etudiant) REFERENCES etudiant(id_etudiant),
    FOREIGN KEY (id_chambre) REFERENCES chambre(id_chambre)
);


INSERT INTO role (libelle_role) VALUES 
('admin'),
('etudiant'),
('chef village');

INSERT INTO users (nom, prenom, email, mot_de_passe, telephone, id_role) VALUES
('Dupont', 'Jean', 'admin@univ.sn', SHA2('admin123', 256), '771234567', 1),
('Sow', 'Salif', 'salif@univ.sn', SHA2('etudiant1', 256), '772345678', 2),
('Mboup', 'Ahmadou', 'ahmadou@univ.sn', SHA2('etudiant2', 256), '773456789', 2),

('Ndiaye', 'Awa', 'awa@univ.sn', SHA2('chef123', 256), '774567890', 3);

INSERT INTO etudiant (id_user, niveau, code_etudiant) VALUES
(2, 'L3 Informatique', 'P45 2222'),
(3, 'L3 Mathématiques', 'P36 379');

INSERT INTO chef_village (id_user, responsabilite) VALUES
(4, 'Gestion du Village A');

INSERT INTO village (nom_village, id_chef_village) VALUES
('Village A', 1);

INSERT INTO chambre (id_village, nombre_lits, type_chambre) VALUES
(1, 2, 'Double'),
(1, 1, 'Simple');

INSERT INTO lit (id_chambre, statut) VALUES
(1, 'libre'),
(1, 'libre'),
(2, 'libre');

INSERT INTO demande (id_etudiant, id_chambre, statut, type_demande) VALUES
(1, 1, 'en attente', 'attribution'),
(2, 2, 'accepte', 'conservation');

INSERT INTO paiement (id_demande, montant, methode_paiement) VALUES
(2, 15000.00, 'Orange Money');

INSERT INTO historique_codification (id_etudiant, id_chambre, date_debut) VALUES
(2, 2, '2023-09-01');

INSERT INTO village (nom_village, id_chef_village) VALUES
('Village B', 1),
('Village C', 1),
('Village D', 1);

INSERT INTO chambre (id_village, nombre_lits, type_chambre) VALUES
(2, 2, 'Double'),
(2, 1, 'Simple'),
(2, 4, 'Collective'),
(2, 3, 'Triple'),
(2, 2, 'Double'),
(2, 1, 'Simple'),
(2, 4, 'Collective'),
(2, 3, 'Triple'),
(2, 2, 'Double'),
(2, 1, 'Simple');

INSERT INTO chambre (id_village, nombre_lits, type_chambre) VALUES
(3, 2, 'Double'),
(3, 1, 'Simple'),
(3, 4, 'Collective'),
(3, 3, 'Triple'),
(3, 2, 'Double'),
(3, 1, 'Simple'),
(3, 4, 'Collective'),
(3, 3, 'Triple'),
(3, 2, 'Double'),
(3, 1, 'Simple');

INSERT INTO chambre (id_village, nombre_lits, type_chambre) VALUES
(4, 2, 'Double'),
(4, 1, 'Simple'),
(4, 4, 'Collective'),
(4, 3, 'Triple'),
(4, 2, 'Double'),
(4, 1, 'Simple'),
(4, 4, 'Collective'),
(4, 3, 'Triple'),
(4, 2, 'Double'),
(4, 1, 'Simple');

INSERT INTO lit (id_chambre, statut)
SELECT id_chambre, 'libre' FROM chambre WHERE id_village IN (2, 3, 4);
