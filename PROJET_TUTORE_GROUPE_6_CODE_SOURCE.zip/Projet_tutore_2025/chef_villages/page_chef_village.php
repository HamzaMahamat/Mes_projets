
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - Chef de Village</title>
    <link rel="stylesheet" href="page_chef_village.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Chef de Village</h1>
        <nav>
            <ul>
                <li><a href="page_chef_village.php">Accueil</a></li>
                <li><a href="page_chef_village.php">Chambres</a></li>
                <li><a href="page_chef_village.php">Valider Demandes</a></li>
                <li><a href="page_chef_village.php">Chambres</a></li>
                <li><a href="page_chef_village.php">Mon Profil</a></li>
                <li><a href="../page_connexion.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Chambres Disponibles</h2>
            <p>10 chambres disponibles dans votre village.</p>
        </section>
        <section class="card">
            <h2>Demandes en Attente</h2>
            <p>5 demandes en attente de validation.</p>
        </section>
    </main>
</body>
</html>
