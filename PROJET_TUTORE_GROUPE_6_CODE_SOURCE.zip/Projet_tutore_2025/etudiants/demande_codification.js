function toggleForm() {
    const demandeType = document.querySelector('input[name="type_demande"]:checked').value;
    const conservationSection = document.getElementById('conservation-section');
    const codificationSection = document.getElementById('codification-section');

    if (demandeType === 'conservation') {
        conservationSection.style.display = 'block';
        codificationSection.style.display = 'none';
    } else {
        conservationSection.style.display = 'none';
        codificationSection.style.display = 'block';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    toggleForm(); // Set the correct form on page load
});