<?php
session_start();
require("../config.php");
$conn = connect_database();

$village_query = "SELECT id_village, nom_village FROM village";
$village_result = mysqli_query($conn, $village_query);

$type_chambre_query = "SELECT DISTINCT type_chambre FROM chambre";
$type_chambre_result = mysqli_query($conn, $type_chambre_query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faire une Demande de Codification</title>
    <link rel="stylesheet" href="demande_codification.css">
    <script src="demande_codification.js" defer></script>
</head>
<body>
    <header>
        <h1>Faire une Demande de Codification</h1>
        <nav>
            <ul>
                <li><a href="page_etudiant.php">Accueil</a></li>
                <li><a href="suivi_demande.php">Suivi des Demandes</a></li>
                <li><a href="profil.php">Mon Profil</a></li>
                <li><a href="logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="traitement_demande.php" method="POST" class="card">
            <label>Type de Demande :</label><br>
            <input type="radio" id="codification" name="type_demande" value="codification" checked onclick="toggleForm()">
            <label for="codification">Codification pour une nouvelle chambre</label><br>
            <input type="radio" id="conservation" name="type_demande" value="conservation" onclick="toggleForm()">
            <label for="conservation">Conservation de chambre</label>

            <div id="codification-section">
                <label for="code_etudiant">Code Étudiant :</label>
                <input type="text" name="code_etudiant" id="code_etudiant" required placeholder="Entrez votre code étudiant">

                <label for="niveau">Niveau :</label>
                <input type="text" name="niveau" id="niveau" required placeholder="Entrez votre niveau (ex: L3, M1, etc.)">

                <label for="village">Choisir un Village :</label>
                <select name="village" id="village" required>
                    <?php
                    if ($village_result && mysqli_num_rows($village_result) > 0) {
                        while ($village = mysqli_fetch_assoc($village_result)) {
                            echo '<option value="' . htmlspecialchars($village['id_village']) . '">' . htmlspecialchars($village['nom_village']) . '</option>';
                        }
                    } else {
                        echo '<option value="">Aucun village disponible</option>';
                    }
                    ?>
                </select>

                <label for="type_chambre">Type de Chambre :</label>
                <select name="type_chambre" id="type_chambre" required>
                    <?php
                    if ($type_chambre_result && mysqli_num_rows($type_chambre_result) > 0) {
                        while ($chambre = mysqli_fetch_assoc($type_chambre_result)) {
                            echo '<option value="' . htmlspecialchars($chambre['type_chambre']) . '">' . htmlspecialchars($chambre['type_chambre']) . '</option>';
                        }
                    } else {
                        echo '<option value="">Aucun type de chambre disponible</option>';
                    }
                    ?>
                </select>
            </div>

            <div id="conservation-section" style="display: none;">
                <label for="info_etudiant">Nom et Prenom:</label>
                <input type="text" name="info_etudiant" id="info_etudiant" placeholder="Entrez votre nom complet" required>

                <label for="village_conservation">Village :</label>
                <select name="village_conservation" id="village_conservation" required>
                    <?php
                    if ($village_result && mysqli_num_rows($village_result) > 0) {
                        mysqli_data_seek($village_result, 0); // Reset result pointer
                        while ($village = mysqli_fetch_assoc($village_result)) {
                            echo '<option value="' . htmlspecialchars($village['id_village']) . '">' . htmlspecialchars($village['nom_village']) . '</option>';
                        }
                    } else {
                        echo '<option value="">Aucun village disponible</option>';
                    }
                    ?>
                </select>

                <label for="numero_chambre">N° Chambre :</label>
                <input type="text" name="numero_chambre" id="numero_chambre" required placeholder="N° chambre">
            </div>

            <button type="submit" class="btn">Soumettre la Demande</button>
        </form>
    </main>
</body>
</html>
<?php
mysqli_close($conn);
?>
