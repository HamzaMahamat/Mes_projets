<?php
session_start();
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'etudiant') {
//     header("Location: ../page_connexion.php");
//     exit();
// }

require('../config.php');
$conn = connect_database();

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM notification WHERE id_user = $user_id ORDER BY date_envoi DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link rel="stylesheet" href="notifications.css">
</head>
<body>
    <header>
        <h1>Mes Notifications</h1>
        <nav>
            <ul>
                <li><a href="dashboard_etudiant.php">Accueil</a></li>
                <li><a href="demande_codification.php">Faire une Demande</a></li>
                <li><a href="profil.php">Mon Profil</a></li>
                <li><a href="logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Notifications Récentes</h2>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($notification = mysqli_fetch_assoc($result)) {
                    echo "<p>{$notification['message']} - <small>{$notification['date_envoi']}</small></p>";
                }
            } else {
                echo "<p>Aucune notification pour le moment.</p>";
            }
            ?>
        </section>
    </main>
</body>
</html>
