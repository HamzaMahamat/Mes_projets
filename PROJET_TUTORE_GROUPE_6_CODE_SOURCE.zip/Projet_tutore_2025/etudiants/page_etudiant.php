
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - Étudiant</title>
    <link rel="stylesheet" href="page_etudiant.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Étudiant</h1>
        <nav>
            <ul>
                <li><a href="page_etudiant.php">Accueil</a></li>
                <li><a href="demande_codification.php">Faire une demande</a></li>
                <li><a href="suivi_demande.php">Suivi des demandes</a></li>
                <li><a href="profil.php">Mon Profil</a></li>
                <li><a href="logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Statut de la Codification</h2>
            <p>Votre demande de codification est en cours de traitement.</p>
        </section>
        <section class="card">
            <h2>Notifications</h2>
            <p>Aucune nouvelle notification.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 CROUS UGB</p>
    </footer>
</body>
</html>
