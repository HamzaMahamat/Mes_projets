<?php
session_start();
session_regenerate_id(true);
// if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !='etudiant') {
//     header("Location:../page_connexion.php");
//     exit();
// }
require('../config.php');
$conn = connect_database();

$user_id = $_SESSION['user_id'];

$query = "SELECT u.nom, u.prenom, u.email, u.telephone, e.niveau, e.code_etudiant 
          FROM users u 
          JOIN etudiant e ON u.id_user = e.id_user 
          WHERE u.id_user = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil</title>
    <link rel="stylesheet" href="profil.css">
</head>
<body>
    <header>
        <h1>Mon Profil</h1>
        <nav>
            <ul>
                <li><a href="page_etudiant.php">Accueil</a></li>
                <li><a href="demande_codification.php">Faire une Demande</a></li>
                <li><a href="suivi_demande.php">Suivi des Demandes</a></li>
                <li><a href="logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="tabs">
            <button class="tab-btn active" onclick="switchTab('formulaire',event)">Informations personnelles</button>
        </div>
        <div id="formulaire" class="tab-content active">
            <div class="accordion">
                <div class="accordion-item">
                    <button class="accordion-header">Etat Civil</button>
                    <div class="accordion-content">
                        <form action="" method="POST">
                            <div class="contacts">
                                <div class="inputform">
                                    <label for="code_etudiant">Code Étudiant :</label>
                                    <input type="text" name="code_etudiant" value="<?php echo htmlspecialchars($user['code_etudiant']); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="prenom">Prénom(s) :</label>
                                    <input type="text" name="prenom" value="<?php echo htmlspecialchars($user['prenom']); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="nom">Nom :</label>
                                    <input type="text" name="nom" value="<?php echo htmlspecialchars($user['nom']); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="email">Email :</label>
                                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="niveau">Niveau :</label>
                                    <input type="text" name="niveau" value="<?php echo htmlspecialchars($user['niveau']); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="telephone">Téléphone :</label>
                                    <input type="tel" name="telephone" value="<?php echo htmlspecialchars($user['telephone']); ?>" readonly>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="page_profil.js"></script>
</body>
</html>
<?php
mysqli_close($conn);
?>
