<?php
session_start();
require("../config.php");

if (isset($_SESSION['user_id']) && $_SESSION['user_role'] !== 'etudiant') {
    $_SESSION['error'] = 'Veuillez vous connecter pour accéder à cette page.';
    header("Location: ../page_connexion.php");
    exit();
}

$connexion = connect_database();
$user_id = $_SESSION['user_id'];
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$sql = "SELECT * FROM demande WHERE id_etudiant = ? ";
$stmt = mysqli_prepare($connexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suivi des Demandes</title>
    <link rel="stylesheet" href="suivi_demande.css">
</head>
<body>
    <header>
        <h1>Suivi des Demandes</h1>
        <nav>
            <ul>
                <li><a href="page_etudiant.php">Accueil</a></li>
                <li><a href="demande_codification.php">Faire une Demande</a></li>
                <li><a href="notifications.php">Notifications</a></li>
                <li><a href="profil.php">Mon Profil</a></li>
                <li><a href="../logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Mes Demandes</h2>
            <?php
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<p>Demande pour le <strong>" . htmlspecialchars($row['type_demande']) . "</strong> - Statut : <strong>" . htmlspecialchars($row['statut']) . "</strong></p>";
                }
            } else {
                echo "<p>Aucune demande trouvée.</p>";
            }
            ?>
        </section>
    </main>
</body>
</html>

<?php
mysqli_close($connexion);
?>
