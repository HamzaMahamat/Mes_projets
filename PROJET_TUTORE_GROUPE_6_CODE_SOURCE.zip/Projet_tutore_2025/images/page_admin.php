
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - Administrateur</title>
    <link rel="stylesheet" href="page_admin.css">
</head>
<body>
    <header>
        <h1>Tableau de Bord - Administrateur</h1>
        <nav>
            <ul>
                <li><a href="dashboard_admin.php">Accueil</a></li>
                <li><a href="gestion_utilisateurs.php">Gérer les Utilisateurs</a></li>
                <li><a href="gestion_villages.php">Gérer les Villages</a></li>
                <li><a href="gestion_paiements.php">Gérer les Paiements</a></li>
                <li><a href="logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="card">
            <h2>Statistiques Globales</h2>
            <p>1200 étudiants inscrits cette année.</p>
        </section>
        <section class="card">
            <h2>Demandes en Cours</h2>
            <p>35 demandes en cours de traitement.</p>
        </section>
    </main>
</body>
</html>
