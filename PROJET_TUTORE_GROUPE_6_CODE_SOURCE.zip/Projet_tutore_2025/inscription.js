// Validation du formulaire d'inscription

document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('.form-inscription');

    form.addEventListener('submit', function (e) {
        const email = document.getElementById('email').value.trim();
        const motDePasse = document.getElementById('mot_de_passe').value.trim();
        let errors = [];
      
        if (!email.endsWith('@ugb.edu.sn')) {
            errors.push("L'email doit se terminer par @ugb.edu.sn");
        }
      
        if (motDePasse.length < 8) {
            errors.push("Le mot de passe doit contenir au moins 8 caractères.");
        }
     
        if (errors.length > 0) {
            e.preventDefault();
            displayErrors(errors);
        }
    });

    function displayErrors(errors) {
        const errorContainer = document.querySelector('.error');
        if (errorContainer) {
            errorContainer.innerHTML = errors.join('<br>');
        } else {
            const newErrorDiv = document.createElement('p');
            newErrorDiv.className = 'error';
            newErrorDiv.innerHTML = errors.join('<br>');
            document.querySelector('main').insertBefore(newErrorDiv, form);
        }
    }
});
