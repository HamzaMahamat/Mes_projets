<?php
session_start();
require("config.php");

$connexion = connect_database();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $email = trim($_POST['email']);
    $mot_de_passe = trim($_POST['mot_de_passe']);
    $telephone = trim($_POST['telephone']);
    $niveau = trim($_POST['niveau']);
    $code_etudiant = trim($_POST['code_etudiant']);

    if (!empty($nom) && !empty($prenom) && !empty($email) && !empty($mot_de_passe) && !empty($niveau) && !empty($code_etudiant)) {
     
        $sql_verif_email = "SELECT id_user FROM users WHERE email = ?";
        $stmt_verif = mysqli_prepare($connexion, $sql_verif_email);
        mysqli_stmt_bind_param($stmt_verif, "s", $email);
        mysqli_stmt_execute($stmt_verif);
        $result_verif = mysqli_stmt_get_result($stmt_verif);

        if (mysqli_num_rows($result_verif) > 0) {
            $_SESSION['error'] = "Cet email est déjà utilisé.";
        } else {
            $id_role_etudiant = 2; 
            $sql_user = "INSERT INTO users (nom, prenom, email, mot_de_passe, telephone, id_role) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt_user = mysqli_prepare($connexion, $sql_user);
            mysqli_stmt_bind_param($stmt_user, "sssssi", $nom, $prenom, $email, $mot_de_passe, $telephone, $id_role_etudiant);
            
            if (mysqli_stmt_execute($stmt_user)) {
                $id_user = mysqli_insert_id($connexion);
               
                $sql_etudiant = "INSERT INTO etudiant (id_user, niveau, code_etudiant) VALUES (?, ?, ?)";
                $stmt_etudiant = mysqli_prepare($connexion, $sql_etudiant);
                mysqli_stmt_bind_param($stmt_etudiant, "iss", $id_user, $niveau, $code_etudiant);
                
                if (mysqli_stmt_execute($stmt_etudiant)) {
                    $_SESSION['success'] = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
                    header("Location: page_connexion.php");
                    exit();
                } else {
                    $_SESSION['error'] = "Erreur lors de l'inscription de l'étudiant.";
                }
            } else {
                $_SESSION['error'] = "Erreur lors de l'inscription de l'utilisateur.";
            }
        }
    } else {
        $_SESSION['error'] = "Veuillez remplir tous les champs.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription Étudiant</title>
    <link rel="stylesheet" href="inscription.css">
</head>
<body>
    <header>
        <h1>Inscrivez vous au site de Campus Social </h1>
    </header>
    <main>
        <?php if (isset($_SESSION['error'])): ?>
            <p class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
        <?php endif; ?>

        <form action="" method="POST" class="form-inscription">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>

            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" required>

            <label for="email">Email :</label>
            <input type="email" id="email" name="email" required>

            <label for="mot_de_passe">Mot de Passe :</label>
            <input type="password" id="mot_de_passe" name="mot_de_passe" required>

            <label for="telephone">Téléphone :</label>
            <input type="text" id="telephone" name="telephone">

            <label for="niveau">Niveau :</label>
            <input type="text" id="niveau" name="niveau" required>

            <label for="code_etudiant">Code Étudiant :</label>
            <input type="text" id="code_etudiant" name="code_etudiant" required>

            <button type="submit">S'inscrire</button>
        </form>
    </main>
    <script src="inscription.js"></script>
</body>
</html>
