const emailForme = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const motDePasse = /^(?=.*\d).{6,}$/;

document.querySelector('.connexion').addEventListener('click', function (p) {
    const email = document.getElementById('email').value;
    const password = document.querySelector('input[type="password"]').value;

    let estCorrect = true;
    document.getElementById('email-error').textContent = '';
    document.getElementById('password-error').textContent = '';
    if (!emailForme.test(email)) {
        document.getElementById('email-error').textContent = "Le login saisi n'est pas correct.";
        estCorrect = false;
    }
    if (!motDePasse.test(password)) {
        document.getElementById('password-error').textContent = "Le mot de passe saisi n'est pas correct.";
        estCorrect = false;
    }
    if (!estCorrect) {
        p.preventDefault();
        return;
    }
   
});

