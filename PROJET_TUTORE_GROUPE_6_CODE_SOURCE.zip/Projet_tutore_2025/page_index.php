<!DOCTYPE html>
<html lang="fr">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Projet_Developpement_dapplication_web_II</title>
       <link rel="stylesheet" href="page_index.css">
       <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
   </head>
   <body>
        <div>
            <div id="entete">
                <header id="header">
                    <h1>Bienvenue sur la plateforme de codification du campus Social UGB</h1>
                    <nav>
                        <ul>
                            <li><a href="page_index.php">Accueil</a></li>
                            <li><a href="page_index.php">Apropos</a></li>
                            <li><a href="page_index.php">Contact</a></li>
                            <li><a href="inscription.php">S'inscrire</a></li>
                        </ul>
                    </nav>
                </header>
            </div>
            <div id="pere">
                  
                <div id="milieu">
                    <div id="filsG">
                      <p class="info">
                        <i class="fas fa-file-alt" style="color: #186fbb;"> </i>
                        <span>Informations Campus Social</span>
                      </p> 
                      <div class="base">
                      <?php
                        require("config.php"); 
                        $connexion = connect_database();
                        $sql = "SELECT id, titre, contenu, image_url FROM article ORDER BY id ";
                        $resultat = mysqli_query($connexion, $sql);

                        if ($resultat && mysqli_num_rows($resultat) > 0) {
                            while ($article = mysqli_fetch_assoc($resultat)) {
                                echo '<div class="article" style=" display: flex;"   >';
                                if (!empty($article['image_url'])) {
                                    echo '<img src="' . htmlspecialchars($article['image_url']) . '" alt="Image de l\'article" style="width: 150px; height: 150px;">';
                                }
                                echo '<div class="article2">';
                                echo '<h2>'. htmlspecialchars($article['titre']) . '</h2>';
                                echo '<p>' . htmlspecialchars($article['contenu']) . '</p>';
                                echo '</div>';
                                echo '</div>';
                                echo '<hr>'; 
                            }
                        } else {
                            echo "<p>Aucun article trouvé.</p>";
                        }
                        mysqli_close($connexion);
                        ?>
                      </div>
                    </div>
                    <div id="filsD">
                        <div id="haut">
                            <p class="info">
                                <i class="fas fa-graduation-cap" style="color: #186fbb;"> </i>
                                <span>Espace Campus</span>
                            </p>
                            <p class="text1">Veuillez vous connecter pour accéder à votre espace Campus.</p>
                            <button class="boutton"><i class="fas fa-sign-in-alt" style="color: white;"> </i> <a href="page_connexion.php">Se connecter</a> </button>
                        </div>
                        <div id="bas">
                            <p class="info">
                                <i class="fas fa-exclamation-circle" style="color: #186fbb;"> </i>
                                <span>Guides</span>
                            </p>
                            <p>Pour tout savoir sur l'utilisation de ce portail, veuillez télécharger :</p>
                            <button class="boutton2">
                                <i class="fas fa-file-pdf" style="color: white;"> </i>
                                <a  href="document_pdf/guide_ugb.pdf">Le guide d'utilisation</a>
                             </button>
                             <p>Ou consulter</p>
                             <button class="boutton3">
                                <i class="fas fa-file-pdf" style="color: white;"> </i>
                                <a  href="document_pdf/guide_ugb.pdf">Le guide en ligne</a>
                             </button>  
                        </div>
                    </div>
                </div>
            </div>
            <footer>
                @Copyright CCOS | 2024
            </footer>
        </div>
   </body>
  
</html>
