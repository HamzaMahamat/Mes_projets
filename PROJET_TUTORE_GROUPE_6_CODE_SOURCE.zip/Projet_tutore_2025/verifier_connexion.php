<?php 
session_start();
require("config.php");
$connexion = connect_database();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = trim($_POST["password"]);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'Adresse e-mail invalide.';
        header("Location: page_connexion.php");
        exit;
    }

    if (!empty($email) && !empty($password)) {
     
        $sql = "SELECT u.*, r.libelle_role 
                FROM users u
                JOIN role r ON u.id_role = r.id_role
                WHERE u.email = ?";
        $stmt = mysqli_prepare($connexion, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            
            if ($password === $user['mot_de_passe']) {
                session_regenerate_id(true);
                $_SESSION["user_id"] = $user["id_user"];
                $_SESSION["user_role"] = $user["libelle_role"];
                $_SESSION["nom"] = $user["nom"];
                $_SESSION["prenom"] = $user["prenom"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["telephone"] = $user["telephone"];
            
                if ($user["libelle_role"] === "etudiant") {
                    $sql_etudiant = "SELECT * FROM etudiant WHERE id_user = ?";
                    $stmt_etudiant = mysqli_prepare($connexion, $sql_etudiant);
                    mysqli_stmt_bind_param($stmt_etudiant, "i", $user["id_user"]);
                    mysqli_stmt_execute($stmt_etudiant);
                    $result_etudiant = mysqli_stmt_get_result($stmt_etudiant);
                    
                    if ($result_etudiant && mysqli_num_rows($result_etudiant) > 0) {
                        $etudiant = mysqli_fetch_assoc($result_etudiant);
                        $_SESSION["id_etudiant"] = $etudiant["id_etudiant"];
                        $_SESSION["niveau"] = $etudiant["niveau"];
                        $_SESSION["code_etudiant"] = $etudiant["code_etudiant"];
                    }
                    header("Location:etudiants/page_etudiant.php");
                    exit;
                }
               
                if ($user["libelle_role"] === "chef village") {
                    $sql_chef = "SELECT * FROM chef_village WHERE id_user = ?";
                    $stmt_chef = mysqli_prepare($connexion, $sql_chef);
                    mysqli_stmt_bind_param($stmt_chef, "i", $user["id_user"]);
                    mysqli_stmt_execute($stmt_chef);
                    $result_chef = mysqli_stmt_get_result($stmt_chef);

                    if ($result_chef && mysqli_num_rows($result_chef) > 0) {
                        $chef = mysqli_fetch_assoc($result_chef);
                        $_SESSION["id_chef_village"] = $chef["id_chef_village"];
                        $_SESSION["responsabilite"] = $chef["responsabilite"];
                    }
                    header("Location:chef_villages/page_chef_village.php");
                    exit;
                }
                if ($user["libelle_role"] === "admin") {
                    header("Location:admins/page_admin.php");
                    exit;
                }
            } else {
                $_SESSION['error'] = 'Mot de passe incorrect.';
            }
        } else {
            $_SESSION['error'] = 'Adresse e-mail non trouvée.';
        }
    } else {
        $_SESSION['error'] = 'Veuillez remplir tous les champs.';
    }
    header("Location:page_connexion.php");
    exit;
}

mysqli_close($connexion);
?>
