package Perceptron1;

import javax.swing.*;
import java.awt.*;

public class PanelGraphique extends JPanel {
    private float[][] donnees;
    private int[] sorties;
    private float[] poids;

    private Float testSepale = null;
    private Float testPetale = null;

    public PanelGraphique(float[][] donnees, int[] sorties, float[] poids) {
        this.donnees = donnees;
        this.sorties = sorties;
        this.poids = poids;
    }

    public void setPointTest(float sepale, float petale) {
        this.testSepale = sepale;
        this.testPetale = petale;
        repaint(); 
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        int w = getWidth();
        int h = getHeight();

        g2.setColor(Color.GRAY);
        g2.drawLine(40, h - 40, w - 20, h - 40); 
        g2.drawLine(40, 20, 40, h - 40);      

        float maxX = 8f, maxY = 8f;
        
        float x1 = 0, x2 = maxX;
        float y1 = -(poids[0] + poids[1]*x1)/poids[2];
        float y2 = -(poids[0] + poids[1]*x2)/poids[2];

        int sx1 = (int)(40 + (x1 / maxX) * (w - 60));
        int sy1 = (int)(h - 40 - (y1 / maxY) * (h - 60));
        int sx2 = (int)(40 + (x2 / maxX) * (w - 60));
        int sy2 = (int)(h - 40 - (y2 / maxY) * (h - 60));

        g2.setColor(Color.BLACK);
        g2.drawLine(sx1, sy1, sx2, sy2);

        if (testSepale != null && testPetale != null) {
            int px = (int)(40 + (testSepale / maxX) * (w - 60));
            int py = (int)(h - 40 - (testPetale / maxY) * (h - 60));

            g2.setColor(Color.GREEN);
            g2.fillOval(px - 5, py - 5, 10, 10);
        }
    }
}
