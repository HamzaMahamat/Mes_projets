package Perceptron1;
import java.io.*;
import java.util.*;

public class Perceptron {
	
	public Perceptron() {
		
	}
	
   public float[] calculPerceptron(float[]w ,float[][]tab,int []C ) {
		int i,j,l,k=0,rep=0,c,o,E;   
		float z;
		
		for(i=0;i<w.length;i++) {
			w[i]=1;
		}
		for(j=0;j<tab.length;j++) {
			z=0;
				for(i=0;i<w.length;i++) {
					z=z+w[i]*tab[j][i];
				}
			
			if(z>0) {
				o=1;
			}
			else {
				o=0;
			}
			E=C[j]-o;
			if(E==0) {
				rep=rep+1;
				if(rep>=tab.length) {
					return w;
				}
			}
			else {
				rep=0;
					for(l=0;l<w.length;l++) {
						w[l]=w[l]+E*tab[j][l];
					}
			}
			if(j==tab.length-1 && rep<tab.length)
				j=0;
			k++;
			System.out.println("Literation : "+k);
	        for (i = 0; i < w.length; i++) {
	            System.out.println("w[" + i + "] = " + w[i]);
	        }
		}
		
		return w;
	}
   
   public boolean testPerceptron(float[]w) {
	   Scanner sr = new Scanner(System.in);
       
       System.out.println("Donner la longueur sepale :");
       float ls = sr.nextFloat();

       System.out.println("Donner la longueur petale :");
       float lp = sr.nextFloat();
       
       float r=w[0]*1+w[1]*ls+w[2]*lp;
       
       if(r>0) {
    	   return true;
       }
       else {
    	   return false;
       }
      
   }
   
   
   public static Object[] lireCSV(String cheminFichier) {
       List<float[]> entrees = new ArrayList<>();
       List<Integer> sorties = new ArrayList<>();

       try (BufferedReader br = new BufferedReader(new FileReader(cheminFichier))) {
           String ligne;

           while ((ligne = br.readLine()) != null) {
               ligne = ligne.replace("\"", "").replace(",", ".").trim();

               if (ligne.isEmpty()) continue;

               String[] valeurs = ligne.split(";");
               if (valeurs.length < 4) continue;

               float[] ligneEntree = new float[3];
               for (int i = 0; i < 3; i++) {
                   ligneEntree[i] =Float.parseFloat(valeurs[i].trim());
               }

               int sortie = Integer.parseInt(valeurs[3].trim());

               entrees.add(ligneEntree);
               sorties.add(sortie);
           }
       } catch (FileNotFoundException e) {
           System.out.println("Fichier non trouvé : " + cheminFichier);
       } catch (IOException e) {
           System.out.println("Erreur de lecture : " + e.getMessage());
       } catch (NumberFormatException e) {
           System.out.println("Erreur de format de nombre : " + e.getMessage());
       }

       float[][] tab = new float[entrees.size()][3];
       int[] C = new int[sorties.size()];

       for (int i = 0; i < entrees.size(); i++) {
           tab[i] = entrees.get(i);
           C[i] = sorties.get(i);
       }

       return new Object[]{tab, C};
   }
	
	public static void main(String []argv) {
		
		String fichier = "perceptron.csv"; 

        Object[] resultats = lireCSV(fichier);
        float[][] T = (float[][]) resultats[0];
        int[] C = (int[]) resultats[1];

        float[] w = new float[3]; 

        Perceptron p = new Perceptron();
        float[] R = p.calculPerceptron(w, T, C);
		
		System.out.println("Poids finaux : ");
        for (int i = 0; i < R.length; i++) {
            System.out.println("w[" + i + "] = " + R[i]);
        }
        PerceptronGUI.lancerInterface(R, T, C);
        
	}

}
