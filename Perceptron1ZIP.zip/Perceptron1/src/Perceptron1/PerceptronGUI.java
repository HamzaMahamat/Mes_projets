package Perceptron1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PerceptronGUI extends JFrame {
    private JTextField sepaleField;
    private JTextField petaleField;
    private JLabel resultLabel;
    private float[] poids;
    private PanelGraphique graphique;

    public PerceptronGUI(float[] poidsFinal, float[][] tab, int[] C) {
        this.poids = poidsFinal;

        setTitle("Test Perceptron - Iris avec graphique");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        sepaleField = new JTextField(10);
        petaleField = new JTextField(10);
        resultLabel = new JLabel("Résultat : ");

        JButton testerBtn = new JButton("Tester");

        testerBtn.addActionListener(e -> testerIris());

        JPanel saisiePanel = new JPanel(new GridLayout(4, 2));
        saisiePanel.add(new JLabel("Longueur sépale :"));
        saisiePanel.add(sepaleField);
        saisiePanel.add(new JLabel("Longueur pétale :"));
        saisiePanel.add(petaleField);
        saisiePanel.add(testerBtn);
        saisiePanel.add(resultLabel);

        graphique = new PanelGraphique(tab, C, poids);
        graphique.setPreferredSize(new Dimension(600, 250));

        setLayout(new BorderLayout());
        add(saisiePanel, BorderLayout.NORTH);
        add(graphique, BorderLayout.CENTER);
    }

    private void testerIris() {
        try {
            float ls = Float.parseFloat(sepaleField.getText());
            float lp = Float.parseFloat(petaleField.getText());

            float r = poids[0] * 1 + poids[1] * ls + poids[2] * lp;

            graphique.setPointTest(ls, lp);

            if (r > 0) {
                resultLabel.setText("Résultat : Iris-versicolor");
            } else {
                resultLabel.setText("Résultat : Iris-setosa ");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Entrez des nombres valides !");
        }
    }

    public static void lancerInterface(float[] poidsFinal, float[][] tab, int[] C) {
        SwingUtilities.invokeLater(() -> {
            new PerceptronGUI(poidsFinal, tab, C).setVisible(true);
        });
    }
}