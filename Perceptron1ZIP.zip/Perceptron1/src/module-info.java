/**
 * 
 */
/**
 * 
 */
module Perceptron1 {
	requires java.desktop;
}