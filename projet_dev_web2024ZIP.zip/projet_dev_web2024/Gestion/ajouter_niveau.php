<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="ajouter_niveau.css">
</head>
<body>
<header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
            <form method="post" action="ajouterniveau.php">
                <h3> Ajouter un Niveau</h3>
                <p>
                <label for="id_niveau">ID Niveau: </label> 
                <input type="text" name="id_niveau" />
                </p>
                <p>
                <label for="auteur">Libelle Niveau: </label>
                <input type="text" name="libelle_niveau" />
                </p>
                <br>
                <p>
                    <input id="valider" type="submit" name="valider" value="Valider">
                </p>
            </form>
        </div>
        <div class="page3_2">
            <img src="../images/logo_ugb@2x.png" alt="" class="logo25">
            <ul>
                <li><a href="../page_admin.php"><i class="fas fa-home"></i>Accueil</a></li> 
                <li><a href="important/etudiant.php"><i class="fa fa-user-graduate"></i>Etudiants</a></li> 
                <li><a href="important/info.php"><i class="fa fa-graduation-cap"></i> Informations</a></li>
                <li><a href="pageformation.php"><i class="fas fa-graduation-cap"></i>Formations </a></li>
                <li><a href="pageniveau.php" target="_parent"><i class="fa fa-layer-group"></i>Niveau </a></li>
                <li><a href="pageanneeacademique.php"><i class="fas fa-calendar-alt"></i> Année academique</a></li>
                <li><a href=""><i class="fas fa-question-circle "></i> Aide</a></li>
            </ul>
        </div>
        
    </div>
   <!-- <script src="script.js"></script> -->
</body>
</html>
