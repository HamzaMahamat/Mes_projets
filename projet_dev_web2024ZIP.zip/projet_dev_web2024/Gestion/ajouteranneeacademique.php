<?php
        if($_POST && isset($_POST['valider'])){
            require("../config2.php");
            $connexion=connect_database2();
            $new_id = addslashes($_POST["id_annee"]);
            $new_libelle = addslashes($_POST["libelle_annee"]);
            $sql="insert into anneeaccademique(id_annee,libelle_annee)
             values('$new_id','$new_libelle')";

            $resultat=mysqli_query($connexion,$sql);

            header("Location:pageanneeacademique.php");
        }
?> 
