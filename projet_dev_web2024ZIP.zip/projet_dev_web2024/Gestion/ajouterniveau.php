<?php
        if($_POST && isset($_POST['valider'])){
            require("../config2.php");
            $connexion=connect_database2();
            $new_id = addslashes($_POST["id_niveau"]);
            $new_libelle = addslashes($_POST["libelle_niveau"]);
            $sql="insert into niveau(id_niveau,libelle_niveau)
             values('$new_id','$new_libelle')";

            $resultat=mysqli_query($connexion,$sql);

            header("Location:pageniveau.php");
        }
?> 
