<?php
     if(isset($_GET['id_annee']) ){
        include("../config2.php");
        $connect=connect_database2();
        $id = addslashes($_GET['id_annee']);
        
        $sql="delete from anneeaccademique where id_annee='$id'";

        $resultat=mysqli_query($connect,$sql);

        header("Location:pageanneeacademique.php");
     }
?>