<?php
     if(isset($_GET['id_formation']) ){
        include("../config2.php");
        $connect=connect_database2();
        $id = ($_GET['id_formation']);
        
        $sql="delete from formation where id_formation='$id'";

        $resultat=mysqli_query($connect,$sql);

        header("Location:pageformation.php");
     }
?>