<?php
    $id=$_POST['id_annee'];
    $libelle=$_POST['libelle_annee'];
    include("../config2.php");
    $connexion=connect_database2();

    $sql="update anneeaccademique set libelle_annee='$libelle' where id_annee='$id'";

    $resultat=mysqli_query($connexion,$sql);

    header("Location:pageanneeacademique.php");
?>