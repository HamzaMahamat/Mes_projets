<?php
    $id=$_POST['id_formation'];
    $libelle=$_POST['libelle_formation'];
    include("../config2.php");
    $connexion=connect_database2();
    $sql="update formation set libelle_formation='$libelle' 
          where id_formation='$id'
         ";

    $resultat=mysqli_query($connexion,$sql);

    header("Location:pageformation.php");
?>