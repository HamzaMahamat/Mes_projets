<?php
    $id=$_POST['id_niveau'];
    $libelle=$_POST['libelle_niveau'];
    include("../config2.php");
    $connexion=connect_database2();

    $sql="update niveau set libelle_niveau='$libelle' where id_niveau='$id'";
    
    $resultat=mysqli_query($connexion,$sql);

    header("Location:pageniveau.php");
?>