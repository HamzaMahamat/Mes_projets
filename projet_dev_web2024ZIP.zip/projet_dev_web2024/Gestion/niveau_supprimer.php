<?php
require("../config2.php");
$connexion = connect_database2();

if (isset($_GET['id_niveau'])) {
    $id_niveau = addslashes($_GET['id_niveau']);
    $sql = "DELETE FROM niveau WHERE id_niveau = '$id_niveau'";
    $resultat = mysqli_query($connexion, $sql);
    if ($resultat) {
        header("Location:pageniveau.php");
        exit();
    } else {
        echo "Erreur lors de la suppression : " . mysqli_error($connexion);
    }
}
?>
