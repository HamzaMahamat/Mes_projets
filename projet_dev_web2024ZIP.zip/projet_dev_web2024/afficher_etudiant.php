<?php
session_start();
require("config2.php");

if (!isset($_SESSION['id_etudiant'])) {
    header("Location: pageconnexion.php");
    exit;
}

$connexion = connect_database2();


$id_etudiant = $_SESSION['id_etudiant'];
$sql = "SELECT * FROM etudiant WHERE id_etudiant = ?";
$stmt = mysqli_prepare($connexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_etudiant);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $etudiant = mysqli_fetch_assoc($result);
} else {
    echo "Erreur : étudiant introuvable.";
    exit;
}
?>
