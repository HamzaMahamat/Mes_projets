document.getElementById('naviton').addEventListener('click', () => {
    const button = document.getElementById('navigaton');
    button.classList.toggle('glow'); 
});
