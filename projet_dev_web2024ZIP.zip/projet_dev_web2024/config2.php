<?php 
     function connect_database2(){
            $conn=mysqli_connect("localhost","root","Deribordo@62");
            if(!$conn){
            echo "Echec de la connexion au serveur :";
            exit;

            }
            $selection_bd=mysqli_select_db($conn,"Universite_UGB");
            if(!$selection_bd){
                echo "Echec de la connexion à la base de données.";
                exit;
            }
            return $conn;
        }
?>