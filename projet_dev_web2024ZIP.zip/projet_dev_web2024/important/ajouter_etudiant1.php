<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="ajouter_etudiant1.css">
</head>
<body>
    <header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
        <h1>Remplissez le formulaire pour ajouter un nouvel étudiant.</h1>
        <form action="traitement_ajout_etudiant.php" method="post" enctype="multipart/form-data" class="form">
            <!-- Section : Informations personnelles -->
            <div class="form-group">
                <label for="code_etudiant">Code Étudiant *</label>
                <input type="text" id="code_etudiant" name="code_etudiant" required>
            </div>

            <div class="form-group">
                <label for="prenom">Prénom *</label>
                <input type="text" id="prenom" name="prenom" required>
            </div>

            <div class="form-group">
                <label for="nom">Nom *</label>
                <input type="text" id="nom" name="nom" required>
            </div>

            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" placeholder="Ex : xxxx@ugb.edu.sn"  required>
            </div>

            <div class="form-group">
                <label for="date_naissance">Date de Naissance *</label>
                <input type="date" id="date_naissance" name="date_naissance" required>
            </div>

            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="tel" id="telephone" name="telephone" placeholder="Ex: +221 70 123 4567">
            </div>

            <div class="form-group">
                <label for="adresse">Adresse</label>
                <input type="text" id="adresse" name="adresse">
            </div>

            <div class="form-group">
                <label for="photo_etudiant">Photo de l'Étudiant</label>
                <input type="text" id="photo_etudiant" name="photo_etudiant" placeholder="Ex: nom_image.png">
            </div>

            <div class="form-group">
                <label for="id_user">ID Utilisateur *</label>
                <input type="text" id="id_user" name="id_user"  required>
            </div>

            <!-- Bouton d'envoi -->
            <div class="form-group">
                <button type="submit" class="submit-button"><i class="fas fa-save"></i> Enregistrer</button>
            </div>
        </form>
            
        </div>
        <!-- Page3_2 Div -->
        <div class="page3_2">
            <img src="../images/logo_ugb@2x.png" alt="" class="logo25">
            <ul>
                <li><a href="../page_admin.php"><i class="fas fa-home"></i>Accueil</a></li> 
                <li><a href="etudiant.php"><i class="fa fa-user-graduate"></i>Etudiants</a></li> 
                <li><a href="info.php"><i class="fa fa-graduation-cap"></i> Informations</a></li>
                <li><a href="Gestion/pageformation.php"><i class="fas fa-graduation-cap"></i>Formations </a></li>
                <li><a href="Gestion/pageniveau.php" target="_parent"><i class="fa fa-layer-group"></i>Niveau </a></li>
                <li><a href="Gestion/pageanneeacademique.php"><i class="fas fa-calendar-alt"></i> Année academique</a></li>
                <li><a href=""><i class="fas fa-question-circle "></i> Aide</a></li>
            </ul>
        </div>
    </div>
   <script src="etudiant.js"></script>
</body>
</html>
