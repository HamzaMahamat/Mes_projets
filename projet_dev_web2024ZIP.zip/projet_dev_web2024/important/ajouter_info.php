<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="ajouter_etudiant1.css">
</head>
<body>
    <header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
        <h1>Remplissez le formulaire pour ajouter une nouvelle information.</h1>
        <form action="insert_info.php" method="post" enctype="multipart/form-data" class="form">
            <div class="form-group">
                <label for="titre">Titre *</label>
                <input type="text" id="titre" name="titre" required>
            </div>

            <div class="form-group">
                <label for="contenu">Contenu *</label>
                <input type="text" id="contenu" name="contenu" required>
            </div>

            <div class="form-group">
                <label for="image">URL image *</label>
                <input type="text" id="image" name="image" required>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-button" name="valider"><i class="fas fa-save"></i> Enregistrer</button>
            </div>
        </form>
            
        </div>
        <!-- Page3_2 Div -->
        <div class="page3_2">
            <img src="../images/logo_ugb@2x.png" alt="" class="logo25">
            <ul>
                <li><a href="../page_admin.php"><i class="fas fa-home"></i>Accueil</a></li> 
                <li><a href="etudiant.php"><i class="fa fa-user-graduate"></i>Etudiants</a></li> 
                <li><a href="info.php"><i class="fa fa-graduation-cap"></i> Informations</a></li>
                <li><a href="Gestion/pageformation.php"><i class="fas fa-graduation-cap"></i>Formations </a></li>
                <li><a href="Gestion/pageniveau.php" target="_parent"><i class="fa fa-layer-group"></i>Niveau </a></li>
                <li><a href="Gestion/pageanneeacademique.php"><i class="fas fa-calendar-alt"></i> Année academique</a></li>
                <li><a href=""><i class="fas fa-question-circle "></i> Aide</a></li>
            </ul>
        </div>
    </div>
   <script src="etudiant.js"></script>
</body>
</html>
