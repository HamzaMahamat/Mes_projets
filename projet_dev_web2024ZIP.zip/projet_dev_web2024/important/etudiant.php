<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="etudiant.css">
</head>
<body>
    <header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <a href="../page_admin.php">Accueil</a>
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
          <button id="ajouter" onclick="location.href='ajouter_etudiant1.php';">Ajouter</button>
            <h1>La liste des etudiants inscrits.</h1>
            <?php 
                require("../config2.php");
                $connexion=connect_database2();
                $sql="SELECT * FROM etudiant";
                $resultat=mysqli_query($connexion,$sql);
            ?>
            <table>
                    <tr>
                        <th>Id</th>
                        <th>Code Etudiant</th>
                        <th>Prénom</th>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Date de Naissance</th>
                        <th>Telephone</th>
                        <th>Adresse</th>
                        <th>Photo</th>
                        <th>Id_user</th>
                        <th>Modifier</th>
                        <th>Supprimer</th>

                    </tr>
                    <?php
                    while($ligne=mysqli_fetch_array($resultat)){?>
                        <tr>
                        <td><?php echo $ligne['id_etudiant']; ?></td>
                            <td><?php echo $ligne['code_etudiant']; ?></td>
                            <td><?php echo $ligne['prenom']; ?></td>
                            <td><?php echo $ligne['nom']; ?></td>
                            <td><?php echo $ligne['email']; ?></td>
                            <td><?php echo $ligne['date_naissance']; ?></td>
                            <td><?php echo $ligne['telephone']; ?></td>
                            <td><?php echo $ligne['adresse']; ?></td>
                            <td><?php echo $ligne['photo_etudiant']; ?></td>
                            <td><?php echo $ligne['id_user']; ?></td>
                            <td><a href="modification.php?id_etudiant=<?php echo $ligne['id_etudiant']; ?>">Modifier</a></td>
                            <td><a href="supprimer_etudiant.php?id_etudiant=<?php echo $ligne['id_etudiant']; ?>">Supprimer</a></td>
                        </tr>
                <?php }?>
                </table>
           
        </div>
    </div>
   <script src="etudiant.js"></script>
</body>
</html>
