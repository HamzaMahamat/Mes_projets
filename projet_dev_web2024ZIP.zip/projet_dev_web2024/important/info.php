<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="etudiant.css">
</head>
<body>
    <header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <a href="../page_admin.php">Accueil</a>
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
          <button id="ajouter" onclick="location.href='ajouter_info.php';">Ajouter</button>
            <h1>La liste des Informations.</h1>
            <?php 
                require("../config2.php");
                $connexion=connect_database2();
                $sql="SELECT * FROM information";
                $resultat=mysqli_query($connexion,$sql);
            ?>
            <table>
                    <tr>
                        <th>Id</th>
                        <th>Titre</th>
                        <th>Contenu</th>
                        <th>Image</th>
                        <th>Modifier</th>
                        <th>Supprimer</th>

                    </tr>
                    <?php
                    while($ligne=mysqli_fetch_array($resultat)){?>
                        <tr>
                        <td><?php echo $ligne['id_information']; ?></td>
                            <td><?php echo $ligne['titre']; ?></td>
                            <td><?php echo $ligne['contenu']; ?></td>
                            <td><?php echo $ligne['image']; ?></td>
                            <td><a href="update_info.php?id_information=<?php echo $ligne['id_information']; ?>">Modifier</a></td>
                            <td><a href="supp_info.php?id_information=<?php echo $ligne['id_information']; ?>">Supprimer</a></td>
                        </tr>
                <?php }?>
                </table>
           
        </div>
    </div>
   <script src="etudiant.js"></script>
</body>
</html>
