<?php
if ($_POST && isset($_POST["valider"])) {
    require("../config2.php");
    $connexion = connect_database2();
  
    $new_titre = addslashes($_POST["titre"]);
    $new_contenu= addslashes($_POST["contenu"]);
    $new_image = addslashes($_POST["image"]);
    $sql = "INSERT INTO information (titre, contenu,image) 
            VALUES ('$new_titre', '$new_contenu', '$new_image')";
    $resultat = mysqli_query($connexion, $sql);

    if ($resultat) {
        
        header("Location:info.php"); 
        exit();
    } else {
        echo "Erreur lors de l'ajout : " . mysqli_error($connexion);
    }
}
?>
