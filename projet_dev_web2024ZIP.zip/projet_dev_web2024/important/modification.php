<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="modification.css">
</head>
<body>
    <header>
        <img src="../images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="../pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
            <h1>Modifier un etudiant</h1>
            <?php 
            require("../config2.php");
            $connexion = connect_database2();

            if (isset($_GET['id_etudiant'])) {
                $id_etudiant = addslashes($_GET['id_etudiant']);
                $sql = "SELECT * FROM etudiant WHERE id_etudiant = '$id_etudiant'";
                $resultat = mysqli_query($connexion, $sql);
                
                if ($resultat && mysqli_num_rows($resultat) > 0) {
                    $etudiant = mysqli_fetch_assoc($resultat);
                } else {
                    echo "L'étudiant n'existe pas.";
                    exit;
                }
            }
            ?>
            <form method="POST" action="modifier_etudiant.php"    class="form">
                <input type="hidden" name="id_etudiant" value="<?php echo htmlspecialchars($etudiant['id_etudiant']); ?>">
                <div class="form-group">
                <label for="code_etudiant">Code Étudiant :</label><br>
                <input type="text" id="code_etudiant" name="code_etudiant" value="<?php echo htmlspecialchars($etudiant['code_etudiant']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="prenom">Prénom :</label><br>
                <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($etudiant['prenom']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="nom">Nom :</label><br>
                <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($etudiant['nom']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="email">Email :</label><br>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($etudiant['email']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="date_naissance">Date de Naissance :</label><br>
                <input type="date" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($etudiant['date_naissance']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="telephone">Téléphone :</label><br>
                <input type="tel" id="telephone" name="telephone" value="<?php echo htmlspecialchars($etudiant['telephone']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="adresse">Adresse :</label><br>
                <input type="text" id="adresse" name="adresse" value="<?php echo htmlspecialchars($etudiant['adresse']); ?>"><br>
                </div>
                <div class="form-group">
                <label for="photo_etudiant">Photo Étudiant :</label><br>
                <input type="text" id="photo_etudiant" name="photo_etudiant" value="<?php echo htmlspecialchars($etudiant['photo_etudiant']); ?>"><br>
                </div>
                <div class="form-group">
                <button type="submit" class="submit-button"><i class="fas fa-save"></i>Mettre à jour</button>
                </div>
            </form>

            
        </div>
        <!-- Page3_2 Div -->
        <div class="page3_2">
            <img src="../images/logo_ugb@2x.png" alt="" class="logo25">
            <ul>
                <li><a href="../page_admin.php"><i class="fas fa-home"></i>Accueil</a></li> 
                <li><a href="etudiant.php"><i class="fa fa-user-graduate"></i>Etudiants</a></li> 
                <li><a href="info.php"><i class="fa fa-graduation-cap"></i> Informations</a></li>
                <li><a href="Gestion/pageformation.php"><i class="fas fa-graduation-cap"></i>Formations </a></li>
                <li><a href="Gestion/pageniveau.php" target="_parent"><i class="fa fa-layer-group"></i>Niveau </a></li>
                <li><a href="Gestion/pageanneeacademique.php"><i class="fas fa-calendar-alt"></i> Année academique</a></li>
                <li><a href=""><i class="fas fa-question-circle "></i> Aide</a></li>
            </ul>
        </div>
    </div>
   <script src="etudiant.js"></script>
</body>
</html>
