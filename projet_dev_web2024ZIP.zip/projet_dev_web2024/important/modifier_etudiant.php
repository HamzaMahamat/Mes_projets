<?php
if ($_POST && isset($_POST["modifier"])) {
    require("../config2.php");
    $connexion = connect_database2();
    
    $id_etudiant = $_POST["id_etudiant"] ?? ''; 
    $prenom = $_POST["prenom"] ?? '';
    $nom = $_POST["nom"] ?? '';
    $email = $_POST["email"] ?? '';
    $date_naissance = $_POST["date_naissance"] ?? '';
    $telephone = $_POST["telephone"] ?? '';
    $adresse = $_POST["adresse"] ?? '';
    $photo_etudiant = $_POST["photo_etudiant"] ?? '';

    if (!empty($id_etudiant)) {
        $sql = "UPDATE etudiant 
                SET prenom = ?, nom = ?, email = ?, date_naissance = ?, telephone = ?, adresse = ?, photo_etudiant = ? 
                WHERE id_etudiant = ?";
        $stmt = mysqli_prepare($connexion, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param(
                $stmt,
                "ssssssss",
                $prenom,
                $nom,
                $email,
                $date_naissance,
                $telephone,
                $adresse,
                $photo_etudiant,
                $id_etudiant
            );

            if (mysqli_stmt_execute($stmt)) {
                header("Location: etudiant.php");
                exit();
            } else {
                echo "Erreur lors de la mise à jour : " . mysqli_error($connexion);
            }
        } else {
            echo "Erreur de préparation de la requête : " . mysqli_error($connexion);
        }
    } else {
        echo "ID invalide pour la mise à jour.";
    }
}
?>
