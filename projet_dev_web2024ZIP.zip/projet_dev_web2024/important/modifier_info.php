<?php
if ($_POST) {
    require("../config2.php");
    $connexion = connect_database2();
    $titre=addslashes($_POST["titre"]);
    $contenu=addslashes($_POST["contenu"]);
    $image=addslashes($_POST["image"]);
    $id_information=$_POST['id_information'];
    if($id_information>0){
    $sql = "UPDATE information 
            SET titre = '$titre', contenu = '$contenu', image = '$image'
            WHERE id_information = $id_information";

    if (mysqli_query($connexion, $sql)) {
        echo "L'infomration' a été mise à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour : " . mysqli_error($connexion);
    }
    header("Location:info.php");
   }
}
?>