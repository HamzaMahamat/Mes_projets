<?php
     require("../config2.php");
     $connexion = connect_database2();
     if (isset($_GET['id_information'])) {
         $id_information = intval($_GET['id_information']);
         $sql = "DELETE FROM information WHERE id_information = $id_information";
         $resultat = mysqli_query($connexion, $sql);
         header("Location:info.php");
     }
?>
