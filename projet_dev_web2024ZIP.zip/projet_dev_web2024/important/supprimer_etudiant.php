<?php
require("../config2.php");
$connexion = connect_database2();

if (isset($_GET['id_etudiant'])) {
    $id_etudiant = addslashes($_GET['id_etudiant']);

   
    $sql = "DELETE FROM etudiant WHERE id_etudiant = '$id_etudiant'";
    $resultat = mysqli_query($connexion, $sql);
 
    if ($resultat) {
        header("Location: etudiant.php");
        exit();
    } else {
        echo "Erreur lors de la suppression : " . mysqli_error($connexion);
    }
}
?>
