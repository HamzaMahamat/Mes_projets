<?php
require("../config2.php"); 
$connexion = connect_database2();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
 
    $code_etudiant = trim($_POST['code_etudiant']);
    $prenom = trim($_POST['prenom']);
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $date_naissance = trim($_POST['date_naissance']);
    $telephone = trim($_POST['telephone']);
    $adresse = trim($_POST['adresse']);
    $id_user = trim($_POST['id_user']);
   
    $photo_etudiant = null;
    if (!empty($_FILES['photo_etudiant']['name'])) {
        $photo_etudiant = 'uploads/' . basename($_FILES['photo_etudiant']['name']);
        move_uploaded_file($_FILES['photo_etudiant']['tmp_name'], $photo_etudiant);
    }
  
    $sql = "INSERT INTO Etudiant (id_etudiant, code_etudiant, prenom, nom, email, date_naissance, telephone, adresse, photo_etudiant, id_user)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($connexion, $sql);
 
    $id_etudiant = uniqid();
  
    mysqli_stmt_bind_param($stmt, "ssssssssss", $id_etudiant, $code_etudiant, $prenom, $nom, $email, $date_naissance, $telephone, $adresse, $photo_etudiant, $id_user);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: etudiant.php");
    } else {
        echo "<p style='color:red;'>Erreur lors de l'ajout de l'étudiant : " . mysqli_error($connexion) . "</p>";
    }
    mysqli_close($connexion);
}
?>
