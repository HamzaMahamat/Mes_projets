<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="page_de_accueillie.css">
</head>
<body>
    <header>
        <img src="images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i>informations</a>
                        <a href="#"><i class="fas fa-cog"></i>paramètres</a>
                        <a href="pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
       <div class="page3_1">
          <div class="droite">
          </div>
          <div class="gauche">
                <p class="info">
                  <i class="fas fa-file-alt" style="color: #186fbb;"> </i>
                  <span>Informations Administrative</span>
                </p> 
                <div class="allo">
                    <div class="message">Veillez passer à la scolarité pour demarrer votre inscription </div>
                    <button class="boutton" id="navigaton"><i class="fas fa-sign-in-alt" style="color: white;"> </i> <a href="page_info_etudiant.php">Consulter mon dossier</a> </button>
               </div>
         </div>
        </div>
        <div class="page3_2">
            <img src="images/logo_ugb@2x.png" alt="" class="logo25">
           <ul>
            <li><a href=""><i class="fas fa-home"></i> Accueil</a></li> 
            <li><a href=""><i class="fas fa-graduation-cap"></i>Inscription Administrative</a></li>
            <li><a href=""><i class="fas fa-graduation-cap"></i>Inscription APédagogique</a></li>
            <li><a href="" target="_parent"><i class="fas fa-file-alt"></i> Consultation des notes</a></li>
            <li><a href=""><i class="fas fa-info-circle"></i> Informations</a></li>
            <li><a href=""><i class="fas fa-info-circle"></i> Aide</a></li>
           </ul>
        </div>
        <br>
       
    </div>
   <script src="boutoun.js"></script>
    <footer>
        <p>&copy; 2024 UFR SAT.Sciences & Technologies</p>
    </footer>
</body>
</html>
