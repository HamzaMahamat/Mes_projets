<?php
session_start();
session_regenerate_id(true);
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== "etudiant") {
    header("Location: pageconnexion.php");
    exit;
}
$Idetudiant=$_SESSION["id_etudiant"];
$prenom = $_SESSION["prenom"];
$nom = $_SESSION["nom"];
$code_etudiant = $_SESSION["code_etudiant"];
$email = $_SESSION["email"];
$date_naissance = $_SESSION["date_naissance"];
$telephone = $_SESSION["telephone"];
$adresse = $_SESSION["adresse"];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Portail UFR SAT</title> 
    <link rel="stylesheet" href="page_infostudent.css">
</head>
<body>
    <header>
        <img src="images/pngtree-graduation-bachelor-cap-black-gold-edge-png-image_6661077.png" alt="" class="image1_gauche">
        <h1>Portail de Services aux Etudiants</h1>
        <nav class="user-nav">
            <ul>
                <li class="dropdown">
                    <a href="#" class="dropbtn"><i class="fas fa-user"></i> Profil</a>
                    <div class="dropdown-content">
                        <a href="#"><i class="fas fa-info-circle"></i> Informations</a>
                        <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                        <a href="pageconnexion.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <div class="pere">
        <div class="container">
            <div class="toto">
            <p class="info">
                <i class="fas fa-file-alt" style="color: #186fbb;"> </i>
                <span>Informations Administrative</span>
            </p> 
            </div>
                <div class="tabs">
                    <button class="tab-btn active" onclick="switchTab('formulaire',event)">Informations personnelles</button>
                    <button class="tab-btn" onclick="switchTab('autres',event)">Formations</button>
                </div>
           
                <div id="formulaire" class="tab-content active">
                <div class="accordion">
                    <h1>Veuillez remplir ce formulaire d'abord.</h1>
                    <p>Les champs grisés ne peuvent pas être modifiés. Les champs précédés de "<span>*</span>" sont <span>obligatoires</span>.</p>
                    <p>Si Vous y trouvez des erreurs, veillez les signaler à la scolarité.</p>
                  
                    <div class="accordion-item">
                        <button class="accordion-header">Etat Civil</button>
                        <div class="accordion-content">

                            <form action="" method="POST">
                            <div class="contacts">
                                <div class="inputform">
                                    <label for="code_etudiant">Code Étudiant :</label>
                                    <input type="text" name="code_etudiant" value="<?php echo htmlspecialchars($code_etudiant); ?>" readonly>
                                </div>
                                <div class="inputform">
                                    <label for="prenom">Prénom(s) :</label>
                                    <input type="text" name="prenom" value="<?php echo htmlspecialchars($prenom); ?>" required readonly>
                                </div>
                                <div class="inputform">
                                    <label for="nom">Nom :</label>
                                    <input type="text" name="nom" value="<?php echo htmlspecialchars($nom); ?>" required readonly>
                                </div>
                                <div class="inputform">
                                    <label for="email">Email :</label>
                                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required readonly>
                                </div>
                                <div class="inputform">
                                    <label for="date_naissance">Date de Naissance :</label>
                                    <input type="date" name="date_naissance" value="<?php echo htmlspecialchars($date_naissance); ?>" required readonly>
                                </div>
                                <div class="inputform">
                                    <label for="telephone">Téléphone :</label>
                                    <input type="tel" name="telephone" value="<?php echo htmlspecialchars($telephone); ?>" required readonly>
                                </div>
                                <div class="inputform">
                                    <label for="adresse">Adresse :</label>
                                    <input type="text" name="adresse" value="<?php echo htmlspecialchars($adresse); ?>" required readonly>
                                </div>
                            </div>
                        </form>
                        </div>
                        
                    </div>
                    <div class="accordion-item">
                        <button class="accordion-header">Contacts</button>
                        <div class="accordion-content">
                            <div class="contacts">
                                <div class="inputform">
                                    <p>
                                <label>Adresse :</label>
                                <input type="text" name="adresse" class="adresse1" >
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Téléphone<span>*</span>:</label> 
                                <input type="tel" name="number" class="numero" >
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Email personnel<span>*</span> :</label>
                                <input type="email" name="email" class="email">
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Email institutionnel :</label>
                                <input type="emaili" name="emaili" class="emaili">
                                </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Section 2 -->
                    <div class="accordion-item">
                        <button class="accordion-header">Personne à contacter en cas d'urgence</button>
                        <div class="accordion-content">
                            <div class="inputform">
                                    <p>
                                <label>Prénom parent :<span>*</span></label>
                                <input type="text" name="adresse" class="adresse1" >
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Nom parent :<span>*</span>:</label> 
                                <input type="tel" name="number" class="numero" >
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Adresse parent :</label>
                                <input type="text" name="email" class="email">
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Telephone parent :<span>*</span></label>
                                <input type="tel" name="tel" class="tel">
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Email parent :<span>*</span></label>
                                <input type="email" name="email" class="tel">
                                </p>
                                </div>
                        </div>
                    </div>

                    <!-- Section 3 -->
                    <div class="accordion-item">
                        <button class="accordion-header">Autres informations</button>
                        <div class="accordion-content">
                        <div class="inputform">
                                    <p>
                                <label>Bourse :</label>
                                <input type="text" name="adresse" class="adresse1" value="NON">
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Ordinateur Personnel:</label> 
                                <input type="tel" name="number" class="numero" value="NON">
                                </p>
                                </div>
                                <div class="inputform">
                                    <p>
                                <label>Souffrez-vous d'un handicap ?:</label>
                                <input type="text" name="email" class="email" value="NON">
                                </p>
                                </div>
                        </div>
                    </div>
                </div>
                <button class="save-button">Enregistrer</button>
                </div>

                <div id="autres" class="tab-content">
                  
                    <div class="accordion-item">
                        <button class="accordion-header">Formations</button>

                        <div class="accordion-content">
                        <?php 
                                    require("config2.php");
                                    $connexion=connect_database2();
                                    $sql="SELECT distinct f.libelle_formation,n.libelle_niveau,a.libelle_annee  FROM inscription i,formation f,niveau n, etudiant e,anneeaccademique a 
                                    where i.id_etudiant='$Idetudiant' and i.id_formation=f.id_formation 
                                    and i.id_niveau=n.id_niveau and i.id_annee=a.id_annee";
                                    $resultat=mysqli_query($connexion,$sql);
                                ?>
                                <table>
                                        <tr>
                                            <th>UFR</th>
                                            <th>FILIERE</th>
                                            <th>NIVEAU</th>
                                            <th>ANNEE ACADEMIQUE</th>
                                            
                                        </tr>
                                        <?php
                                        while($ligne=mysqli_fetch_array($resultat)){?>
                                            <tr>
                                            <td><?php echo "SAT"; ?></td>
                                                <td><?php echo $ligne['libelle_formation']; ?></td>
                                                <td><?php echo $ligne['libelle_niveau']; ?></td>
                                                <td><?php echo $ligne['libelle_annee']; ?></td>
                                            </tr>
                                    <?php }?>
                                    </table>
                        </div>
                    </div>
                </div>
        </div>
    
        <div class="page3_2">
            <img src="images/logo_ugb@2x.png" alt="" class="logo25">
           <ul>
            <li><a href=""><i class="fas fa-home"></i> Accueil</a></li> 
            <li><a href=""><i class="fas fa-graduation-cap"></i>Inscription Administrative</a></li>
            <li><a href=""><i class="fas fa-graduation-cap"></i>Inscription APédagogique</a></li>
            <li><a href="" target="_parent"><i class="fas fa-file-alt"></i> Consultation des notes</a></li>
            <li><a href=""><i class="fas fa-info-circle"></i> Informations</a></li>
            <li><a href=""><i class="fas fa-info-circle"></i> Aide</a></li>
           </ul>
        </div>
    </div>
   <script src="script_infopersonnelle.js"></script>
</body>
</html>
