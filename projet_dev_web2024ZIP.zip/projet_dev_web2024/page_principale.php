<!DOCTYPE html>

<html lang="fr">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Projet_Developpement_dapplication_web_II</title>
       <link rel="stylesheet" href="pageprincipale.css">
       <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
   </head>
   <body>
        <div>
            <div id="entete">
                <header id="header">
                    <img src="images/entete_image_2.png" alt="Image_entete" id="image">
                </header>
            </div>
            <div id="pere">
                    <div id="aine">
                    <img src="images/etudiant.png" alt="Image_entete" id="image">
                    </div>
                <div id="milieu">
                    <div id="filsG">
                      <p class="info">
                        <i class="fas fa-file-alt" style="color: #186fbb;"> </i>
                        <span>Informations</span>
                      </p> 
                      <div class="base">
                      <?php
                        require("config2.php"); 
                        $connexion = connect_database2();
                        $sql = "SELECT id_information, titre, contenu, image FROM information ORDER BY id_information DESC";
                        $resultat = mysqli_query($connexion, $sql);

                        if ($resultat && mysqli_num_rows($resultat) > 0) {
                            while ($article = mysqli_fetch_assoc($resultat)) {
                                echo '<div class="article" style=" display: flex;"   >';
                                if (!empty($article['image'])) {
                                    echo '<img src="' . htmlspecialchars($article['image']) . '" alt="Image de l\'article" style="width: 150px; height: 150px;">';
                                }
                                echo '<div class="article2">';
                                echo '<h2>'. htmlspecialchars($article['titre']) . '</h2>';
                                echo '<p>' . htmlspecialchars($article['contenu']) . '</p>';
                                echo '</div>';
                                echo '</div>';
                                echo '<hr>'; 
                            }
                        } else {
                            echo "<p>Aucun article trouvé.</p>";
                        }
                        mysqli_close($connexion);
                        ?>
                        </div>
                    </div>
                    <div id="filsD">
                        <div id="haut">
                            <p class="info">
                                <i class="fas fa-graduation-cap" style="color: #186fbb;"> </i>
                                <span>Espace privé</span>
                            </p>
                            <p class="text1">Veuillez vous connecter pour accéder à votre espace privé.</p>
                            <button class="boutton"><i class="fas fa-sign-in-alt" style="color: white;"> </i> <a href="pageconnexion.php">Se connecter</a> </button>
                        </div>
                        <div id="bas">
                            <p class="info">
                                <i class="fas fa-exclamation-circle" style="color: #186fbb;"> </i>
                                <span>Guides</span>
                            </p>
                            <p>Pour tout savoir sur l'utilisation de ce portail, veuiller techarger :</p>
                            <button class="boutton2">
                                <i class="fas fa-file-pdf" style="color: white;"> </i>
                                <a  href="document_pdf/guide_ugb.pdf">Le guide d'utilisation</a>
                             </button>
                             <p>Ou consulter</p>
                             <button class="boutton3">
                                <i class="fas fa-file-pdf" style="color: white;"> </i>
                                <a  href="document_pdf/guide_ugb.pdf">Le guide en ligne</a>
                             </button>  
                        </div>

                    </div>
                </div>
                <div id="benjamin">
                <iframe width="100%" height="500" 
                src="https://www.youtube.com/embed/xZhfQyfUOLQ?si=We5HtNuT43xeMBdV" 
                title="YouTube video player" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
            </div>
        </div>
   </body>
   <footer>
      @Copyright CCOS | 2024
   </footer>
</html>