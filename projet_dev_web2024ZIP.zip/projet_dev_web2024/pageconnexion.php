<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion UGB</title>
    <link rel="stylesheet" href="page_connexion.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="images/Ugb.png"  width="100" height="100" alt="Logo UFR SAT">
        </div>
        <h2>Service Authentification Unique</h2>
        <form action="verifier_connexion.php" method="post" id="superman">
            <div class="input-group">
                <label for="email">Email institutionnel UGB</label>
                <input type="email" id="email" name="email" autocomplete="" autofocus="" placeholder="Ex: xxx.xxxx@ugb.edu.sn"  required>
                <span class="error-message" id="email-error" style="color:red;"></span>
            </div>
            <div class="input-group">
                <label for="password">Mot de passe :</label>
                <input type="password" id="password" autofocus="" name="password" required>
                <span class="error-message" id="password-error" style="color:red;"></span>
            </div>
            <div class="links">
                <a href="" class="forgot-password">Activation mail UGB</a>
                <a href="" class="register">Mot de passe oublié ?</a>
            </div>
            <button type="submit" class="connexion">Connexion</button>
        </form>
    </div>
    <script src="page_connexion.js"></script>
</body>
</html>

