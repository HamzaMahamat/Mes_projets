
document.querySelectorAll('.accordion-header').forEach(button => {
    button.addEventListener('click', () => {
        const content = button.nextElementSibling;

        document.querySelectorAll('.accordion-content').forEach(item => {
            if (item !== content) {
                item.style.display = 'none';
            }
        });

      
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
});
function switchTab(tabId,event) {
  
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });

   
    document.querySelectorAll('.tab-btn').forEach(button => {
        button.classList.remove('active');
    });

    document.getElementById(tabId).classList.add('active');


    event.currentTarget.classList.add('active');
}
