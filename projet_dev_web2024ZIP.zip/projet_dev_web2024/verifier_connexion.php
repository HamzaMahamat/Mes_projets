<?php
session_start();
require("config2.php");
$connexion = connect_database2();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
  
    if (!empty($email) && !empty($password)) {
      
        $sql = "SELECT * FROM user WHERE email = ?";
        $stmt = mysqli_prepare($connexion, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);

         
            if ($password === $user['password']) { 
                session_regenerate_id(true); 
             
                $_SESSION["user_id"] = $user["id_user"];
                $_SESSION["user_role"] = $user["id_role"];
             
                if ($user["id_role"] === "etudiant") {
                    $sql_etudiant = "SELECT * FROM etudiant WHERE id_user = ? AND email='$email'";
                    $stmt_etudiant = mysqli_prepare($connexion, $sql_etudiant);
                    mysqli_stmt_bind_param($stmt_etudiant, "i", $user["id_user"]);
                    mysqli_stmt_execute($stmt_etudiant);
                    $result_etudiant = mysqli_stmt_get_result($stmt_etudiant);
            
                    if ($result_etudiant && mysqli_num_rows($result_etudiant) > 0) {
                        $etudiant = mysqli_fetch_assoc($result_etudiant);
                      
                        $_SESSION["id_etudiant"] = $etudiant["id_etudiant"];
                        $_SESSION["prenom"] = $etudiant["prenom"];
                        $_SESSION["nom"] = $etudiant["nom"];
                        $_SESSION["code_etudiant"] = $etudiant["code_etudiant"];
                        $_SESSION["email"] = $etudiant["email"];
                        $_SESSION["date_naissance"] = $etudiant["date_naissance"];
                        $_SESSION["telephone"] = $etudiant["telephone"];
                        $_SESSION["adresse"] = $etudiant["adresse"];
                    }
                }
            
            
                if ($user["id_role"] === "admin") {
                    header("Location: page_admin.php");
                } elseif ($user["id_role"] === "etudiant") {
                    header("Location: page_de_accueille.php");
                }
                exit;
            }
            
        }
    }
    header("Location: pageconnexion.php");
    exit;
}

mysqli_close($connexion);
?>
